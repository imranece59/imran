package com.inventivhealth.etl.test

import java.sql.Timestamp

import com.inventivhealth.etl.Args
import com.inventivhealth.etl.test.base.TestETLProcess
import org.scalatest.Inspectors._
import org.scalatest.{Matchers, WordSpec}

class TransformationSpecTest extends WordSpec with SparkCassandraSpec with Matchers {

  override val dataSets: Seq[String] = Seq("transform/customer_transform.cql")

  "Transformation step" should {
    "apply insert transformation rules according to mapping_config" in {
      val args = Args(tenantId = 1, sourceName = "classPath", sourceEntityName = "Customer_Header.txt",
        targetName = "ods", targetEntityName = "d_account")
      val process = new TestETLProcess(args, sqlContext)
      val source = process.findDelta(process.extract()).head.data
      val target = process.transform(source, process.mappingIns)
      val targetData = target.collect()
      targetData should have size 15
      forAll(targetData) { row =>
        val cid = row.getAs[String]("src_unq_id")
        cid should not be null
        row.getAs[String]("accnt_id") should be(s"1:$cid")
        row.getAs[Int]("tenant_id") should be(1)
        val pdrp = row.getAs[Int]("pdrp_opt_out_c")
        assert(pdrp == 0 || pdrp == 1)
        row.getAs[String]("active_inactive") should be("ACTIVE")
        row.getAs[String]("created_by") should be(process.etlConfig.processId.toString)
        row.getAs[Timestamp]("created_dt") should not be null
        intercept[IllegalArgumentException] {
          row.getAs[String]("updated_by")
        }
        intercept[IllegalArgumentException] {
          row.getAs[Timestamp]("updated_dt")
        }

        val firstName = row.getAs[String]("frst_nm")
        val lastName = row.getAs[String]("lst_nm")
        row.getAs[String]("accnt_attrb_99") should be (s"$firstName:$lastName")
      }
      val withBrthDate = targetData.filter(_.getAs[Timestamp]("brth_dt") != null)
      withBrthDate should have size 4
    }
    "apply update transformation rules according to mapping_config" in {
      val args = Args(tenantId = 1, sourceName = "classPath", sourceEntityName = "Customer_Header.txt",
        targetName = "ods", targetEntityName = "d_account")
      val process = new TestETLProcess(args, sqlContext)
      val source = process.findDelta(process.extract()).head.data
      val target = process.transform(source, process.mappingUpd)
      val targetData = target.collect()
      targetData should have size 15
      forAll(targetData) { row =>
        val cid = row.getAs[String]("src_unq_id")
        cid should not be null
        row.getAs[String]("accnt_id") should be(s"1:$cid")
        row.getAs[Int]("tenant_id") should be(1)
        val pdrp = row.getAs[Int]("pdrp_opt_out_c")
        assert(pdrp == 0 || pdrp == 1)
        row.getAs[String]("active_inactive") should be("ACTIVE")
        row.getAs[String]("updated_by") should be(process.etlConfig.processId.toString)
        row.getAs[Timestamp]("updated_dt") should not be null
        intercept[IllegalArgumentException] {
          row.getAs[String]("created_by")
        }
        intercept[IllegalArgumentException] {
          row.getAs[Timestamp]("created_dt")
        }
      }
      val withBrthDate = targetData.filter(_.getAs[Timestamp]("brth_dt") != null)
      withBrthDate should have size 4
    }
    "apply delete transformation rules according to mapping_config" in {
      val args = Args(tenantId = 1, sourceName = "classPath", sourceEntityName = "Customer_Header.txt",
        targetName = "ods", targetEntityName = "d_account")
      val process = new TestETLProcess(args, sqlContext)
      val source = process.findDelta(process.extract()).head.data
      val target = process.transform(source, process.mappingDel)
      val targetData = target.collect()
      targetData should have size 15
      forAll(targetData) { row =>
        row.getAs[String]("accnt_id") should startWith("1:")
        row.getAs[Int]("tenant_id") should be(1)
        row.getAs[String]("active_inactive") should be("INACTIVE")
        row.getAs[String]("updated_by") should be(process.etlConfig.processId.toString)
        row.getAs[Timestamp]("updated_dt") should not be null
        intercept[IllegalArgumentException] {
          row.getAs[String]("created_by")
        }
        intercept[IllegalArgumentException] {
          row.getAs[Timestamp]("created_dt")
        }
      }
    }
  }
}
