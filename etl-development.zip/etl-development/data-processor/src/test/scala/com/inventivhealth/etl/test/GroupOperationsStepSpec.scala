package com.inventivhealth.etl.test

import com.inventivhealth.etl.Args
import com.inventivhealth.etl.test.base.TestETLProcess
import org.scalatest.{Matchers, WordSpec}

class GroupOperationsStepSpec extends WordSpec with SparkCassandraSpec with Matchers {

  override val dataSets: Seq[String] = Seq("groupops/group.cql")

  val args =  Args(tenantId = 1, sourceName = "classPath", sourceEntityName = "Customer_Header.txt",
    targetName = "ods", targetEntityName = "d_account")

  lazy val process = new TestETLProcess(args, sqlContext)

  "ETL process group operations step" should {
    "apply filtering operation to target data set" in {
      val source = process.extract()
      val delta = process.findDelta(source)
      val (valid, _) = process.validate(delta.head.data)
      val transformed = process.transform(valid, delta.head.mappings)
      transformed.count() should be (4)
      val filtered = process.applyTargetGroupOperations(transformed)
      filtered.count() should be (3)
      val set = filtered.collect().map(_.getAs[String]("accnt_id")).toSet
      set should be (Set("1:3143195", "1:3074129", "1:2102250"))
    }
  }

}
