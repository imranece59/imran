package com.inventivhealth.etl.test.base

import com.inventivhealth.etl.extract.DataExtractor
import org.apache.spark.sql.{DataFrame, SQLContext}
import org.apache.spark.sql.types.StructType

/**
  * Extracts file from jar's classpath. For testing and debugging purposes only.
  */
class ClassPathDataExtractor(path: String, schema: Option[StructType], delimiter: String, header:Boolean) extends DataExtractor {

  override def extractData(sqlContext: SQLContext): DataFrame = {
    val filePath =
      if (path.startsWith("/")) path.replace("/", "")
      else path
    val fullPath = this.getClass.getClassLoader.getResource(filePath).toString

    var dfReader = sqlContext.read
      .format("com.databricks.spark.csv")
      .option("header", header.toString)
      .option("inferSchema", schema.isEmpty.toString)
      .option("delimiter", delimiter)
    if (schema.isDefined) {
      dfReader = dfReader.schema(schema.get)
    }
    dfReader.load(fullPath)
  }

}
