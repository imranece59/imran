package com.inventivhealth.etl.test.base

import com.inventivhealth.etl.Args
import com.inventivhealth.etl.test.SparkCassandraSpec

trait EtlSpec {
  this: SparkCassandraSpec =>

  val args: Args

  lazy val testRegistry = new TestETLProcess(args, sqlContext)

}
