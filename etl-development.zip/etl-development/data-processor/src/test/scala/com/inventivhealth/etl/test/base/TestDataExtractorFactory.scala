package com.inventivhealth.etl.test.base

import com.inventivhealth.etl.extract.{CassandraDataExtractor, DataExtractor, DataExtractorFactory, DataSources}
import org.apache.spark.sql.types.StructType

trait TestDataExtractorFactory extends DataExtractorFactory {

  override def getDataExtractor(sourceName: String, sourceEntityName: String, hasHeader: Boolean,
                                schema: Option[StructType], delimiter: Option[String], parserLib: String = "commons"): DataExtractor = {
    DataSources.withName(sourceName) match {
      case DataSources.`classPath` => new ClassPathDataExtractor(sourceEntityName, schema, delimiter.getOrElse("^"), hasHeader)
      case DataSources.`ods` => new CassandraDataExtractor(sourceName, sourceEntityName)
      case _ => throw new IllegalArgumentException(s"$sourceName source is supported by unit tests")
    }
  }

}
