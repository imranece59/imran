package com.inventivhealth.etl.test

import com.inventivhealth.etl.Args
import com.inventivhealth.etl.test.base.TestETLProcess
import org.apache.spark.sql.Row
import org.scalatest.Inspectors._
import org.scalatest.{Matchers, WordSpec}

import scala.collection.JavaConverters._

class EnrichmentStepSpec extends WordSpec with SparkCassandraSpec with Matchers {

  override val dataSets: Seq[String] = Seq("enrich/enrichement_test.cql")

  "Enrichment ETL step" should {
    "perform single parent lookup" in {
      val args =  Args(tenantId = 1, sourceName = "classPath", sourceEntityName = "enrichment_test_single_lookup.txt",
        targetName = "ods", targetEntityName = "d_account")
      val process = new TestETLProcess(args, sqlContext)

      val source = process.extract()
      source.count() should be (9)

      val (enriched, _) = process.enrich(source)

      val specialties = process.cassandraDao.withSessionDo { session =>
        val rs = session.execute("select * from ods.d_specialty").all().asScala
        rs.map(r => r.getInt("spclty_id") -> (r.getString("spclty_cd"), r.getString("spclty_grp_desc"))).toMap
      }
      specialties should have size 6
      val enrichedList = enriched.collect().toList
      enrichedList should have size specialties.size

      val result = enrichedList
        .map(row => row.getAs[String]("AMX_SPEC_DESC").toInt -> (row.getAs[String]("spclty_cd"), row.getAs[String]("spclty_grp_desc")))

      forAll(result) { case (id, (code, desc)) =>
        specialties should contain key id
        specialties should contain value (code, desc)
      }
    }
    "collect RI validation violations and return separate data frame with invalid records for single lookup" in {
      val args =  Args(tenantId = 1, sourceName = "classPath", sourceEntityName = "enrichment_test_single_lookup.txt",
        targetName = "ods", targetEntityName = "d_account")
      val process = new TestETLProcess(args, sqlContext)

      val source = process.extract()
      source.count() should be (9)

      val (enriched, invalid) = process.enrich(source)

      invalid.count should be (3)
      val data = invalid.map { row =>
        val id = row.getAs[String]("AMX_SPEC_DESC").toInt
        val arr = row.getAs[scala.collection.mutable.WrappedArray[Row]]("validations")
          .map(r => (r.getAs[String](0), r.getAs[String](1), r.getAs[String](2)))
          .toArray
        id -> arr
      }.collect()
      data.map(_._1).toSet should be (Set(3,6,9))
      forAll(data) { case (_, arr) =>
        arr should have size 1
        forAll(arr) { case (fieldVal, fieldName, reason) =>
          fieldVal should be (null)
          fieldName should be ("spclty_id")
          reason should be ("RI_VIOLATION")
        }
      }
    }
    "perform multi parent lookup" in {
      val args =  Args(tenantId = 2, sourceName = "classPath", sourceEntityName = "erichment_test_multi_lookup.txt",
        targetName = "ods", targetEntityName = "d_account")
      val process = new TestETLProcess(args, sqlContext)

      val source = process.extract()
      source.count() should be (9)

      val (enriched, _) = process.enrich(source)

      val specialties = process.cassandraDao.withSessionDo { session =>
        val rs = session.execute("select * from ods.d_specialty").all().asScala
        rs.map(r => r.getInt("spclty_id") -> (r.getString("spclty_cd"), r.getString("spclty_grp_desc"))).toMap
      }
      val testLookups = process.cassandraDao.withSessionDo { session =>
        val rs = session.execute("select * from ods.test_multi_lookup_parent").all().asScala
        rs.map(r => r.getInt("lookup_id") -> (r.getString("name"), r.getString("description"), r.getString("attrb_1"), r.getString("attrb_2")))
          .toMap
      }

      val sourceIds = source.map { r =>
        (r.getAs[String]("AMX_SPEC_DESC").toInt, r.getAs[String]("AMX_SPEC_SECN_SPEC_DESC").toInt, r.getAs[String]("CID"))
      }.collect()

      val firstLookupValid = sourceIds
        .filter { case (specId, _, _) => specialties.contains(specId) }
        .map { case (_, _, cid) => cid }
        .toSet
      val secondLookupValid = sourceIds
        .filter { case (_, lookupId, _) => testLookups.contains(lookupId) }
        .map { case (_, _, cid) => cid }
        .toSet
      val validIds = firstLookupValid.intersect(secondLookupValid)

      enriched.count() should be (validIds.size)
      val enrichedList = enriched.collect()
      enrichedList.map(_.getAs[String]("CID")).toSet should be (validIds)
      forAll(enrichedList) { row =>
        row.getAs[String]("spclty_cd") should not be 'empty
        row.getAs[String]("spclty_grp_desc") should not be 'empty
        row.getAs[String]("name") should not be 'empty
        row.getAs[String]("description") should not be 'empty
        row.getAs[String]("attrb_1") should not be 'empty
        intercept[IllegalArgumentException] {
          row.getAs[String]("attrb_2")
        }
      }
    }
    "collect RI validation violations and return separate data frame with invalid records for multi lookup" in {
      val args =  Args(tenantId = 2, sourceName = "classPath", sourceEntityName = "erichment_test_multi_lookup.txt",
        targetName = "ods", targetEntityName = "d_account")
      val process = new TestETLProcess(args, sqlContext)

      val source = process.extract()
      source.count() should be (9)

      val (_, invalid) = process.enrich(source)

      val specialties = process.cassandraDao.withSessionDo { session =>
        val rs = session.execute("select * from ods.d_specialty").all().asScala
        rs.map(r => r.getInt("spclty_id") -> (r.getString("spclty_cd"), r.getString("spclty_grp_desc"))).toMap
      }
      val testLookups = process.cassandraDao.withSessionDo { session =>
        val rs = session.execute("select * from ods.test_multi_lookup_parent").all().asScala
        rs.map(r => r.getInt("lookup_id") -> (r.getString("name"), r.getString("description"), r.getString("attrb_1"), r.getString("attrb_2")))
          .toMap
      }

      val sourceIds = source.map { r =>
        (r.getAs[String]("AMX_SPEC_DESC").toInt, r.getAs[String]("AMX_SPEC_SECN_SPEC_DESC").toInt, r.getAs[String]("CID"))
      }.collect()

      val firstLookupValid = sourceIds
        .filter { case (specId, _, _) => specialties.contains(specId) }
        .map { case (_, _, cid) => cid }
        .toSet
      val secondLookupValid = sourceIds
        .filter { case (_, lookupId, _) => testLookups.contains(lookupId) }
        .map { case (_, _, cid) => cid }
        .toSet
      val validIds = firstLookupValid.intersect(secondLookupValid)

      val allIds = source.map(_.getAs[String]("CID")).collect().toSet
      val invalidIds = allIds.diff(validIds)

      val invalidList = invalid.collect()
      invalidList should have size invalidIds.size
      invalidList.map(_.getAs[String]("CID")).toSet should be (invalidIds)
      val data = invalid.map { row =>
        val specId = row.getAs[String]("AMX_SPEC_DESC").toInt
        val lookupId = row.getAs[String]("AMX_SPEC_SECN_SPEC_DESC").toInt
        val arr = row.getAs[scala.collection.mutable.WrappedArray[Row]]("validations")
          .map(r => (r.getAs[String](0), r.getAs[String](1), r.getAs[String](2)))
          .toArray
        (specId, lookupId, arr)
      }.collect()
      val onlySpecViolations = data.filter { case (specId, _, _) => specId == 3 }
      forAll(onlySpecViolations) { case (_, _, arr) =>
        arr should have size 1
        arr should contain ((null, "spclty_id", "RI_VIOLATION"))
      }
      val onlyLookupViolations = data.filter { case (_, lookupId, _) => Set(50, 70, 80).contains(lookupId) }
      forAll(onlyLookupViolations) { case (_, _, arr) =>
        arr should have size 1
        arr should contain ((null, "lookup_id", "RI_VIOLATION"))
      }
      val allViolations = data.filter { case (_, lookupId, _) => Set(60, 90).contains(lookupId) }
      forAll(allViolations) { case (_, _, arr) =>
        arr should have size 2
        arr should contain ((null, "lookup_id", "RI_VIOLATION"))
        arr should contain ((null, "spclty_id", "RI_VIOLATION"))
      }
    }
  }
}
