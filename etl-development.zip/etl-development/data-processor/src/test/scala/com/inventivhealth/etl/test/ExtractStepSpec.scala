package com.inventivhealth.etl.test

import com.inventivhealth.etl.Args
import com.inventivhealth.etl.test.base.TestETLProcess
import com.inventivhealth.etl.util.FormattingUtil
import org.scalatest.Inspectors._
import org.scalatest.{Matchers, WordSpec}

class ExtractStepSpec extends WordSpec with SparkCassandraSpec with Matchers {

  val args =  Args(tenantId = 1, sourceName = "classPath", sourceEntityName = "Customer_Header.txt",
    targetName = "ods", targetEntityName = "d_account")

  lazy val process = new TestETLProcess(args, sqlContext)

  "ETL process extract step" should {
    "extract data from source (Customer_Header.txt)" in {
      val source = process.extract()
      val count = source.count()
      count should be (16)
    }
    "apply schema from etl_config.schema_cols to source data frame" in {
      val source = process.extract()
      val schema = source.schema
      schema should not be null

      val schemaStr = process.etlConfig.schemaCols.get
      val cols = "row" :: schemaStr.split(FormattingUtil.escapeCharacters(process.delim)).toList
      forAll(schema.fields) { field =>
        cols should contain (field.name)
      }
    }
  }

}
