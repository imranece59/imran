package com.inventivhealth.etl.test

import com.inventivhealth.etl.Args
import com.inventivhealth.etl.test.base.TestETLProcess
import org.scalatest.Inspectors._
import org.scalatest.{Matchers, WordSpec}

class ValidateStepSpec extends WordSpec with SparkCassandraSpec with Matchers {

  val args =  Args(tenantId = 1, sourceName = "classPath", sourceEntityName = "Customer_Header.txt",
    targetName = "ods", targetEntityName = "d_account")

  lazy val process = new TestETLProcess(args, sqlContext)

  "Validate step" should {
    "validate data with data type and non null validation rules" in {
      val source = process.extract()
      val (valid, invalid) = process.validate(source)
      valid.count() should be (4)
      invalid.count() should be (12)
      val rows = invalid.select("validations")
        .collect()
        .map(_.getAs[scala.collection.mutable.WrappedArray[String]]("validations"))
      forAll(rows) { row =>
        row should not be 'empty
      }
    }
  }
}
