package com.inventivhealth.etl.test

import com.inventivhealth.etl.Args
import com.inventivhealth.etl.config.model.ETLError
import com.inventivhealth.etl.exceptions.ETLProcessException
import com.inventivhealth.etl.test.base.TestETLProcess
import org.scalatest.{Matchers, WordSpec}
import org.scalatest.Inspectors._

import scala.collection.JavaConverters._

class ETLProcessE2ESpec extends WordSpec with SparkCassandraSpec with Matchers {

  override val dataSets: Seq[String] = Seq("e2e/customer_e2e.cql")

  "ETL process" should {
    "extract, validate, enrich and transform data (positive path)" in {
      val args =  Args(tenantId = 1, sourceName = "classPath", sourceEntityName = "Customer_success.txt",
        targetName = "ods", targetEntityName = "d_account")
      val process = new TestETLProcess(args, sqlContext)

      process.perform()

      val validCIDs = Set("2022604720", "2020372393", "2004258310", "3143195", "2019795993", "2017323242", "3074129",
        "1000333986", "2102250", "2022105500", "2022891881", "1000247355", "2020783842", "11000247355")
      process.cassandraDao.withSessionDo { session =>
        val accounts = session.execute("select * from ods.d_account").all().asScala
        accounts should have size validCIDs.size
        accounts.map(_.getString("src_unq_id")).toSet should be (validCIDs)
        forAll(accounts) { acc =>
          acc.getString("src_unq_id") should not be 'empty
          validCIDs should contain (acc.getString("src_unq_id"))
          acc.getString("lst_nm") should not be 'empty
          acc.getString("frst_nm") should not be 'empty
          acc.getString("accnt_id") should startWith ("1:")
          acc.getInt("tenant_id") should be (1)
          acc.getString("active_inactive") should be ("ACTIVE")
          acc.getString("created_by") should be ("1")
          acc.getTimestamp("created_dt") should not be null
          acc.getString("accnt_attrb_95") should not be 'empty
          acc.getString("accnt_attrb_95") should startWith ("spec_code_")
          acc.getString("accnt_attrb_96") should not be 'empty
          acc.getString("accnt_attrb_96") should startWith ("description_")
        }

        val errors = session.execute("select * from ods.err_table").all().asScala
          .map(r => ETLError(
            r.getInt("tenant_id"),
            r.getInt("group_id"),
            r.getInt("process_id"),
            r.getInt("err_min"),
            r.getInt("err_hour"),
            r.getInt("err_day"),
            r.getInt("err_month"),
            r.getInt("err_year"),
            r.getString("subcategory"),
            r.getUUID("err_timestamp"),
            r.getString("err_message"),
            r.getString("row"),
            r.getString("source"),
            r.getString("source_entity"),
            r.getString("status"),
            r.getTimestamp("status_dt").getTime,
            r.getString("step"),
            r.getString("target"),
            r.getString("target_entity")
          ))
        errors should have size 4
        forAll(errors.filter(_.row.startsWith("1002500864"))) { err =>
          err.errMsg should be ("[error = RI_VIOLATION, field = spclty_id, value = 'null']")
        }
        forAll(errors.filter(_.row.startsWith("21000247355"))) { err =>
          err.errMsg should be ("[error = WRONG_DATA_TYPE, field = PRFN_AMX_DATA_SRC_ID, value = 'wrong']")
        }
        forAll(errors.filter(_.row.startsWith("31000247355"))) { err =>
          err.errMsg should be ("[error = FIELD_IS_NULL, field = LST_NM, value = '']")
        }
        forAll(errors.filter(_.row.startsWith("43143195"))) { err =>
          err.errMsg should be ("[error = FIELD_IS_NULL, field = FRST_NM, value = '']")
        }

        val logs = session.execute("select * from ods.log_table").all().asScala
          .filter(r => r.getInt("tenant_id") == 1)
        logs should have size 1
        forAll(logs) { log =>
          log.getInt("tenant_id") should be (1)
          log.getInt("process_id") should be (1)
          log.getString("status") should be ("SUCCESS")
          log.getLong("num_rows_source") should be (18)
          log.getLong("num_rows_target") should be (14)
        }
      }
    }
    "fail ETL process in case if error threshold exceeded (negative path)" in {
      val args =  Args(tenantId = 2, sourceName = "classPath", sourceEntityName = "Customer_error.txt",
        targetName = "ods", targetEntityName = "d_account")
      val process = new TestETLProcess(args, sqlContext)

      intercept[ETLProcessException] {
        process.perform()
      }
    }

    "perform only RI validation in case if return columns not specified" in {
      val args =  Args(tenantId = 3, sourceName = "classPath", sourceEntityName = "Customer_success.txt",
        targetName = "ods", targetEntityName = "d_account")
      val process = new TestETLProcess(args, sqlContext)

      process.perform()

      val validCIDs = Set("2022604720", "2020372393", "2004258310", "3143195", "2019795993", "2017323242", "3074129",
        "1000333986", "2102250", "2022105500", "2022891881", "1000247355", "2020783842", "11000247355")
      process.cassandraDao.withSessionDo { session =>
        val accounts = session.execute("select * from ods.d_account").all().asScala
        accounts should have size validCIDs.size
        accounts.map(_.getString("src_unq_id")).toSet should be (validCIDs)
        forAll(accounts) { acc =>
          acc.getString("src_unq_id") should not be 'empty
          validCIDs should contain (acc.getString("src_unq_id"))
          acc.getString("lst_nm") should not be 'empty
          acc.getString("frst_nm") should not be 'empty
          acc.getString("accnt_id") should startWith ("3:")
          acc.getInt("tenant_id") should be (3)
          acc.getString("active_inactive") should be ("ACTIVE")
          acc.getString("created_by") should be ("3")
          acc.getTimestamp("created_dt") should not be null
        }

        val errors = session.execute("select * from ods.err_table").all().asScala
          .map(r => ETLError(
            r.getInt("tenant_id"),
            r.getInt("group_id"),
            r.getInt("process_id"),
            r.getInt("err_min"),
            r.getInt("err_hour"),
            r.getInt("err_day"),
            r.getInt("err_month"),
            r.getInt("err_year"),
            r.getString("subcategory"),
            r.getUUID("err_timestamp"),
            r.getString("err_message"),
            r.getString("row"),
            r.getString("source"),
            r.getString("source_entity"),
            r.getString("status"),
            r.getTimestamp("status_dt").getTime,
            r.getString("step"),
            r.getString("target"),
            r.getString("target_entity")
          ))
        errors should have size 4
        forAll(errors.filter(_.row.startsWith("1002500864"))) { err =>
          err.errMsg should be ("[error = RI_VIOLATION, field = spclty_id, value = 'null']")
        }
        forAll(errors.filter(_.row.startsWith("21000247355"))) { err =>
          err.errMsg should be ("[error = WRONG_DATA_TYPE, field = PRFN_AMX_DATA_SRC_ID, value = 'wrong']")
        }
        forAll(errors.filter(_.row.startsWith("31000247355"))) { err =>
          err.errMsg should be ("[error = FIELD_IS_NULL, field = LST_NM, value = '']")
        }
        forAll(errors.filter(_.row.startsWith("43143195"))) { err =>
          err.errMsg should be ("[error = FIELD_IS_NULL, field = FRST_NM, value = '']")
        }

        val logs = session.execute("select * from ods.log_table").all().asScala
          .filter(r => r.getInt("tenant_id") == 3)
        logs should have size 1
        forAll(logs) { log =>
          log.getInt("tenant_id") should be (3)
          log.getInt("process_id") should be (3)
          log.getString("status") should be ("SUCCESS")
          log.getLong("num_rows_source") should be (18)
          log.getLong("num_rows_target") should be (14)
        }
      }
    }
  }
}
