package com.inventivhealth.etl.test.base

import com.inventivhealth.etl.Args
import com.inventivhealth.etl.config.model.ETLConfig
import com.inventivhealth.etl.config.{AppConfig, ConfigComponent}
import com.inventivhealth.etl.dao.{CassandraDao, CassandraDaoComponent, CassandraETLConfigComponent}
import com.inventivhealth.etl.persist.{CassandraDataSaver, DefaultDataSaverFactory}
import com.inventivhealth.etl.process._
import com.inventivhealth.etl.spark.SparkComponent
import com.inventivhealth.etl.transform.ClassPathScanETLFunctionsComponent
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.SQLContext

class TestETLProcess(override val args: Args, override val sqlContext: SQLContext) extends {

  val config = ConfigFactory.parseResources("reference.conf")

  override val appConfig: AppConfig = new AppConfig(config)

  override val etlConfig: ETLConfig = {
    val cassandraDao = CassandraDao(appConfig)
    try {
      cassandraDao
        .getConfig(args.tenantId, args.sourceName, args.sourceEntityName, args.targetName, args.targetEntityName)
        .head
    } finally cassandraDao.destroy()
  }

} with ConfigComponent
  with CassandraDaoComponent with CassandraETLConfigComponent with TestDataExtractorFactory
  with ClassPathScanETLFunctionsComponent with SparkComponent with DefaultDataSaverFactory
  with ETLProcess