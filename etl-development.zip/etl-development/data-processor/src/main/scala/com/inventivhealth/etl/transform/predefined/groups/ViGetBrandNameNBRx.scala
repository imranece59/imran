package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class ViGetBrandNameNBRx extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "viGetBrandNameNBRx"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val tenantId = parameters(ETLProcess.tenantIdParam)
    val sqlContext = df.sqlContext
    val sparkContext = sqlContext.sparkContext

    val brandDataExtractor = getDataExtractor(sourceName, "d_brand", false)
    var brandDf = brandDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (brandDf.schema.fieldNames.contains("active_inactive")) {
      brandDf = brandDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }

    val brands = brandDf
      .select("src_brand_id", "brand_id")
      .withColumn("src_brand_id", when(col("src_brand_id").isNull, lit("")).otherwise(col("src_brand_id")))
      .collect()
      .map(row => row.getAs[String]("src_brand_id") -> row.getAs[String]("brand_id")).toMap

    val brandsBc = sparkContext.broadcast(brands)

    val getBrandName = udf { (srcBrandId: String) => brandsBc.value.get(srcBrandId) }

    df
      .withColumn("brand_id", getBrandName(col("fin_brnd_id")))
      .where(col("brand_id").isNotNull)
  }
}