package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame

class BiWebGeographyRegionWeek1Columns extends GroupOperation {
  override val name: String = "biWebGeoRegWeek1Cols"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    df
      .withColumnRenamed("region_four_week_rx", "region_four_week_nbrx")
      .withColumnRenamed("region_four_week_rx_change_perc", "region_four_week_nbrx_change_perc")
      .withColumnRenamed("district_four_week_rx", "district_four_week_nbrx")
      .withColumnRenamed("district_four_week_rx_change_perc", "district_four_week_nbrx_change_perc")
  }
}