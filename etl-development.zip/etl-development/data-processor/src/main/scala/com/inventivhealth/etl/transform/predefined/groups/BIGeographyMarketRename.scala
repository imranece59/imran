package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class BIGeographyMarketRename extends GroupOperation {
  override val name: String = "biGeoMktRen"
  private val newNameParam = "newName"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    df.withColumn("market_name", lit(operationParams.getOrElse(newNameParam, "MARKET")))
  }
}