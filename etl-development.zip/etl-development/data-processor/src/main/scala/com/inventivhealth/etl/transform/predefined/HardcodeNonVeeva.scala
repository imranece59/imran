package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class HardcodeNonVeeva extends EtlFunction0[String] {
  override val name: String = "hardcodeNonVeeva"

  override def execute(): String = "Non-Veeva"

  override def createUdf: UserDefinedFunction = udf { execute _ }
}