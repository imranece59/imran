package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class DefaultLocationType extends EtlFunction0[String] {
  override val name: String = "defaultLcnsTyp"

  override def execute(): String = "STATE_LCNS_NMBR"

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
