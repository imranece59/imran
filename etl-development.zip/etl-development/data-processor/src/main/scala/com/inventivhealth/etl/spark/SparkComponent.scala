package com.inventivhealth.etl.spark

import org.apache.spark.sql.SQLContext

trait SparkComponent {
  val sqlContext: SQLContext
}
