package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.bi._
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{countDistinct, first, lit}

class BIWebHomeNationMonthlyAggregation extends GroupOperation {
  override val name: String = "biWebHomeNationMonthlyAggregation"

  val cacheParam = "cache"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._

    if (operationParams.get(cacheParam).exists(_.toBoolean)) {
      df.cache()
      df.count()
    }

    val regionAll = df
      .groupBy("tenant_id", "st_id", "region_name", "nation_name", "segment_type", "segment", "month_id", "month_name")
      .agg(countDistinct("accnt_call_id") as "total_prescriber_calls",
        first("reg_number_working_days") as "number_working_days", first("region_total_targets") as "total_targets")

    val regionTargets = df
      .where($"target" === lit("Y"))
      .groupBy("tenant_id", "st_id", "region_name", "nation_name", "segment_type", "segment", "month_id", "month_name")
      .agg(countDistinct("accnt_call_id") as "target_calls", countDistinct("accnt_id") as "targets_called")

    val nationAll = df
      .groupBy("tenant_id", "st_id", "nation_name", "segment_type", "segment", "month_id", "month_name")
      .agg(countDistinct("accnt_call_id") as "total_prescriber_calls",
        first("nat_number_working_days") as "number_working_days", first("nation_total_targets") as "total_targets")

    val nationTargets = df
      .where($"target" === lit("Y"))
      .groupBy("tenant_id", "st_id", "nation_name","segment_type", "segment", "month_id", "month_name")
      .agg(countDistinct("accnt_call_id") as "target_calls", countDistinct("accnt_id") as "targets_called")

    val region = regionAll
      .join(regionTargets, Seq("tenant_id", "st_id", "region_name", "nation_name", "segment_type", "segment", "month_id", "month_name"), "left_outer")
      .select(regionAll("*"), regionTargets("target_calls"), regionTargets("targets_called"))
      .withColumn("region_avg_target_frequency", avgTargetFrequency($"target_calls", $"targets_called"))
      .withColumn("region_avg_prescriber_calls_per_day", avgPrescriberCallsPerDay($"total_prescriber_calls", $"number_working_days"))
      .withColumn("region_target_calls_per_day", targetCallsPerDay($"target_calls", $"number_working_days"))
      .withColumn("region_percent_calls_to_targets", percentCallsToTargets($"target_calls", $"total_prescriber_calls"))
      .withColumn("region_reach", reach($"targets_called", $"total_targets"))

    val nation = nationAll
      .join(nationTargets, Seq("tenant_id", "st_id", "nation_name", "segment_type", "segment", "month_id", "month_name"), "left_outer")
      .select(nationAll("*"), nationTargets("target_calls"), nationTargets("targets_called"))
      .withColumn("nation_avg_target_frequency", avgTargetFrequency($"target_calls", $"targets_called"))
      .withColumn("nation_avg_prescriber_calls_per_day", avgPrescriberCallsPerDay($"total_prescriber_calls", $"number_working_days"))
      .withColumn("nation_target_calls_per_day", targetCallsPerDay($"target_calls", $"number_working_days"))
      .withColumn("nation_percent_calls_to_targets", percentCallsToTargets($"target_calls", $"total_prescriber_calls"))
      .withColumn("nation_reach", reach($"targets_called", $"total_targets"))

    region
      .join(nation, Seq("tenant_id", "st_id", "nation_name", "segment_type", "segment", "month_id", "month_name"))
      .select(
        region("tenant_id"),
        region("st_id"),
        region("region_name"),
        region("nation_name"),
        region("segment_type"),
        region("segment"),
        region("month_id"),
        region("month_name"),
        region("region_avg_target_frequency"),
        region("region_avg_prescriber_calls_per_day"),
        region("region_target_calls_per_day"),
        region("region_percent_calls_to_targets"),
        region("region_reach"),
        nation("nation_avg_target_frequency"),
        nation("nation_avg_prescriber_calls_per_day"),
        nation("nation_target_calls_per_day"),
        nation("nation_percent_calls_to_targets"),
        nation("nation_reach"),

        region("target_calls") as "region_target_calls",
        region("targets_called") as "region_number_of_targets_called",
        region("total_prescriber_calls") as "region_total_prescriber_calls",
        region("number_working_days") as "region_number_of_work_days",
        region("targets_called") as "region_call_count", // identical
        region("number_working_days") as "region_target_number_of_work_days", //identical
        region("total_targets") as "region_total_targets",
        nation("target_calls") as "nation_target_calls",
        nation("targets_called") as "nation_number_of_targets_called",
        nation("total_prescriber_calls") as "nation_total_prescriber_calls",
        nation("number_working_days") as "nation_number_of_work_days",
        nation("targets_called") as "nation_call_count", // identical
        nation("number_working_days") as "nation_target_number_of_work_days", //identical
        nation("total_targets") as "nation_total_targets"
      )
  }
}
