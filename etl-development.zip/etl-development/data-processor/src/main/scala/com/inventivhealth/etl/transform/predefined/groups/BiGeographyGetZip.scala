package com.inventivhealth.etl.transform.predefined.groups


import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

class BiGeographyGetZip extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biGeoGetZip"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val tenantId = parameters(ETLProcess.tenantIdParam)
    val sqlContext = df.sqlContext

    // d_account_location
    val accLocDataExtractor = getDataExtractor(sourceName, "d_account_location", false)
    var accLocDf = accLocDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (accLocDf.schema.fieldNames.contains("active_inactive"))  {
      accLocDf = accLocDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }

    // order by prmry_adrs, veeva_id and get only first row
    accLocDf = accLocDf
      .withColumn("r_n",
        row_number()
          .over(Window.partitionBy("accnt_id").orderBy(col("prmry_adrs").desc, col("veeva_id"))))
      .where(col("r_n") === lit(1))
      .select("accnt_id", "geo_zip_cd")

    val replaceEmptyString = udf { (in: String) =>
      if (in == null || in.isEmpty) "N/A" else in
    }

    // join with account_location to get zip
    val res = df.join(accLocDf, df("accnt_id") === accLocDf("accnt_id"), "left_outer")
      .select(df("*"), accLocDf("geo_zip_cd") as "zip")

    res.withColumn("zip", replaceEmptyString(col("zip")))
  }
}