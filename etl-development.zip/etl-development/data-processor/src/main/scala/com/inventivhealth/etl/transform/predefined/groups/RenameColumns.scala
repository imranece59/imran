package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame

class RenameColumns extends GroupOperation {
  override val name: String = "renameColumns"

  private final val columns = "columns"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    operationParams.get(columns).map { str =>
      val cols = str.replace(">", ":").split(",").map(_.trim)
      cols.foldLeft(df) { (frame, c) => frame.withColumnRenamed(c.split(":")(0), c.split(":")(1)) }
    }.getOrElse(df)
  }
}
