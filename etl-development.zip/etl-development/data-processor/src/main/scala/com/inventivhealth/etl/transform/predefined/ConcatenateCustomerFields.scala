package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction3
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class ConcatenateCustomerFields extends EtlFunction3[String, String, String, String] {
  override val name: String = "concatCustFlds"

  override def execute(l: String, f: String, m: String): String = {
    if (l == null) {
      null
    } else {
      val a = l.trim
      val b = f.trim
      val c = m.trim
      s"$a,$b $c"
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
