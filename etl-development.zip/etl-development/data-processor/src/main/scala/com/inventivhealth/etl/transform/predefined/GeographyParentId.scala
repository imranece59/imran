package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class GeographyParentId extends EtlFunction1[String, String] {
  override val name: String = "geographyParentId"

  override def execute(s: String): String = {
    if (s == null) null
    else {
        val t = parameters(ETLProcess.tenantIdParam).asInstanceOf[Int]
      s"$t:$s"
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
