package com.inventivhealth.etl.transform.api

import scala.collection.mutable

trait CellValidation[S1]
  extends EtlFunction4[S1, String, String, mutable.WrappedArray[(S1, String, String)], List[(S1, String, String)]]
    with EtlFunction3[S1, String, String, Option[String]] {

  override def execute(value: S1, name: String, arg: String,
                       accumulator: mutable.WrappedArray[(S1, String, String)]): List[(S1, String, String)] = {
    val reason = execute(value, name, arg)
    if (reason.isDefined) {
      if (accumulator == null)
        (value, name, reason.get) :: Nil
      else
        (value, name, reason.get) :: accumulator.toList
    } else {
      if (accumulator == null) null
      else accumulator.toList
    }
  }

}
