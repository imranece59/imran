package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame

class CountCount extends GroupOperation{
  override val name: String = "countcount"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    df.cache()
    println(s"count -> ${df.count()}")
    df
  }
}
