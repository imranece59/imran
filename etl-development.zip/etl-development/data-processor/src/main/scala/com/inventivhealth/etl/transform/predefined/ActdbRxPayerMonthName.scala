package com.inventivhealth.etl.transform.predefined

import java.sql.Date
import java.text.SimpleDateFormat

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import org.apache.commons.lang3.StringUtils

import scala.util.{ Failure, Success, Try }

class ActdbRxPayerMonthName extends EtlFunction1[String, String] {
  override val name: String = "actdbRxPayerMonthName"

  override def execute(source: String): String = {
    val inFormat = new SimpleDateFormat("yyyyMM")
    val outFormat = new SimpleDateFormat("MMM yyyy")

    if (StringUtils.isBlank(source)) ""
    else {
      val d1 = inFormat.parse(source)
      outFormat.format(d1)
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
