package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.inventivhealth.etl.actdb._

class ActdbGroupBy extends GroupOperation {

  override val name: String = "actdbGroupBy"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val res = if (operationParams("aggCols").contains("("))
      new1(df, operationParams)
    else
      old1(df, operationParams)

    if (operationParams.contains("outputPersistKey"))
      ActdbHelper.persistDf(operationParams("outputPersistKey"), res)

    res

  }

  def new1(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val groupByCols = operationParams("groupBy").split(",").map(df(_))

    val aggComputations = getAggCols(operationParams("aggCols").split(";").map(_.trim))

    df.groupBy(groupByCols: _*).
      agg(aggComputations.take(1)(0), aggComputations.drop(1): _*)

  }

  def old1(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val groupByCols = operationParams("groupBy").split(",").map(df(_))

    val aggCols = scala.collection.mutable.Map[String, String]()
    operationParams("aggCols").split(";").foreach(v =>
      aggCols(v.split(">")(0)) = v.split(">")(1))

    val aggComputeMap = scala.collection.mutable.Map[String, String]()
    aggCols.foreach(v => aggComputeMap(v._1) = "sum")

    val colRenameMap = scala.collection.mutable.Map[String, String]()
    aggCols.foreach(v => colRenameMap("sum(" + v._1 + ")") = v._2)

    val df1 = df.groupBy(groupByCols: _*).agg(aggComputeMap.toMap)

    colRenameMap.foldLeft(df1) { (frame, c) => frame.withColumnRenamed(c._1, c._2) }

  }

  def getAggCols(aggCols: Array[String]) = {

    aggCols.map(c => {

      val parts1 = c.split(">").map(_.trim)
      val colName = parts1(0).replace("\\)", "").split("\\(")(1).split("\\)")(0).trim
      val funcName = parts1(0).split("\\(")(0).trim

      funcName.toLowerCase match {
        case "sum"           => sum(colName).alias(parts1(1))
        case "max"           => max(colName).alias(parts1(1))
        case "min"           => min(colName).alias(parts1(1))
        case "count"         => count(colName).alias(parts1(1))
        case "avg"           => count(colName).alias(parts1(1))
        case "countdistinct" => countDistinct(colName).alias(parts1(1))
        case "sumdistinct"   => sumDistinct(colName).alias(parts1(1))
      }
    })

  }

}

class ActdbGroupByAs1 extends ActdbGroupBy {
  override val name: String = "actdbGroupByAs1"
}

class ActdbGroupByAs2 extends ActdbGroupBy {
  override val name: String = "actdbGroupByAs2"
}

class ActdbGroupByAs3 extends ActdbGroupBy {
  override val name: String = "actdbGroupByAs3"
}

class ActdbGroupByAs4 extends ActdbGroupBy {
  override val name: String = "actdbGroupByAs4"
}

class ActdbGroupByAs5 extends ActdbGroupBy {
  override val name: String = "actdbGroupByAs5"
}
