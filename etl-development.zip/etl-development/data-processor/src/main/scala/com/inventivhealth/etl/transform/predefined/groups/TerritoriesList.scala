package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.databricks.spark.csv

class TerritoriesList extends GroupOperation {
  override val name: String = "generateTerritoriesList"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val nonDuplicates = df.dropDuplicates()
    nonDuplicates.registerTempTable("dfTemp")
    val sc = df.sqlContext
    val terrList = sc.sql("""
    SELECT generated_id,oprn,
           collect_list(terr) AS terrs           
    FROM dfTemp
    GROUP BY generated_id,oprn""")
    
    val terrsDf = nonDuplicates.join(terrList,nonDuplicates("generated_id") === terrList("generated_id")
                         && nonDuplicates("oprn") === terrList("oprn"), "left_outer")
                        .select(nonDuplicates("*"),terrList("terrs"))
                        .drop("terr")   
                        .dropDuplicates(Array("generated_id","oprn"))    
    
    val listToString = udf((a:Seq[String]) => a.mkString(";"))
    val allOprnList = terrsDf.withColumn("terrs", listToString(col("terrs")))    
    val addTerr = allOprnList.filter(col("oprn")==="A").withColumnRenamed("terrs", "territory_to_add_vod_c").drop("oprn")
    val dropTerr = allOprnList.filter(col("oprn")==="D").withColumnRenamed("terrs", "territory_to_drop_vod_c").drop("oprn")
    val addLeftJoin = addTerr.join(dropTerr,
                        addTerr("generated_id") === dropTerr("generated_id"), "left_outer")
                        .select(addTerr("*"),dropTerr("territory_to_drop_vod_c"))                        
    val dropLeftJoin = dropTerr.join(addTerr,
                        dropTerr("generated_id") === addTerr("generated_id"), "left_outer")
                        .select(dropTerr("*"),addTerr("territory_to_add_vod_c"))
                        
   val resultDf = unionAllByName(addLeftJoin, dropLeftJoin).dropDuplicates(Array("generated_id"))   
   resultDf
  }  
  
  def unionAllByName(a: DataFrame, b: DataFrame): DataFrame = {
    val columns = a.columns.toSet.intersect(b.columns.toSet).map(col).toSeq
    a.select(columns: _*).unionAll(b.select(columns: _*))
  }
}
