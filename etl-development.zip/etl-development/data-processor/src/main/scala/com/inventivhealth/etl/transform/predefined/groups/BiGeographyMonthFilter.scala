package com.inventivhealth.etl.transform.predefined.groups

import java.sql.Timestamp
import java.time.{LocalDate, YearMonth, ZoneOffset}
import java.time.format.DateTimeFormatter

import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import com.inventivhealth.etl.transform.api.GroupObject
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

import scala.util.{Failure, Success, Try}

class BiGeographyMonthFilter extends GroupOperation {
  override val name: String = "biGeoMonthFilter"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]
  val emptyDate = "30000101"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val sparkContext = df.sqlContext.sparkContext

    // resolve month timestamp and date
    val getMonthInfo = udf { (moId: String) =>
      val monthFormat = DateTimeFormatter.ofPattern("yyyyMM")
      val dateFormat = DateTimeFormatter.ofPattern("yyyyMMdd")
      val date = YearMonth.parse(moId, monthFormat).atDay(1).atStartOfDay(ZoneOffset.UTC)
      val timestamp = new Timestamp(date.toInstant.toEpochMilli)
      val monthDate = date.format(dateFormat).toInt

      (timestamp, monthDate)
    }

    // add month timestamp and date
    var tsDf = df
      .withColumn("month_info", getMonthInfo(col("mo_id")))
      .withColumn("month_timestamp" , col("month_info._1"))
      .withColumn("month_date", col("month_info._2"))
      .drop("month_info")

    // max month date from source
    val maxRow = tsDf.select(max("month_date") as "max_month").take(1)
    val maxMonth = Try(maxRow(0).getInt(0).toString) match {
      case Success(t) => t
      case Failure(_) => emptyDate
    }

    // month date 7 months ago from maxMonth
    val format = DateTimeFormatter.ofPattern("yyyyMMdd")
    val date = LocalDate.parse(maxMonth, format).atStartOfDay(ZoneOffset.UTC).minusMonths(6)
    val startMonthDay = date.format(format)
    val startMonthDayTs = new Timestamp(date.toInstant.toEpochMilli)

    GroupObject.broadcasts = sparkContext.broadcast(Map("start_month" -> startMonthDay))

    // take only last 7 months
    tsDf.where(col("month_timestamp") >= lit(startMonthDayTs)).drop("month_timestamp")
  }
}