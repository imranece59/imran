package com.inventivhealth.etl.persist

/**
  * Enumeration for supported data targets for ETL framework
  */
object DataTargets extends Enumeration {

  type DataTargets = Value

  val s3, local, ods, bi = Value

}
