package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class MarketSegmentLkp extends GroupOperation {
  override val name: String = "mkSegLkp"
  override def execute(inputdf: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import inputdf.sqlContext.implicits._
    val tenantId = parameters(ETLProcess.tenantIdParam)
    val dataExtr = new CassandraDataExtractor("ods", "d_market_segment")
    val msegDf = dataExtr.extractData(inputdf.sqlContext).where(col("tenant_id").equalTo(tenantId)).cache()

    val tempDf = inputdf.as("t1").join(msegDf.as("t2"),
      inputdf("mkt_id") === msegDf("mkt_id")
      && inputdf("fin_brnd_id") === msegDf("fin_brnd_id"),
      "inner").select($"t1.*",$"t2.product".as("prdct_nm"), $"t2.rstrctd_prd".as("accnt_rstrctn_1"))
    tempDf.drop("mkt_id").drop("fin_brnd_id")
  }
}