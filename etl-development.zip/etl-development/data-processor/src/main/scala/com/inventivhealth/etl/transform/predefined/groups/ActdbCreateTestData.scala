package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils
import com.inventivhealth.etl.actdb._

class ActdbCreateTestData extends GroupOperation {

  override val name: String = "actdbDebug"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    var d1 = if (operationParams.contains("where"))
      df.where(operationParams("where"))
    else
      df

    if (operationParams.contains("limit"))
      d1.limit(operationParams("limit").toInt)
    else
      d1

  }
}
