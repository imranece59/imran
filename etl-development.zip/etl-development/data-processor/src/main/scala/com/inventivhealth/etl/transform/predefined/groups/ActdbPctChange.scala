package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils

class ActdbPctChange extends GroupOperation {

  override val name: String = "actdbPctChange"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val currCol = df(operationParams("curr"))
    val prevCol = df(operationParams("prev"))
    val outputCol = operationParams("output")

    def computeRatio(curr: String, prev: String) =
      {
        if (StringUtils.isBlank(curr) || StringUtils.isBlank(prev)) 1
        else if (prev.toDouble == 0D) 1
        else (curr.toDouble - prev.toDouble) / prev.toDouble
      }

    val computeRatioUDF = udf(computeRatio(_: String, _: String))
    df.withColumn(outputCol, computeRatioUDF(currCol, prevCol))

  }

}

class ActdbPctChangeAs1 extends ActdbPctChange {
  override val name: String = "actdbPctChangeAs1"
}

class ActdbPctChangeAs2 extends ActdbPctChange {
  override val name: String = "actdbPctChangeAs2"
}

class ActdbPctChangeAs3 extends ActdbPctChange {
  override val name: String = "actdbPctChangeAs3"
}

class ActdbPctChangeAs4 extends ActdbPctChange {
  override val name: String = "actdbPctChangeAs4"
}

class ActdbPctChangeAs5 extends ActdbPctChange {
  override val name: String = "actdbPctChangeAs5"
}

class ActdbPctChangeAs6 extends ActdbPctChange {
  override val name: String = "actdbPctChangeAs6"
}

class ActdbPctChangeAs7 extends ActdbPctChange {
  override val name: String = "actdbPctChangeAs7"
}
