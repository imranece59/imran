package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils

class ExplodeAccountTerritory extends GroupOperation {
  override val name: String = "explodeAccntTerritory"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val toArray = udf { (Territories: String) =>
      val ip = Territories.split(";").filter(_.trim() != "")
      ip zip (0 until ip.length).map("optimus" + _)
    }
    val newDf = df
      .withColumn("Territory_IDs", toArray(col("Territory_vod__c")))
      .withColumn("terriroty_id_struct", explode(col("Territory_IDs")))
      .drop("Territory_IDs")
      .select(df("*"), col("terriroty_id_struct.*"))      
      .drop("_2")
      .withColumnRenamed("_1", "territoryId")
    newDf

  }
}

