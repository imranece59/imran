package com.inventivhealth.etl.transform.predefined.groups

import java.sql.Timestamp
import java.time.{LocalDate, ZoneOffset}

import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import com.inventivhealth.etl.bi._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class BISalesRegionAggregation extends GroupOperation {

  override val name: String = "biSalesRegionAggregation"

  val cacheParam = "cache"
  val minusMonthsParam = "minusMonths"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._

    if (operationParams.get(cacheParam).exists(_.toBoolean)) {
      df.cache()
      df.count()
    }

    val distDistinct = df.dropDuplicates(
      Seq("tenant_id", "st_id", "accnt_id", "fin_brnd_id", "mkt_pid", "district_name", "region_name", "metric_type", "month_id", "segment_type", "segment", "target", "rx_vol"))

    val distBrandRxWindow = Window.partitionBy("tenant_id", "st_id", "brand_name", "market_name", "region_name", "district_name", "metric_type", "segment_type", "segment", "target").orderBy("month_start")
    val distBrandRx = distDistinct.
      groupBy("tenant_id", "st_id", "brand_name", "market_name", "region_name", "district_name", "metric_type", "month_id", "segment_type", "segment", "target").
      agg(sum($"rx_vol") as "district_brand_rx", first("month_start") as "month_start", first("month_name") as "month_name").
      withColumn("district_prev_brand_rx", lag($"district_brand_rx", 1).over(distBrandRxWindow)).
      withColumn("prev_month_start", lag($"month_start", 1).over(distBrandRxWindow)).
      withColumn("district_prev_brand_rx", when($"district_prev_brand_rx".isNotNull, $"district_prev_brand_rx").otherwise(0)).
      withColumn("district_prev_brand_rx", previousMonthRx($"prev_month_start", $"month_start", $"district_prev_brand_rx"))

    val distMarketRxWindow = Window.partitionBy("tenant_id", "st_id", "market_name", "region_name", "district_name", "metric_type", "segment_type", "segment", "target").orderBy("month_start")
    val distMarketRx = distDistinct.
      groupBy("tenant_id", "st_id", "market_name", "region_name", "district_name", "metric_type", "month_id", "segment_type", "segment", "target").
      agg(sum($"rx_vol") as "district_market_rx", first("month_start") as "month_start", first("month_name") as "month_name").
      withColumn("district_prev_market_rx", lag($"district_market_rx", 1).over(distMarketRxWindow)).
      withColumn("prev_month_start", lag($"month_start", 1).over(distMarketRxWindow)).
      withColumn("district_prev_market_rx", when($"district_prev_market_rx".isNotNull, $"district_prev_market_rx").otherwise(0)).
      withColumn("district_prev_market_rx", previousMonthRx($"prev_month_start", $"month_start", $"district_prev_market_rx"))

    val regionDistinct = df.dropDuplicates(
      Seq("tenant_id", "st_id", "accnt_id", "fin_brnd_id", "mkt_pid", "region_name", "metric_type", "month_id", "segment_type", "segment", "target", "rx_vol"))

    val regBrandRxWindow = Window.partitionBy("tenant_id", "st_id", "brand_name", "market_name", "region_name", "metric_type", "segment_type", "segment", "target").orderBy("month_start")
    val regionBrandRx = regionDistinct
      .groupBy("tenant_id", "st_id", "brand_name", "market_name", "region_name", "metric_type", "month_id", "segment_type", "segment", "target")
      .agg(sum($"rx_vol") as "region_brand_rx", first("month_start") as "month_start", first("month_name") as "month_name")
      .withColumn("region_prev_brand_rx", lag($"region_brand_rx", 1).over(regBrandRxWindow))
      .withColumn("prev_month_start", lag($"month_start", 1).over(regBrandRxWindow))
      .withColumn("region_prev_brand_rx", when($"region_prev_brand_rx".isNotNull, $"region_prev_brand_rx").otherwise(0))
      .withColumn("region_prev_brand_rx", previousMonthRx($"prev_month_start", $"month_start", $"region_prev_brand_rx"))

    val regMarketRxWindow = Window.partitionBy("tenant_id", "st_id", "market_name", "region_name", "metric_type", "segment_type", "segment", "target").orderBy("month_start")
    val regionMarketRx = regionDistinct
      .groupBy("tenant_id", "st_id", "market_name", "region_name", "metric_type", "month_id", "segment_type", "segment", "target")
      .agg(sum($"rx_vol") as "region_market_rx", first("month_start") as "month_start", first("month_name") as "month_name")
      .withColumn("region_prev_market_rx", lag($"region_market_rx", 1).over(regMarketRxWindow))
      .withColumn("prev_month_start", lag($"month_start", 1).over(regMarketRxWindow))
      .withColumn("region_prev_market_rx", when($"region_prev_market_rx".isNotNull, $"region_prev_market_rx").otherwise(0))
      .withColumn("region_prev_market_rx", previousMonthRx($"prev_month_start", $"month_start", $"region_prev_market_rx"))

    val months = operationParams.get(minusMonthsParam).map(_.toInt).getOrElse(6)
    val date =
      if (GroupObject.broadcasts == null || GroupObject.broadcasts.value.get("max_date").isEmpty) {
        LocalDate.now()
      } else {
        val millis = GroupObject.broadcasts.value("max_date").toLong
        new Timestamp(millis).toLocalDateTime.toLocalDate
      }
    val filterDate = new Timestamp(date.atStartOfDay().minusMonths(months).toInstant(ZoneOffset.UTC).toEpochMilli)

    distBrandRx.where($"month_start" >= lit(filterDate))
      .join(distMarketRx, Seq("tenant_id", "st_id", "market_name", "region_name", "district_name", "metric_type", "month_id", "segment_type", "segment", "target"))
      .join(regionBrandRx, Seq("tenant_id", "st_id", "brand_name", "market_name", "region_name", "metric_type", "month_id", "segment_type", "segment", "target"))
      .join(regionMarketRx, Seq("tenant_id", "st_id", "market_name", "region_name", "metric_type", "month_id", "segment_type", "segment", "target"))
      .select(distBrandRx("*"),
        distMarketRx("district_market_rx"), distMarketRx("district_prev_market_rx"),
        regionBrandRx("region_brand_rx"), regionBrandRx("region_prev_brand_rx"),
        regionMarketRx("region_market_rx"), regionMarketRx("region_prev_market_rx"))
      .drop("month_start")
      .drop("prev_month_start")
      .withColumn("district_brand_rx_perc_change", brandRxPercentChange($"district_brand_rx", $"district_prev_brand_rx"))
      .withColumn("region_brand_rx_perc_change", brandRxPercentChange($"region_brand_rx", $"region_prev_brand_rx"))
      .withColumn("district_market_rx_change", marketRxChange($"district_market_rx", $"district_prev_market_rx"))
      .withColumn("region_market_rx_change", marketRxChange($"region_market_rx", $"region_prev_market_rx"))
      .withColumn("district_market_share", marketShare($"district_brand_rx", $"district_market_rx"))
      .withColumn("region_market_share", marketShare($"region_brand_rx", $"region_market_rx"))
      .withColumn("district_market_share_change", marketShareChange($"district_brand_rx", $"district_market_rx", $"district_prev_brand_rx", $"district_prev_market_rx"))
      .withColumn("region_market_share_change", marketShareChange($"region_brand_rx", $"region_market_rx", $"region_prev_brand_rx", $"region_prev_market_rx"))
  }

}
