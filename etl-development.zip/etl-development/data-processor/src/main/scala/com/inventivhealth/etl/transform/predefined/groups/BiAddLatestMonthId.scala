package com.inventivhealth.etl.transform.predefined.groups

import java.time.YearMonth
import java.time.format.{DateTimeFormatter, TextStyle}
import java.util.Locale
import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType

class BiAddLatestMonthId extends GroupOperation {
  override val name: String = "biAddLatestMonthId"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val sparkContext = df.sqlContext.sparkContext

    val maxMonthId = df.agg(max($"mo_id".cast(IntegerType)) as "month_id_max").collect()(0).getInt(0).toString
    val monthMaxName = (moId: String) => {
      val formatter = DateTimeFormatter.ofPattern("yyyyMM")
      val date = YearMonth.parse(moId, formatter)
      val monthName = date.getMonth.getDisplayName(TextStyle.SHORT, Locale.getDefault)
      s"$monthName ${date.getYear}"
    }

    GroupObject.broadcasts = sparkContext.broadcast(Map("maxMonthId" -> maxMonthId))

    df.withColumn("month_id", lit(maxMonthId))
      .withColumn("month_name", lit(monthMaxName(maxMonthId)))
  }

}
