package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.actdb._
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils

class ActdbComputePct extends GroupOperation {

  override val name: String = "actdbComputePct"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val numCol = df(operationParams("num"))
    val denCol = df(operationParams("den"))
    val outputCol = operationParams("output")

    def computeRatio(num: String, den: String) =
      {
        if (StringUtils.isBlank(num) || StringUtils.isBlank(den)) 0
        else if (num.toDouble == 0D) 0
        else if (den.toDouble == 0D) 1
        else (num.toDouble / den.toDouble)
      }

    val computeRatioUDF = udf(computeRatio(_: String, _: String))
    df.withColumn(outputCol, computeRatioUDF(numCol, denCol))

  }
}

class ActdbComputePctAs1 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs1"
}

class ActdbComputePctAs2 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs2"
}

class ActdbComputePctAs3 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs3"
}

class ActdbComputePctAs4 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs4"
}

class ActdbComputePctAs5 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs5"
}

class ActdbComputePctAs6 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs6"
}

class ActdbComputePctAs7 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs7"
}

class ActdbComputePctAs8 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs8"
}

class ActdbComputePctAs9 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs9"
}

class ActdbComputePctAs10 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs10"
}

class ActdbComputePctAs11 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs11"
}

class ActdbComputePctAs12 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs12"
}

class ActdbComputePctAs13 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs13"
}

class ActdbComputePctAs14 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs14"
}

class ActdbComputePctAs15 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs15"
}

class ActdbComputePctAs16 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs16"
}

class ActdbComputePctAs17 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs17"
}

class ActdbComputePctAs18 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs18"
}

class ActdbComputePctAs19 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs19"
}

class ActdbComputePctAs20 extends ActdbComputePct {
  override val name: String = "actdbComputePctAs20"
}
