package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import java.util.Date
import java.text.SimpleDateFormat
import org.apache.commons.lang.time.DateUtils
import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import org.apache.spark.sql.expressions.Window
import java.text.DateFormatSymbols;

class BIWebTopTowHundYtd extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biWebTopTwoHundYtd"
    
  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = { 
    import df.sqlContext.implicits._
    
    val currYearMonth = df.agg({"month_id"->"max"}).head().getInt(0)
          
    /* Getting YTD start month */  
    val currYear = currYearMonth.toString().substring(0, 4)
    val currMonth = currYearMonth.toString().substring(4,6)
    val sMonthYtd = Integer.parseInt(currYear.concat("01"))    
    
    val shortMonths = new DateFormatSymbols().getShortMonths();    
    val monthName = shortMonths.apply(Integer.parseInt(currMonth)-1)+" "+currYear.toString
   
    val ytdDf = df.filter(df("month_id").between(sMonthYtd, currYearMonth))
    
    /* aggregating district level rx */
    
    val calcTotalDistrictRx = udf((a:Double) => a/2) //as we transposed segment and segment type into two rows */
    val distLevelTotalRx  = ytdDf.groupBy("district_name").agg("rx"->"sum")
                            .withColumn("total_district_rx",calcTotalDistrictRx(col("sum(rx)")))                            
                            .filter(col("total_district_rx")!==0)
    
    val groupByCols = Array("tenant_id","accnt_id","st_id","brand_name","segment","segment_type","territory_name",
        "district_name","region_name","nation_name","address","city","customer_full_name","state","zip")
        
    val colNames = groupByCols.map(name=>col(name))
    
    /* aggregating brand_rx for ytd */
    val ytdAgg = ytdDf.groupBy(colNames:_*)
        .agg("rx" -> "sum").withColumnRenamed("sum(rx)", "brand_rx")
        .filter(col("brand_rx")!==0)
        
    val dfWithTotals = ytdAgg.join(distLevelTotalRx,
                        ytdAgg("district_name") === distLevelTotalRx("district_name"), "left_outer")
                        .select(ytdAgg("*"),distLevelTotalRx("total_district_rx"))
    
    /* ranking top 400 -  Distinct are only 200, as we transposed segment and segment type into two rows */
    val w = Window.partitionBy("district_name").orderBy(desc("brand_rx"))    
    val rankedDf = dfWithTotals.withColumn("rank",rank.over(w)).where("rank<=400")
    
    /* calculating market share */
    val calculateMktShare = udf((a:Double,b:Double) => a/b)
    val mktShareDf = rankedDf.withColumn("market_share", calculateMktShare(col("brand_rx"),col("total_district_rx")))
                  .withColumn("month_id", lit(currYearMonth))
                  .withColumn("month_name", lit(monthName))
                  .withColumnRenamed("brand_rx","rx")
                  .drop("rank")
                  .drop("total_district_rx")
                      
   mktShareDf
  }
}