package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils
import com.inventivhealth.etl.actdb._
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess

class ActdbWebAccountNationPeriod3 extends GroupOperation {

  override val name: String = "actdbWebAccountNationPeriod3"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val brandRxGroupBy =
      "tenant_id,st_id,market_name,brand_name,territory_name,target,plan,payment_type,customer_full_name,month_id,month_name,segment,segment_type".
        split(",")

    val marketRxGroupBy =
      "market_name,territory_name,month_id,month_name,segment,segment_type,target,customer_full_name,plan,payment_type".
        split(",")

    val pctBusDenGroupBy =
      "market_name,brand_name,territory_name,month_id,month_name,segment,segment_type,target,customer_full_name".
        split(",")

    val brandPartition =
      "market_name,brand_name,territory_name,segment,segment_type,plan,payment_type,target,customer_full_name".
        split(",")

    val marketPartition =
      "territory_name,segment,segment_type,plan,payment_type,target,customer_full_name".
        split(",")

    val wBrand = Window.partitionBy(brandPartition(0), brandPartition.drop(1): _*).orderBy("month_id")
    val dfBrand = df.
      groupBy(brandRxGroupBy.map(df(_)): _*).
      agg(sum("nrx_vol").alias("nbrx_brand"), sum("trx_vol").alias("trx_brand")).
      withColumn("prev_nbrx_brand", lag("nbrx_brand", 1).over(wBrand)).
      withColumn("prev_trx_brand", lag("trx_brand", 1).over(wBrand))

    ActdbHelper.persistDf("primary", dfBrand)

    if (operationParams.contains("bWhere"))
      dfBrand.where(operationParams("bWhere")).show(5000)

    val wMarket = Window.partitionBy(marketPartition(0), marketPartition.drop(1): _*).orderBy("month_id")
    val dfMarket = dfBrand.
      groupBy(marketRxGroupBy.map(dfBrand(_)): _*).
      agg(sum("nbrx_brand").alias("nbrx_market"), sum("trx_brand").alias("trx_market")).
      withColumn("prev_nbrx_market", lag("nbrx_market", 1).over(wMarket)).
      withColumn("prev_trx_market", lag("trx_market", 1).over(wMarket)).
      withColumn("pterritory_name", lag("territory_name", 1).over(wMarket)).
      withColumn("psegment", lag("segment", 1).over(wMarket)).
      withColumn("psegment_type", lag("segment_type", 1).over(wMarket)).
      withColumn("pplan", lag("plan", 1).over(wMarket)).
      withColumn("ppayment_type", lag("payment_type", 1).over(wMarket)).
      withColumn("pcustomer_full_name", lag("customer_full_name", 1).over(wMarket)).
      withColumn("ptarget", lag("target", 1).over(wMarket))

    val dfBusD = dfBrand.
      groupBy(pctBusDenGroupBy.map(dfBrand(_)): _*).
      agg(sum("nbrx_brand").alias("nbrx_bus"), sum("trx_brand").alias("trx_bus"))

    var res = ActdbHelper.leftOuterJoin(dfBrand, dfMarket, marketRxGroupBy,
      Array("nbrx_market", "trx_market", "prev_nbrx_market", "prev_trx_market"))

    res = ActdbHelper.leftOuterJoin(res, dfBusD, pctBusDenGroupBy, Array("nbrx_bus", "trx_bus"))

    ActdbHelper.persistDf("primary", res)

    if (operationParams.contains("fWhere"))
      res.where(operationParams("fWhere")).show(5000)

    res
  }

}