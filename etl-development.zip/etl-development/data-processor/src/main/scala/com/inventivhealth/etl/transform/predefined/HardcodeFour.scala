package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.UserDefinedFunction

class HardcodeFour extends EtlFunction0[Int] {
  override val name: String = "hardcodeFour"
  override def execute(): Int = 4
  override def createUdf: UserDefinedFunction = udf { execute _ }
}
