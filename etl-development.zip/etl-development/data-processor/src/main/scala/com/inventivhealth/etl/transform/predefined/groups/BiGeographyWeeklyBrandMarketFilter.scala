package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class BiGeographyWeeklyBrandMarketFilter extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biGeoWeekBrandMarketFilter"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]
  private val marketsParam = "markets"
  private val brandsParam = "brands"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val tenantId = parameters(ETLProcess.tenantIdParam)
    val sqlContext = df.sqlContext
    val sparkContext = sqlContext.sparkContext

    val marketDefDataExtractor = getDataExtractor(sourceName, "d_market_def", false)
    var marketDefDf = marketDefDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (marketDefDf.schema.fieldNames.contains("active_inactive"))  {
      marketDefDf = marketDefDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }
    marketDefDf = marketDefDf.select("market_id", "market_name")

    val brandDataExtractor = getDataExtractor(sourceName, "d_brand", false)
    var brandDf = brandDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (brandDf.schema.fieldNames.contains("active_inactive"))  {
      brandDf = brandDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }
    brandDf = brandDf
      .select("src_brand_id", "brand_name")
      .withColumn("src_brand_id", when(col("src_brand_id").isNull, lit("")).otherwise(col("src_brand_id")))

    val bc = sparkContext.broadcast(Map("d_market_def" -> marketDefDf.collect(), "d_brand" -> brandDf.collect()))

    val getBrandName = udf {(brandId: String) =>
      bc.value.get("d_brand").flatMap {
        _.filter(row => row.getAs[String]("src_brand_id").equals(brandId))
          .map(_.getAs[String]("brand_name"))
          .headOption
      }.orNull
    }

    val getMarketName = udf {(marketId: String) =>
      bc.value.get("d_market_def").flatMap {
        _.filter(row => row.getAs[String]("market_id").equals(marketId))
          .map(_.getAs[String]("market_name"))
          .headOption
      }.orNull
    }

    val brands = operationParams.get(brandsParam).map(brand => brand.split(",").map(_.trim.toUpperCase)).get
    val markets = operationParams.get(marketsParam).map(market => market.split(",").map(_.trim.toUpperCase)).get

    df.withColumn("brand_name", getBrandName(col("fin_brnd_id")))
      .withColumn("market_name", getMarketName(col("mkt_pid")))
      .where(col("brand_name").isin(brands:_*) && col("market_name").isin(markets:_*))
  }
}