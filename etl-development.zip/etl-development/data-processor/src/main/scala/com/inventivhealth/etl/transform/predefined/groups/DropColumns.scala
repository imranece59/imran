package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame

class DropColumns extends GroupOperation {
  override val name: String = "dropColumns"

  private final val columns = "columns"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    operationParams.get(columns).map { str =>
      val cols = str.split(",").map(_.trim)
      cols.foldLeft(df) { (frame, c) => frame.drop(c) }
    }.getOrElse(df)
  }
}
