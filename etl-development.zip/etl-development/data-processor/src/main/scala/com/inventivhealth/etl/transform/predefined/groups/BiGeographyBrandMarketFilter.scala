package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

import scala.util.{Failure, Success, Try}

class BiGeographyBrandMarketFilter extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biGeoBrandMarketFilter"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]
  private val marketsParam = "markets"
  private val brandsParam = "brands"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val tenantId = parameters(ETLProcess.tenantIdParam)
    val sqlContext = df.sqlContext
    val sparkContext = sqlContext.sparkContext

    val marketDefDataExtractor = getDataExtractor(sourceName, "d_market_def", false)
    var marketDefDf = marketDefDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (marketDefDf.schema.fieldNames.contains("active_inactive"))  {
      marketDefDf = marketDefDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }
    marketDefDf = marketDefDf.select("market_id", "market_name")

    val productSalesDataExtractor = getDataExtractor(sourceName, "d_product_sales_calls", false)
    var productSalesDf = productSalesDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (productSalesDf.schema.fieldNames.contains("active_inactive"))  {
      productSalesDf = productSalesDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }
    productSalesDf = productSalesDf.select("product_id", "brand_id")

    val bc = sparkContext.broadcast(Map("d_market_def" -> marketDefDf.collect(), "d_product_sales_calls" -> productSalesDf.collect()))

    val getBrandName = udf {(brandId: String) =>
      bc.value.get("d_product_sales_calls").flatMap {
        _.filter(row => row.getAs[String]("product_id").equals(brandId))
          .map(_.getAs[String]("brand_id"))
          .headOption
      }.orNull
    }

    val getMarketName = udf {(marketId: String) =>
      bc.value.get("d_market_def").flatMap {
        _.filter(row => row.getAs[String]("market_id").equals(marketId))
          .map(_.getAs[String]("market_name"))
          .headOption
      }.orNull
    }

    val brands = operationParams.get(brandsParam).map(brand => brand.split(",").map(_.trim.toUpperCase)).get
    val markets = operationParams.get(marketsParam).map(market => market.split(",").map(_.trim.toUpperCase)).get

    df.withColumn("brand_name", getBrandName(col("fin_brnd_id")))
      .withColumn("market_name", getMarketName(col("mkt_pid")))
      .where(col("brand_name").isin(brands:_*) && col("market_name").isin(markets:_*))
  }
}