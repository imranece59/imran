package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.actdb._
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class ActdbJoin extends GroupOperation {

  override val name: String = "actdbJoin"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val ks = if (operationParams.contains("rKeyspace"))
      operationParams("rKeyspace")
    else
      "ods"

    val rightTable = operationParams("rTable").trim
    val leftCols = operationParams("lCols").split(",").map(_.trim)
    val rightCols = operationParams("rCols").split(",").map(_.trim)
    val retCols = operationParams("retCols").split(";").map(_.trim)

    // One of: inner, outer, left_outer, right_outer, leftsemi.
    val joinType = if (operationParams.contains("joinType"))
      operationParams("joinType")
    else
      "left_outer"

    var dfJoin = new CassandraDataExtractor(ks, rightTable).
      extractData(df.sqlContext).
      where(col("tenant_id") === lit(parameters(ETLProcess.tenantIdParam))).
      select()

    if (dfJoin.columns.contains("active_inactive"))
      dfJoin = dfJoin.where(col("active_inactive") === lit("ACTIVE"))

    if (operationParams.contains("rWhere"))
      dfJoin = dfJoin.where(operationParams("rWhere"))

    // rename computed columns to required ones
    dfJoin = rightCols.foldLeft(dfJoin) { (frame, c) => frame.withColumnRenamed(c, c + "_temp") }

    val joinCond = leftCols.zip(rightCols).map { case (s, l) => df(s) === dfJoin(l + "_temp") }.
      reduceLeft(_ && _)

    val retDfCols = retCols.map(v => {
      if (v.contains(">")) dfJoin(v.split(">")(0)).alias(v.split(">")(1))
      else dfJoin(v)
    }).toSeq
    val returnColumns = (df("*") +: retDfCols)

    df.join(dfJoin, joinCond, joinType).select(returnColumns: _*)

  }

}

class ActdbJoinAs1 extends ActdbJoin {
  override val name: String = "actdbJoinAs1"
}

class ActdbJoinAs2 extends ActdbJoin {
  override val name: String = "actdbJoinAs2"
}

class ActdbJoinAs3 extends ActdbJoin {
  override val name: String = "actdbJoinAs3"
}

class ActdbJoinAs4 extends ActdbJoin {
  override val name: String = "actdbJoinAs4"
}