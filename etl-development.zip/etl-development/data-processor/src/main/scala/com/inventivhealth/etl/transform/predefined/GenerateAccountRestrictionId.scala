package com.inventivhealth.etl.transform.predefined

import java.time.{LocalDate, ZoneOffset}
import java.time.format.DateTimeFormatter

import com.inventivhealth.etl.transform.api.EtlFunction5
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class GenerateAccountRestrictionId extends EtlFunction5[String, String, String, String, String, String] {
  override val name: String = "generateAccountRestrictionId"

  override def execute(cid: String, effectiveDate: String, markerId: String,
                       finBrandId: String, specGrpCode: String): String = {
    val dateStr = Option(effectiveDate).map { ed =>
      val formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd")
      val date = LocalDate.parse(effectiveDate, formatter)
      date.atStartOfDay(ZoneOffset.UTC).toInstant.toEpochMilli.toString
    }.getOrElse("null")

    s"$cid:$effectiveDate:$markerId:$finBrandId:$specGrpCode"
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
