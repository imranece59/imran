package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

import scala.util.{Failure, Success, Try}

class StringToLong extends EtlFunction1[String, Long] {
  override val name: String = "convertStringToLong"

  override def execute(s: String): Long = Try(s.toLong) match {
    case Success(v) => v
    case Failure(ex) => 0
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
