package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess

class YNForCustAttrib3InAccountAlignment extends GroupOperation {

  override val name: String = "YNForCustAttrib3InAccountAlignment"

  private final val columns = "columns"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    def checkYN(stId: String, accntId2: String) = {
      if (!StringUtils.isBlank(accntId2) && (stId == "179" || stId == "180")) "Y"
      else "N"
    }

    val checkYNUdf = udf(checkYN(_: String, _: String))

    var rDf = new CassandraDataExtractor("ods", "d_account_segment").extractData(df.sqlContext).
      where(col("tenant_id") === lit(parameters(ETLProcess.tenantIdParam))).
      where("sgmnt_id IN (1,2,3) AND accnt_sgmnt_attrb_4 != 'GSK' AND sgmnt_typ IN ('Advair','Tanzeum') ").
      select("accnt_id").distinct.withColumnRenamed("accnt_id", "accnt_id_temp")

    var df1 = df.join(rDf, df("accnt_id") === rDf("accnt_id_temp"), "left_outer")

    df1.withColumn("cust_attrib3", checkYNUdf(df1("st_id"), df1("accnt_id_temp"))).drop("accnt_id_temp")

    //df1

  }

}
