package com.inventivhealth.etl.extract

import com.inventivhealth.etl.config.model.ETLMapping
import org.apache.spark.sql.DataFrame

case class DataPart(data: DataFrame, mappings: List[ETLMapping], label: Option[String] = None)
