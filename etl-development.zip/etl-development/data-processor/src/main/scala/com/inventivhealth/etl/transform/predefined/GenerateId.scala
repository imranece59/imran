package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.process.ETLProcess.tenantIdParam
import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class GenerateId extends EtlFunction1[String, String] {
  override val name: String = "generateId"

  override def execute(source: String): String = {
    val tenantId = parameters(tenantIdParam).asInstanceOf[Int]
    s"$tenantId:${source.trim}"
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
