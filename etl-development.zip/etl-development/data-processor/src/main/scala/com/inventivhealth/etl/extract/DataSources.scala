package com.inventivhealth.etl.extract

/**
  * Enumeration for supported data sources for ETL framework
  */
object DataSources extends Enumeration {

  type DataSources = Value

  val s3, local, classPath, ods, bi = Value

}
