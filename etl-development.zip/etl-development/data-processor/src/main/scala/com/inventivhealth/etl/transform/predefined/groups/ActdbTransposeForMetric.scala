package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class ActdbTransposeForMetric extends GroupOperation {

  override val name: String = "actdbTransposeForMetric"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    // todo: we can refine this logic and make it more generic
    val df1 = df.selectExpr(operationParams("select1").split(","): _*)
    if (operationParams.contains("select2"))
      df1.unionAll(df.selectExpr(operationParams("select2").split(","): _*))
    else
      df1
  }
}
