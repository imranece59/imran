package com.inventivhealth.etl.extract

import org.apache.spark.sql.types.StructType

trait DataExtractorFactory {

  def getDataExtractor(sourceName: String, sourceEntityName: String, header: Boolean,
                       schema: Option[StructType] = None, delimiter: Option[String] = None, parserLib: String = "commons"): DataExtractor

}

trait DefaultDataExtractorFactory extends DataExtractorFactory {

  override def getDataExtractor(sourceName: String, sourceEntityName: String, header: Boolean,
                                schema: Option[StructType] = None, delimiter: Option[String] = None, parserLib: String = "commons"): DataExtractor = {
    DataSources.withName(sourceName) match {
      case DataSources.`s3` => new S3DataExtractor(sourceEntityName, schema, delimiter.getOrElse("^"), header, parserLib)
      case DataSources.`local` => new CSVDataExtractor(sourceEntityName, schema, delimiter.getOrElse("^"), header, parserLib)
      case DataSources.`ods` | DataSources.`bi` => new CassandraDataExtractor(sourceName, sourceEntityName)
      case _ => throw new IllegalArgumentException(s"Not supported data source $sourceName")
    }
  }

}
