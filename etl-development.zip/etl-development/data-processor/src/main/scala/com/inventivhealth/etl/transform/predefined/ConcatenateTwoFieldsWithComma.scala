package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction2
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class ConcatenateTwoFieldsWithComma extends EtlFunction2[String, String, String] {
  override val name: String = "concatTwoWithComma"
  override def execute(str1: String, str2: String): String = {
    if (str1 == null && str2 == null) {
       null
     } else {
          val f = str1.trim
          val s = str2.trim
          val fullAddr = s"$f,$s"
          if(fullAddr.charAt(fullAddr.length()-1).equals(',')){            
            fullAddr.substring(0, fullAddr.length()-1)
          }else{fullAddr}
        }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
