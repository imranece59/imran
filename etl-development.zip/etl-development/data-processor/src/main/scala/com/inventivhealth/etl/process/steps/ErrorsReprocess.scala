package com.inventivhealth.etl.process.steps

import com.inventivhealth.etl.config.ConfigComponent
import com.inventivhealth.etl.config.model.ETLMapping
import com.inventivhealth.etl.dao.ETLConfigComponent
import com.inventivhealth.etl.spark.SparkComponent
import com.inventivhealth.etl.transform.ETLFunctionsComponent
import com.inventivhealth.etl.util.FormattingUtil._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

trait ErrorsReprocess {
  this: ConfigComponent with ETLConfigComponent with SparkComponent with ETLFunctionsComponent with GroupOperations
    with Validation with Enrichment with Transformation with Loader with Errors =>

  /**
    * Loads PENDING validation errors from err_table for re-processing
    *
    * @return - data frame of errors
    */
  def getPendingErrors: DataFrame = {
    var error_df = sqlContext
      .read
      .format("org.apache.spark.sql.cassandra")
      .options(Map("table" -> "err_table", "keyspace" -> appConfig.odsKeyspace))
      .load()
      .filter(col("tenant_id").equalTo(lit(etlConfig.tenantId)))
      .filter(col("process_id").equalTo(lit(etlConfig.processId)))
      .filter(col("status").equalTo(lit("PENDING")))
    val rowColumn = split(col("row"), escapeCharacters(delim))
    columns.indices.foreach { i =>
      error_df = error_df.withColumn(columns(i), rowColumn.getItem(i))
    }
    error_df
  }

  /**
    * Try to re-process errors from previous runs
    *
    * @param errorsDf - dataframe of error records
    */
  def reprocessErrors(errorsDf: DataFrame): Unit = {
    val errTimestampMapping =  new ETLMapping(etlConfig.tenantId, etlConfig.processId, "err_timestamp", Some("err_timestamp"))
    val reprocessMappings = mappings :+ errTimestampMapping

    val sourceGroupOpsDf = applySourceGroupOperations(errorsDf)
    val (fixedValidationErrors, _) = validate(sourceGroupOpsDf)
    val transformed = transform(fixedValidationErrors.select("err_timestamp", "row" +: columns :_*), reprocessMappings)
    val (fixedRIErrors, _) = enrich(transformed)
    val reprocessResult = applyTargetGroupOperations(fixedRIErrors)

    val target = reprocessResult.drop("err_timestamp").drop("row")
    load(target)

    val getTimestamp = udf { () => System.currentTimeMillis() }
    val fixed = errorsDf.join(reprocessResult, errorsDf("err_timestamp") === reprocessResult("err_timestamp"))
      .select(errorsDf("*"))
      .withColumn("status", lit("FIXED")).withColumn("status_dt", getTimestamp())
      .select("row", "err_message", "tenant_id", "group_id", "source", "source_entity", "target", "target_entity",
        "subcategory", "process_id", "err_min", "err_hour", "err_day", "err_month", "err_year", "err_timestamp", "step", "status", "status_dt", "r_part")
    saveErrors(fixed)
  }

}