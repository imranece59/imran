package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class DaccSplty extends GroupOperation {
  override val name: String = "daccSplty"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val dataExtr = new CassandraDataExtractor("ods", "d_specialty")
    val dspDf = dataExtr.extractData(df.sqlContext).cache()

    finDf(df, dspDf).repartition(40)
  }
  def finDf(sourceDf: DataFrame, dspDf:DataFrame ): DataFrame = {
    import sourceDf.sqlContext.implicits._
    val df = sourceDf.as("t1").join(dspDf.as("t2"),
      sourceDf("spclty_desc") === dspDf("spclty_desc"), "leftouter").select($"t1.*",$"t2.spclty_cd",$"t2.spclty_id")
    df.filter(($"spclty_desc" !== "") && ($"spclty_desc".isNotNull))
  }
}
