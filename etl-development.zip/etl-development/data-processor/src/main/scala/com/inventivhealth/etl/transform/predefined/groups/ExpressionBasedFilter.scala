package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame

class ExpressionBasedFilter extends GroupOperation {
  override val name: String = "exprFilter"

  private final val expression = "expr"

  /**
    * Filters data frame using sql expression. Regular Spark expressions are used:
    * {{{
    *   peopleDf.where("age > 15")
    * }}}
    *
    * @param df - data frame
    * @param operationParams - parameters for operation
    * @return new data frame
    */
  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame =
    df.where(operationParams(expression))
}
