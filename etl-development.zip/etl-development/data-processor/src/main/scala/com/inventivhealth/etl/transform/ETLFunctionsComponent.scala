package com.inventivhealth.etl.transform

import java.lang.reflect.Modifier

import com.inventivhealth.etl.config.ConfigComponent
import com.inventivhealth.etl.dao.{CassandraDaoComponent, ETLConfigComponent}
import com.inventivhealth.etl.extract.DataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess._
import com.inventivhealth.etl.spark.SparkComponent
import com.inventivhealth.etl.transform.api.{CellValidation, EtlFunction, GroupOperation}
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.reflections.Reflections
import org.reflections.scanners.SubTypesScanner
import org.reflections.util.{ClasspathHelper, ConfigurationBuilder, FilterBuilder}

import scala.collection.JavaConverters._

trait ETLFunctionsComponent {

  val transformations: Map[String, UserDefinedFunction]

  val validations: Map[String, UserDefinedFunction]

  val groupOperations: Map[String, GroupOperation]

  trait EtlFunctions {

    /**
      * Scans classpath for subtypes of [[EtlFunction]] (not [[CellValidation]]), instantiates them and creates a UDF
      * @return - map with entries like (function_name -> UDF)
      */
    def getTransformations: Map[String, UserDefinedFunction]

    /**
      * Scans classpath for subtypes of [[CellValidation]], instantiates them and creates a UDF
      * @return - map with entries like (function_name -> UDF)
      */
    def getValidations: Map[String, UserDefinedFunction]


    def getGroupOperations: Map[String, GroupOperation]
  }

}

trait ClassPathScanETLFunctionsComponent extends ETLFunctionsComponent {
  this: ConfigComponent with CassandraDaoComponent with ETLConfigComponent with SparkComponent with DataExtractorFactory =>

  private val etlFunctions: EtlFunctions = new ClassPathFunctions

  override val transformations: Map[String, UserDefinedFunction] = etlFunctions.getTransformations
  override val validations: Map[String, UserDefinedFunction] = etlFunctions.getValidations
  override val groupOperations: Map[String, GroupOperation] = etlFunctions.getGroupOperations

  class ClassPathFunctions extends EtlFunctions {

    override def getTransformations: Map[String, UserDefinedFunction] = {
      val reflections = new Reflections(new ConfigurationBuilder()
        .setUrls(ClasspathHelper.forPackage("com.inventivhealth.etl"))
        .setScanners(new SubTypesScanner())
        .filterInputsBy(new FilterBuilder().includePackage("com.inventivhealth.etl")))

      val mappings = cassandraDao.getBroadcastRefMapping(etlConfig.processId, etlConfig.sourceEntityName)
      val staticData = mappings.map { ref =>
        val extractor = getDataExtractor(ref.lookupLocation, ref.lookup, false)
        var df = extractor.extractData(sqlContext)
          .where(col("tenant_id") === lit(etlConfig.tenantId))
        if (df.schema.fieldNames.contains("active_inactive"))  {
          df = df.where(col("active_inactive").equalTo(lit("ACTIVE")))
        }
        if (ref.condition.isDefined)
          df = df.where(ref.condition.get)
        ref.lookup -> df.collect()
      }.toMap
      val broadcasts = sqlContext.sparkContext.broadcast(staticData)

      reflections.getSubTypesOf(classOf[EtlFunction]).asScala
        .filter(cl => !Modifier.isAbstract(cl.getModifiers))
        .filter(cl => !classOf[CellValidation[_]].isAssignableFrom(cl))
        .map(_.newInstance())
        .map { func =>
          func.parameters ++= Seq(processIdParam -> etlConfig.processId, tenantIdParam -> etlConfig.tenantId, odsKeyspace -> appConfig.odsKeyspace)
          func.broadcasts = broadcasts
          func.name -> func.createUdf
        }.toMap
    }

    override def getValidations: Map[String, UserDefinedFunction] = {
      val reflections = new Reflections(new ConfigurationBuilder()
        .setUrls(ClasspathHelper.forPackage("com.inventivhealth.etl"))
        .setScanners(new SubTypesScanner())
        .filterInputsBy(new FilterBuilder().includePackage("com.inventivhealth.etl")))

      reflections.getSubTypesOf(classOf[CellValidation[_]]).asScala
        .map(_.newInstance())
        .map { func => func.name -> func.createUdf }
        .toMap
    }

    override def getGroupOperations: Map[String, GroupOperation] = {
      val reflections = new Reflections(new ConfigurationBuilder()
        .setUrls(ClasspathHelper.forPackage("com.inventivhealth.etl"))
        .setScanners(new SubTypesScanner())
        .filterInputsBy(new FilterBuilder().includePackage("com.inventivhealth.etl")))

      reflections.getSubTypesOf(classOf[GroupOperation]).asScala
        .filter(cl => !Modifier.isAbstract(cl.getModifiers))
        .map(_.newInstance())
        .map { func =>
          func.parameters ++= Seq(processIdParam -> etlConfig.processId, tenantIdParam -> etlConfig.tenantId, odsKeyspace -> appConfig.odsKeyspace)
          func.name -> func
        }
        .toMap
    }
  }

}