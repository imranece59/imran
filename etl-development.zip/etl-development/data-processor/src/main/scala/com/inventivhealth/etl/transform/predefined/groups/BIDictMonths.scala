package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import java.sql.{Date}
import java.text.SimpleDateFormat
import org.apache.commons.lang.time.DateUtils
import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import java.text.DateFormatSymbols;

case class MonthRecord(month_id:Int, month_name:String)

class BIDictMonths extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biDictMonths"
    
  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = { 
     
    val currYearMonth = df.agg({"mo_id"->"max"}).head().getInt(0)
    val currYear = currYearMonth.toString().substring(0, 4)    
    val sMonthYtd = Integer.parseInt(currYear.concat("01")) 
    var months = Seq(getMonthRecord(sMonthYtd))    
    for (a<-sMonthYtd+1 to currYearMonth) {
      months = months.:+(getMonthRecord(a))
    }    
    val monthsRdd = df.sqlContext.sparkContext.parallelize(months)    
    val monthsDf = df.sqlContext.createDataFrame(monthsRdd)
    monthsDf
  }
  
  def getMonthRecord(monthId:Int): MonthRecord= {
    val month_id = monthId
    val shortMonths = new DateFormatSymbols().getShortMonths(); 
    val month = Integer.parseInt(month_id.toString().substring(4,6))
    val month_name = shortMonths.apply(month-1)+" "+month_id.toString().substring(0, 4)
    MonthRecord(month_id,month_name)
  }  
  
}