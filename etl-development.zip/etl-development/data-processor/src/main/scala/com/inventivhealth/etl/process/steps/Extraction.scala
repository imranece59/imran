package com.inventivhealth.etl.process.steps

import com.inventivhealth.etl.config.ConfigComponent
import com.inventivhealth.etl.dao.ETLConfigComponent
import com.inventivhealth.etl.extract.DataExtractorFactory
import com.inventivhealth.etl.spark.SparkComponent
import org.apache.spark.sql.DataFrame
import org.apache.spark.storage.StorageLevel

trait Extraction {
  this: ConfigComponent with ETLConfigComponent with DataExtractorFactory with SparkComponent =>

  def extract(): DataFrame = {
    val filePath = Option(etlConfig.currentEntityLoc)
      .map(cel => s"$cel/${etlConfig.sourceEntityName}")
      .getOrElse(etlConfig.sourceEntityName)
    val dataExtractor = getDataExtractor(etlConfig.sourceName, filePath, hasHeader, schema, Some(delim), appConfig.parserLib)
    val df = dataExtractor.extractData(sqlContext)
    if (appConfig.cacheSource) {
      df.persist(StorageLevel.MEMORY_AND_DISK_SER)
    }
    df
  }

}

