package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class Upper extends EtlFunction1[String, String] {
  override val name: String = "upper"

  override def execute(s: String): String = s.toUpperCase

  override def createUdf: UserDefinedFunction = udf { execute _ }
}