package com.inventivhealth.etl

import java.io.File

import com.inventivhealth.etl.config.AppConfig
import com.inventivhealth.etl.dao.CassandraDao
import com.typesafe.config.ConfigFactory
import com.typesafe.scalalogging.slf4j.LazyLogging
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}

import scala.util.{Failure, Success, Try}
import org.apache.spark.sql.hive.HiveContext


case class Args(configFile: Option[String] = None,
                tenantId: Int = 1,
                groupId: Option[Int] = None,
                sourceName: String = "s3",
                sourceEntityName: String = "Customer_Header.txt",
                targetName: String = "ods",
                targetEntityName: String = "d_account")


object ETL extends LazyLogging {

  def main(args: Array[String]): Unit = {
    val parser = new scopt.OptionParser[Args]("etl") {
      head("etl", "0.1")
      opt[String]("config-file").action((x, a) => a.copy(configFile = Some(x))) text "Path to external configuration file"
      opt[Int]("tenant-id").required().action((x, a) => a.copy(tenantId = x)) text "Tenant Id"
      opt[Int]("group-id").action((x, a) => a.copy(groupId = Some(x))) text "Group Id"
      opt[String]("source-name").required().action((x, a) => a.copy(sourceName = x)) text "Source name"
      opt[String]("source-entity-name").required().action((x, a) => a.copy(sourceEntityName = x)) text "Source entity name"
      opt[String]("target-name").required().action((x, a) => a.copy(targetName = x)) text "Target name"
      opt[String]("target-entity-name").required().action((x, a) => a.copy(targetEntityName = x)) text "Target entity name"
      help("Usage text")
    }

    parser.parse(args, Args()) match {
      case Some(cmdArgs) =>
        val defaults = ConfigFactory.parseResources("reference.conf")
        val config = if (cmdArgs.configFile.isDefined) {
          ConfigFactory
            .parseFile(new File(cmdArgs.configFile.get))
            .withFallback(defaults)
            .resolve()
        } else defaults.resolve()
        val appConf = new AppConfig(config)

        val conf = new SparkConf(true)
          .set("spark.cassandra.connection.host", appConf.cassandraHost)
          .set("spark.cassandra.connection.port", appConf.cassandraPort.toString)
          .set("spark.cassandra.auth.username", appConf.cassandraUsername)
          .set("spark.cassandra.auth.password", appConf.cassandraPassword)
          .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
          .setAppName(s"${getClass.getSimpleName}-${cmdArgs.sourceEntityName}-${cmdArgs.targetEntityName}")
          .set("spark.cassandra.output.ignoreNulls","true")
          
        val sc = new SparkContext(conf)
        val hadoopConf = sc.hadoopConfiguration
        hadoopConf.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        hadoopConf.set("fs.s3a.access.key", appConf.s3AccessKey)
        hadoopConf.set("fs.s3a.secret.key", appConf.s3SecretKey)

        val sqlContext = new HiveContext(sc)

        val cassandraDao = CassandraDao(appConf)
        val etlConfigList = try {
          cassandraDao.getConfig(cmdArgs.tenantId, cmdArgs.sourceName, cmdArgs.sourceEntityName,
            cmdArgs.targetName, cmdArgs.targetEntityName)
        } finally cassandraDao.destroy()

        etlConfigList.foreach { etlConfig =>
          val process = new DefaultETLProcess(sqlContext, appConf, etlConfig, cmdArgs)

          Try(process.perform()) match {
            case Success(_)  => 0
            case Failure(ex) =>
              logger.error("ETL process failed", ex)
              sc.stop()
              sys.exit(1)
          }
        }
        sc.stop()
        sys.exit(0)

      case None =>
        //print usage
    }
  }

}