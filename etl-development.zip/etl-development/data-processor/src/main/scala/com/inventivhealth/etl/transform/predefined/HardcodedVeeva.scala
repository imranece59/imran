package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.UserDefinedFunction

class HardcodedVeeva extends EtlFunction0[String] {
  override def execute(): String = "Veeva"

  override def createUdf: UserDefinedFunction = udf { execute _ }

  override val name: String = "hardcodedVeeva"
}
