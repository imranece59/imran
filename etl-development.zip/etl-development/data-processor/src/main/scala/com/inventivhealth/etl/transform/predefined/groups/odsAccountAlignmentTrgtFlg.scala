package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess

class odsAccountAlignmentTrgtFlg extends GroupOperation {

  override val name: String = "odsAccountAlignmentTrgtFlg"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    var rDf = new CassandraDataExtractor("ods", "d_tsf").extractData(df.sqlContext).
      where(col("tenant_id") === lit(parameters(ETLProcess.tenantIdParam))
        and col("my_trgt_c") === lit(1)).
      select("accnt_c", "trrtry_c")

    rDf = rDf.withColumn("trgt_flg_1", lit("Y"))
    df.join(rDf, df("cust_attrib5") === rDf("accnt_c") && df("cust_attrib4") === rDf("trrtry_c"), "left_outer").
      select(df("*") +: Seq(rDf("trgt_flg_1")): _*).
      withColumn("trgt_flg", coalesce(col("trgt_flg_1"), lit("N"))).
      drop("trgt_flg_1")

    
  }
}
