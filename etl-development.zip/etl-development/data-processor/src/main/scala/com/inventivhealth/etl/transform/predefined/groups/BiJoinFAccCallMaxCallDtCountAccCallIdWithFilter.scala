package com.inventivhealth.etl.transform.predefined.groups

import java.sql.Timestamp
import java.time.format.DateTimeFormatter
import java.time._
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType

class BiJoinFAccCallMaxCallDtCountAccCallIdWithFilter extends GroupOperation {
  override val name: String = "biJoinFAccCallMaxCallDtCountAccCallIdWithFilter"
  private val callTypesParam = "callTypes"
  private val statusParam = "statuses"
  private val activityTypesParam = "activityTypes"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val tenantId = parameters(ETLProcess.tenantIdParam).asInstanceOf[Int]
    var accountCall = df.sqlContext.read.format("org.apache.spark.sql.cassandra").
      options(Map("table" -> "f_account_call", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String])).load()
      .where($"tenant_id" === lit(tenantId) and $"active_inactive" === lit("ACTIVE"))

    val callTypes = operationParams.get(callTypesParam).map(_.split(",").map(_.trim)).getOrElse(Array.empty)
    if (callTypes.nonEmpty) {
      accountCall = accountCall.where($"calltyp_c".isin(callTypes:_*))
    }

    val statuses = operationParams.get(statusParam).map(_.split(",").map(_.trim)).getOrElse(Array.empty)
    if (statuses.nonEmpty) {
      accountCall = accountCall.where($"status_c".isin(statuses:_*))
    }

    val activityTypes = operationParams.get(activityTypesParam).map(_.split(",").map(_.trim)).getOrElse(Array.empty)
    if (statuses.nonEmpty) {
      accountCall = accountCall.where($"actvty_typ_c".isin(activityTypes:_*))
    }

    val maxMonthId = GroupObject.broadcasts.value("maxMonthId")

    val startDate = (moId: String) => {
      val formatter = DateTimeFormatter.ofPattern("yyyyMM")
      val date = YearMonth.parse(moId, formatter).withMonth(1).atDay(1).atStartOfDay(ZoneOffset.UTC)
      new Timestamp(date.toInstant.toEpochMilli)
    }

    val endDate = (moId: String) => {
      val formatter = DateTimeFormatter.ofPattern("yyyyMM")
      val date = YearMonth.parse(moId, formatter).atEndOfMonth().atStartOfDay(ZoneOffset.UTC)
      new Timestamp(date.toInstant.toEpochMilli)
    }

    val withUTC = udf { (callDt: String) =>
      val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
      val date = LocalDate.parse(callDt, formatter)
      val dateWithZone = ZonedDateTime.of(date.getYear, date.getMonthValue, date.getDayOfMonth, 0, 0, 0, 0, ZoneOffset.UTC)
      new Timestamp(dateWithZone.toInstant.toEpochMilli)
    }

    val aggregatedDf =
    accountCall
      .withColumn("last_call_date", max($"call_dt_c").over(Window.partitionBy("accnt_id", "st_id", "trtry_c")))
      .withColumn("call_dt_with_utc", withUTC($"call_dt_c".cast(StringType)))
      .where($"call_dt_with_utc" >= lit(startDate(maxMonthId)) && $"call_dt_with_utc" <= lit(endDate(maxMonthId)))
      .groupBy("accnt_id", "st_id", "trtry_c", "last_call_date")
      .agg(countDistinct("accnt_call_id") as "call_count_ytd")
      .select("accnt_id", "call_count_ytd", "last_call_date", "st_id", "trtry_c")

    df.join(aggregatedDf, df("accnt_id") === aggregatedDf("accnt_id") &&
      df("st_id") === aggregatedDf("st_id") && df("geo_nbr") === aggregatedDf("trtry_c"), "left_outer")
      .select(df("*"), aggregatedDf("call_count_ytd"), aggregatedDf("last_call_date"))
      .drop($"geo_nbr")
      .drop($"accnt_id")
  }
}
