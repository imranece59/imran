package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import java.util.Date
import java.text.SimpleDateFormat
import org.apache.commons.lang.time.DateUtils
import com.inventivhealth.etl.process.ETLProcess
import org.apache.spark.sql.functions._

class BINewWritersWeekly extends GroupOperation {  
  override val name: String = "biNewWriters"
    
  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {    
    import df.sqlContext.implicits._
    
    val maxWeek = df.agg({"week_id"->"max"}).head().getInt(0)  
    
    /* current week (max week_id) records */ 
    val currWeekDf = df.filter(col("week_id")===maxWeek)
    
    val groupByCols = Array("tenant_id","accnt_id","st_id","brand_name","segment","segment_type","territory_name",
        "district_name","region_name","nation_name","address","city","customer_full_name","state","zip")
        
    val colNames = groupByCols.map(name=>col(name))   
    
    /* aggregating current week records */     
    val aggCurrWeekDf = currWeekDf.groupBy(colNames:_*)
        .agg("rx_current_week" -> "sum") 
        .withColumnRenamed("sum(rx_current_week)", "rx_current_week")
        .filter(col("rx_current_week")!==0)
        
     /* calculating past 12th week_id from the max week_id */  
    val fmt = new SimpleDateFormat("yyyyMMdd")
    val sDate = fmt.parse(maxWeek.toString())
    val eDate = DateUtils.addWeeks(sDate, -12)
    val eDateInt = fmt.format(eDate)
    
    /* past 12 week records */  
    val pastTwelveWeeksDf = df.filter(df("week_id").between(eDateInt, maxWeek-1))
    
     /* aggregating past 12 week records */  
    val aggPastTwelveWeeksDf = pastTwelveWeeksDf.groupBy(colNames:_*)
        .agg("rx_current_week" -> "sum")
        .withColumnRenamed("sum(rx_current_week)", "rx_current_week")
        .filter(col("rx_current_week")!==0)
        
    val oldWriters = aggCurrWeekDf.as("t1").join(aggPastTwelveWeeksDf.as("t2"),
    ($"t1.accnt_id") === ($"t2.accnt_id"), "inner")
    .select($"t1.*")
    
    val weekCode = new SimpleDateFormat("yyyy-MM-dd").format(sDate)
    
    val newWriters =  aggCurrWeekDf.except(oldWriters)                          
                          .withColumn("week_id",lit(maxWeek))
                          .withColumn("week_code", lit(weekCode)) 
                           
    newWriters
  }
}
