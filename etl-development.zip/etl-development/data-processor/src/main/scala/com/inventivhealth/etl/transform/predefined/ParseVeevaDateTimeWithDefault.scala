package com.inventivhealth.etl.transform.predefined

import java.sql.Timestamp
import java.time.{LocalDateTime, ZoneOffset}
import java.time.format.DateTimeFormatter

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions._

import scala.util.{Failure, Success, Try}

class ParseVeevaDateTimeWithDefault extends EtlFunction1[String, Option[Timestamp]] {

  override val name: String = "parseVeevaDateTimeWithDefault"

  override def execute(s: String): Option[Timestamp] = {
    Option(s) match {
      case Some(str) =>
        val format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S")
        Try(LocalDateTime.parse(str, format)) match {
          case Success(dt) =>
            val time = dt.toInstant(ZoneOffset.UTC).toEpochMilli
            Some(new Timestamp(time))
          case Failure(_) => Some(new Timestamp(System.currentTimeMillis()))
        }
      case None => Some(new Timestamp(System.currentTimeMillis()))
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
