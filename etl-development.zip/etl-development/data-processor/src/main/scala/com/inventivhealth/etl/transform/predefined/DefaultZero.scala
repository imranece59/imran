package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class DefaultZero extends EtlFunction0[Int] {
  override val name: String = "defaultZero"

  override def execute(): Int = 0

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
