package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import java.util.Date
import java.text.SimpleDateFormat
import org.apache.commons.lang.time.DateUtils
import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import org.apache.spark.sql.functions._

class BIJoinLocationDetails extends GroupOperation with DefaultDataExtractorFactory {  
  override val name: String = "biJoinLocationDetails"
  
  private val keyspace = "keypsace"
  private val table = "table"
  
  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {    
    import df.sqlContext.implicits._
    
    /* separating null and not null addr records */
    val nullAddrDf = df.filter(col("address").isNull)   
    val notNullAddrDf = df.filter(col("address").isNotNull)
    
    val dc = new DropColumns()
    val dcNullAddrDf = dc.execute(nullAddrDf, Map(("columns", "accnt_lctn_adrs1,accnt_lctn_adrs2,address,city,state,zip")))
    
    /* loading d_account_location table from ods*/
    val extractor = getDataExtractor(operationParams.getOrElse(keyspace, "ods"), operationParams.getOrElse(table, "d_account_location"), false)
    val tenantId = parameters(ETLProcess.tenantIdParam).asInstanceOf[Int]
    val locations = extractor.extractData(df.sqlContext) 
    
    /* formatting address fields to concatenate into one string*/
   val concatStr = udf((addrLine1: String,addrLine2:String) => {
     if (addrLine1 == null && addrLine2 == null) {
      null
     } else {
          val f = addrLine1.trim
          val s = addrLine2.trim
          val fullAddr = s"$f,$s"
          if(fullAddr.charAt(fullAddr.length()-1).equals(',')){            
            fullAddr.substring(0, fullAddr.length()-1)
          }else{fullAddr}
        }
    })
    
    /* getting address attributes for null addr records */      
    val tempDf1 = dcNullAddrDf.as("t1").join(locations.as("t2"),
        dcNullAddrDf("accnt_id") === locations("accnt_id"), "left_outer")
       .select($"t1.*",concatStr($"t2.accnt_lctn_adrs1",$"t2.accnt_lctn_adrs2"),$"t2.accnt_lctn_city",$"t2.accnt_lctn_state",$"t2.accnt_lctn_zip")       
       .withColumnRenamed("UDF(t2.accnt_lctn_adrs1,t2.accnt_lctn_adrs2)", "address")
       .withColumnRenamed("accnt_lctn_city","city")
       .withColumnRenamed("accnt_lctn_state","state")
       .withColumnRenamed("accnt_lctn_zip","zip")
    
     /*dropping null addr records and having only one address record per account */
    val tempDf2 = tempDf1.filter(col("address").isNotNull)
                  .filter(col("city").isNotNull)
                  .filter(col("state").isNotNull)                  
                  .filter(col("zip").isNotNull)
                  .dropDuplicates(dcNullAddrDf.columns)
       
    val filteredDf = unionAllByName(notNullAddrDf,tempDf2)    
    filteredDf
   
  }
  
  def unionAllByName(a: DataFrame, b: DataFrame): DataFrame = {
    val columns = a.columns.toSet.intersect(b.columns.toSet).map(col).toSeq
    a.select(columns: _*).unionAll(b.select(columns: _*))
  }
}
