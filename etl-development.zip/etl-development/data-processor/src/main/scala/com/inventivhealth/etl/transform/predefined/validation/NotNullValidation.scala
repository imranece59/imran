package com.inventivhealth.etl.transform.predefined.validation

import com.inventivhealth.etl.transform.api.CellValidation
import org.apache.commons.lang.StringUtils
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class NotNullValidation extends CellValidation[String] {
  override val name: String = "validateNotNull"

  override def execute(v: String, fieldName: String, param: String): Option[String] = {
    if (StringUtils.isBlank(v) || v == "null") {
      Some(s"FIELD_IS_NULL")
    } else None
  }



  override def createUdf: UserDefinedFunction = udf { super[CellValidation].execute _ }
}
