package com.inventivhealth.etl

import com.inventivhealth.etl.config.model.ETLConfig
import com.inventivhealth.etl.config.{AppConfig, ConfigComponent}
import com.inventivhealth.etl.dao.{CassandraDaoComponent, CassandraETLConfigComponent}
import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.persist.DefaultDataSaverFactory
import com.inventivhealth.etl.process._
import com.inventivhealth.etl.spark.SparkComponent
import com.inventivhealth.etl.transform.ClassPathScanETLFunctionsComponent
import org.apache.spark.sql.SQLContext

class DefaultETLProcess(override val sqlContext: SQLContext,
                        override val appConfig: AppConfig,
                        override val etlConfig: ETLConfig,
                        override val args: Args)
  extends ConfigComponent with CassandraDaoComponent with CassandraETLConfigComponent with ClassPathScanETLFunctionsComponent
    with DefaultDataExtractorFactory with SparkComponent with DefaultDataSaverFactory
    with ETLProcess
