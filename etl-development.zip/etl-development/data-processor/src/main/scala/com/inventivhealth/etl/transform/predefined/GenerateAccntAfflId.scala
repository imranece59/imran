package com.inventivhealth.etl.transform.predefined

import java.time.format.DateTimeFormatter
import java.time.{LocalDate, ZoneOffset}

import com.inventivhealth.etl.transform.api.EtlFunction5
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class GenerateAccntAfflId extends EtlFunction5[String, String, String, String, String,String] {
  override val name: String = "generateAccntAffilId"

  override def execute(sls_org_id: String, hca_cid: String, hca_chld_cid: String,
                       hcp_cid: String, affil_grp_typ: String): String = {

    s"$sls_org_id:$hca_cid:$hca_chld_cid:$hcp_cid:$affil_grp_typ"
  }
  override def createUdf: UserDefinedFunction = udf { execute _ }
}