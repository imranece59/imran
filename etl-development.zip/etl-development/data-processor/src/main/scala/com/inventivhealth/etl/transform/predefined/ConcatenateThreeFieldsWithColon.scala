package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction3
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class ConcatenateThreeFieldsWithColon extends EtlFunction3[String, String, String, String] {
  override val name: String = "concatThreeWithColon"

  override def execute(s1: String, s2: String, s3: String): String = {
    if (s1 == null || s2 == null || s3 == null) {
      null
    } else {
      val f = s1.trim
      val s = s2.trim
      val t = s3.trim
      s"$f:$s:$t"
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
