package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import com.inventivhealth.etl.bi._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.storage.StorageLevel

class BiGeographyRegionDistrictCalc extends GroupOperation {
  override val name: String = "biGeoRegDistCalc"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    // first friday
    val firstFriday = GroupObject.broadcasts.value("first_friday").toInt

    // cache input df
    df.persist(StorageLevel.MEMORY_AND_DISK_SER)

    /**
      * get region, district level
      * distinct payer rows after joins
      */
    val allDf = df
      .select("wk_id", "fin_brnd_id", "mkt_pid", "sls_chnl_desc", "prsc_cid", "tenant_id", "st_id", "market_name",
        "brand_name", "region_name", "district_name", "target", "rx", "group_id")
      .distinct()

    // get only region level
    val allRegionDf = df
      .select("wk_id", "fin_brnd_id", "mkt_pid", "sls_chnl_desc", "prsc_cid", "tenant_id", "st_id", "market_name",
        "brand_name", "region_name", "target", "rx", "group_id")
      .distinct()

    /**
      * sum(trx) group by market, brand, region, district, target, group_id (group week friday) and get distinct rows
      * and count(prescriber) for the same group
      */
    var aggDf = allDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "region_name", "district_name", "target", "group_id")
      .agg(sum("rx") as "four_week_rx", expr("count(case when rx > 0 then tenant_id else null end)") as "four_week_prescriber_count")

    // sum and count on region level
    var aggRegionDf = allRegionDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "region_name", "target", "group_id")
      .agg(sum("rx") as "region_four_week_rx", expr("count(case when rx > 0 then tenant_id else null end)") as "region_four_week_prescriber_count")

    // add previous four_week_rx column and previous four_week_prescriber_count
    aggDf = aggDf
      .withColumn("prev_four_week_rx",
        lag("four_week_rx", 1).over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "region_name", "district_name", "target").orderBy("group_id")))
      .withColumn("prev_four_week_prescriber_count",
        lag("four_week_prescriber_count", 1).over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "region_name", "district_name", "target").orderBy("group_id")))

    // region level
    aggRegionDf = aggRegionDf
      .withColumn("region_prev_four_week_rx",
        lag("region_four_week_rx", 1).over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "region_name", "target").orderBy("group_id")))
      .withColumn("region_prev_four_week_prescriber_count",
        lag("region_four_week_prescriber_count", 1).over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "region_name", "target").orderBy("group_id")))

    // replace null values for prev_ columns
    aggDf = aggDf.withColumn("prev_four_week_prescriber_count", when(col("prev_four_week_prescriber_count").isNull, lit(0)).otherwise(col("prev_four_week_prescriber_count")))
    aggDf = aggDf.withColumn("prev_four_week_rx", when(col("prev_four_week_rx").isNull, lit(0)).otherwise(col("prev_four_week_rx")))

    aggRegionDf = aggRegionDf.withColumn("region_prev_four_week_prescriber_count", when(col("region_prev_four_week_prescriber_count").isNull, lit(0)).otherwise(col("region_prev_four_week_prescriber_count")))
    aggRegionDf = aggRegionDf.withColumn("region_prev_four_week_rx", when(col("region_prev_four_week_rx").isNull, lit(0)).otherwise(col("region_prev_four_week_rx")))

    // add four_week_rx_change_perc, four_week_prescriber_count_change_perc
    aggDf = aggDf
      .withColumn("four_week_rx_change_perc", brandRxPercentChange(col("four_week_rx"), col("prev_four_week_rx")))
      .withColumn("four_week_prescriber_count_change_perc", brandRxPercentChange(col("four_week_prescriber_count"), col("prev_four_week_prescriber_count")))
      .drop("prev_four_week_rx")
      .drop("prev_four_week_prescriber_count")

    // region level
    aggRegionDf = aggRegionDf
      .withColumn("region_four_week_rx_change_perc", brandRxPercentChange(col("region_four_week_rx"), col("region_prev_four_week_rx")))
      .withColumn("region_four_week_prescriber_count_change_perc", brandRxPercentChange(col("region_four_week_prescriber_count"), col("region_prev_four_week_prescriber_count")))
      .drop("region_prev_four_week_rx")
      .drop("region_prev_four_week_prescriber_count")

    // join district and region aggregations
    aggDf = aggDf.join(aggRegionDf, Seq("tenant_id", "st_id", "market_name", "brand_name", "region_name", "target", "group_id"))
      .select(aggDf("*"), aggRegionDf("region_four_week_rx"), aggRegionDf("region_four_week_prescriber_count"), aggRegionDf("region_four_week_rx_change_perc"),
        aggRegionDf("region_four_week_prescriber_count_change_perc"))

    // filter out first week
    aggDf = aggDf.where(col("group_id").notEqual(lit(firstFriday)))

    aggDf = aggDf
      .withColumnRenamed("four_week_rx", "district_four_week_rx")
      .withColumnRenamed("four_week_rx_change_perc", "district_four_week_rx_change_perc")
      .withColumnRenamed("four_week_prescriber_count", "district_four_week_prescriber_count")
      .withColumnRenamed("four_week_prescriber_count_change_perc", "district_four_week_prescriber_count_change_perc")

    aggDf
      .withColumn("week_code", getWeekCode(col("group_id")))
      .withColumnRenamed("group_id", "week_id")
  }
}