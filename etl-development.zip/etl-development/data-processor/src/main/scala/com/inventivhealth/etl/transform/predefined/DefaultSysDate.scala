package com.inventivhealth.etl.transform.predefined

import java.sql.Timestamp

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class DefaultSysDate extends EtlFunction0[Timestamp] {
  override val name: String = "defaultSysdate"

  override def execute(): Timestamp = new Timestamp(System.currentTimeMillis())

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
