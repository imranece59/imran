package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction3
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class AccountFullName extends EtlFunction3[String, String, String, String] {
  override val name: String = "accountFullName"

  override def execute(lastName: String, firstName: String, middleName: String): String = s"$lastName, $firstName $middleName"

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
