package com.inventivhealth.etl.transform.predefined.groups

import java.time.{LocalDate, ZoneOffset}
import java.time.format.DateTimeFormatter
import java.time.temporal.WeekFields

import com.inventivhealth.etl.bi._
import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

class BiHomeRegionDistrictCalc extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biHomeRegDistCalc"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    // get current week
    val currentWeek = GroupObject.broadcasts.value("current_week")

    // previous, 3rd and 4th weeks
    val format = DateTimeFormatter.ofPattern("yyyyMMdd")
    val field = WeekFields.ISO.dayOfWeek()
    val prevWeekDate = LocalDate.parse(currentWeek, format).atStartOfDay(ZoneOffset.UTC).minusWeeks(1).`with`(field, 5)
    val thirdWeekDate = LocalDate.parse(currentWeek, format).atStartOfDay(ZoneOffset.UTC).minusWeeks(2).`with`(field, 5)
    val fourthWeekDate = LocalDate.parse(currentWeek, format).atStartOfDay(ZoneOffset.UTC).minusWeeks(3).`with`(field, 5)
    val previousWeek = prevWeekDate.format(format)
    val thirdWeek = thirdWeekDate.format(format)
    val fourthWeek = fourthWeekDate.format(format)

    // cache input df
    df.persist(StorageLevel.MEMORY_AND_DISK_SER)

    /**
      * get district level
      * distinct payer rows after joins
      */
    val allDf = df
      .select("wk_id", "fin_brnd_id", "mkt_pid", "sls_chnl_desc", "prsc_cid", "tenant_id", "st_id", "market_name",
        "brand_name", "district_name", "region_name", "rx", "week_id", "segment", "segment_type")
      .distinct()

    // get only region level
    val allRegionDf = df
      .select("wk_id", "fin_brnd_id", "mkt_pid", "sls_chnl_desc", "prsc_cid", "tenant_id", "st_id", "market_name",
        "brand_name", "region_name", "rx", "week_id", "segment", "segment_type")
      .distinct()

    // district level
    // district_NBRx/district_prescriber_count
    var aggDf = allDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "district_name", "region_name", "week_id", "segment", "segment_type")
      .agg(sum("rx") as "district_nbrx", expr("count(case when rx > 0 then tenant_id else null end)") as "district_prescriber_count")

    // district_current_week_NBRx/district_current_prescriber_count/district_prev_week_nbrx/district_prev_week_prescriber_count/3rd/4th
    var pivotDf = aggDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "district_name", "region_name", "segment", "segment_type")
      .pivot("week_id", Seq(currentWeek, previousWeek, thirdWeek, fourthWeek))
      .max("district_nbrx", "district_prescriber_count")
      .withColumnRenamed(currentWeek + "_max(district_nbrx)", "district_current_week_nbrx")
      .withColumnRenamed(currentWeek + "_max(district_prescriber_count)", "district_current_prescriber_count")
      .withColumnRenamed(previousWeek + "_max(district_nbrx)", "district_prev_week_nbrx")
      .withColumnRenamed(previousWeek + "_max(district_prescriber_count)", "district_prev_week_prescriber_count")
      .withColumnRenamed(thirdWeek + "_max(district_nbrx)", "district_3rd_week_nbrx")
      .withColumnRenamed(thirdWeek + "_max(district_prescriber_count)", "district_3rd_week_prescriber_count")
      .withColumnRenamed(fourthWeek + "_max(district_nbrx)", "district_4th_week_nbrx")
      .withColumnRenamed(fourthWeek + "_max(district_prescriber_count)", "district_4th_week_prescriber_count")

    // replace nulls with zeros
    pivotDf = pivotDf
      .withColumn("district_current_week_nbrx", when(col("district_current_week_nbrx").isNull, lit(0)).otherwise(col("district_current_week_nbrx")))
      .withColumn("district_current_prescriber_count", when(col("district_current_prescriber_count").isNull, lit(0)).otherwise(col("district_current_prescriber_count")))
      .withColumn("district_prev_week_nbrx", when(col("district_prev_week_nbrx").isNull, lit(0)).otherwise(col("district_prev_week_nbrx")))
      .withColumn("district_prev_week_prescriber_count", when(col("district_prev_week_prescriber_count").isNull, lit(0)).otherwise(col("district_prev_week_prescriber_count")))
      .withColumn("district_3rd_week_nbrx", when(col("district_3rd_week_nbrx").isNull, lit(0)).otherwise(col("district_3rd_week_nbrx")))
      .withColumn("district_3rd_week_prescriber_count", when(col("district_3rd_week_prescriber_count").isNull, lit(0)).otherwise(col("district_3rd_week_prescriber_count")))
      .withColumn("district_4th_week_nbrx", when(col("district_4th_week_nbrx").isNull, lit(0)).otherwise(col("district_4th_week_nbrx")))
      .withColumn("district_4th_week_prescriber_count", when(col("district_4th_week_prescriber_count").isNull, lit(0)).otherwise(col("district_4th_week_prescriber_count")))

    // district_4_week_NBRx/district_4_week_prescriber_count
    pivotDf = pivotDf
      .withColumn("district_4_week_nbrx", col("district_current_week_nbrx") + col("district_prev_week_nbrx") + col("district_3rd_week_nbrx") + col("district_4th_week_nbrx"))
      .withColumn("district_4_week_prescriber_count", col("district_current_prescriber_count") + col("district_prev_week_prescriber_count") + col("district_3rd_week_prescriber_count") + col("district_4th_week_prescriber_count"))
      .drop("district_3rd_week_nbrx")
      .drop("district_3rd_week_prescriber_count")
      .drop("district_4th_week_nbrx")
      .drop("district_4th_week_prescriber_count")

    // district_NBRx_perc_change/district_prescriber_count_perc_change
    pivotDf = pivotDf
      .withColumn("district_nbrx_perc_change", brandRxPercentChange(col("district_current_week_nbrx"), col("district_prev_week_nbrx")))
      .withColumn("district_prescriber_count_perc_change", brandRxPercentChange(col("district_current_prescriber_count"), col("district_prev_week_prescriber_count")))

    // join weekly and pivot data
    aggDf = aggDf.join(pivotDf, Seq("tenant_id", "st_id", "market_name", "brand_name", "district_name", "region_name", "segment", "segment_type"))
      .select(aggDf("*"), pivotDf("district_current_week_nbrx"), pivotDf("district_current_prescriber_count"), pivotDf("district_prev_week_nbrx"), pivotDf("district_prev_week_prescriber_count"),
        pivotDf("district_4_week_nbrx"), pivotDf("district_4_week_prescriber_count"), pivotDf("district_nbrx_perc_change"), pivotDf("district_prescriber_count_perc_change"))

    // region level
    // region_NBRx/region_prescriber_count
    var aggRegionDf = allRegionDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "region_name", "week_id", "segment", "segment_type")
      .agg(sum("rx") as "region_nbrx", expr("count(case when rx > 0 then tenant_id else null end)") as "region_prescriber_count")

    // region_current_week_NBRx/region_current_prescriber_count/region_prev_week_NBRx/region_prev_week_prescriber_count/3rd/4th
    var pivotRegionDf = aggRegionDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "region_name", "segment", "segment_type")
      .pivot("week_id", Seq(currentWeek, previousWeek, thirdWeek, fourthWeek))
      .max("region_nbrx", "region_prescriber_count")
      .withColumnRenamed(currentWeek + "_max(region_nbrx)", "region_current_week_nbrx")
      .withColumnRenamed(currentWeek + "_max(region_prescriber_count)", "region_current_prescriber_count")
      .withColumnRenamed(previousWeek + "_max(region_nbrx)", "region_prev_week_nbrx")
      .withColumnRenamed(previousWeek + "_max(region_prescriber_count)", "region_prev_week_prescriber_count")
      .withColumnRenamed(thirdWeek + "_max(region_nbrx)", "region_3rd_week_nbrx")
      .withColumnRenamed(thirdWeek + "_max(region_prescriber_count)", "region_3rd_week_prescriber_count")
      .withColumnRenamed(fourthWeek + "_max(region_nbrx)", "region_4th_week_nbrx")
      .withColumnRenamed(fourthWeek + "_max(region_prescriber_count)", "region_4th_week_prescriber_count")

    // replace nulls with zeros
    pivotRegionDf = pivotRegionDf
      .withColumn("region_current_week_nbrx", when(col("region_current_week_nbrx").isNull, lit(0)).otherwise(col("region_current_week_nbrx")))
      .withColumn("region_current_prescriber_count", when(col("region_current_prescriber_count").isNull, lit(0)).otherwise(col("region_current_prescriber_count")))
      .withColumn("region_prev_week_nbrx", when(col("region_prev_week_nbrx").isNull, lit(0)).otherwise(col("region_prev_week_nbrx")))
      .withColumn("region_prev_week_prescriber_count", when(col("region_prev_week_prescriber_count").isNull, lit(0)).otherwise(col("region_prev_week_prescriber_count")))
      .withColumn("region_3rd_week_nbrx", when(col("region_3rd_week_nbrx").isNull, lit(0)).otherwise(col("region_3rd_week_nbrx")))
      .withColumn("region_3rd_week_prescriber_count", when(col("region_3rd_week_prescriber_count").isNull, lit(0)).otherwise(col("region_3rd_week_prescriber_count")))
      .withColumn("region_4th_week_nbrx", when(col("region_4th_week_nbrx").isNull, lit(0)).otherwise(col("region_4th_week_nbrx")))
      .withColumn("region_4th_week_prescriber_count", when(col("region_4th_week_prescriber_count").isNull, lit(0)).otherwise(col("region_4th_week_prescriber_count")))

    // region_4_week_NBRx/region_4_week_prescriber_count
    pivotRegionDf = pivotRegionDf
      .withColumn("region_4_week_nbrx", col("region_current_week_nbrx") + col("region_prev_week_nbrx") + col("region_3rd_week_nbrx") + col("region_4th_week_nbrx"))
      .withColumn("region_4_week_prescriber_count", col("region_current_prescriber_count") + col("region_prev_week_prescriber_count") + col("region_3rd_week_prescriber_count") + col("region_4th_week_prescriber_count"))
      .drop("region_3rd_week_nbrx")
      .drop("region_3rd_week_prescriber_count")
      .drop("region_4th_week_nbrx")
      .drop("region_4th_week_prescriber_count")

    // region_NBRx_perc_change/region_prescriber_count_perc_change
    pivotRegionDf = pivotRegionDf
      .withColumn("region_nbrx_perc_change", brandRxPercentChange(col("region_current_week_nbrx"), col("region_prev_week_nbrx")))
      .withColumn("region_prescriber_count_perc_change", brandRxPercentChange(col("region_current_prescriber_count"), col("region_prev_week_prescriber_count")))

    // join weekly and pivot data
    aggRegionDf = aggRegionDf.join(pivotRegionDf, Seq("tenant_id", "st_id", "market_name", "brand_name", "region_name", "segment", "segment_type"))
      .select(aggRegionDf("*"), pivotRegionDf("region_current_week_nbrx"), pivotRegionDf("region_current_prescriber_count"), pivotRegionDf("region_prev_week_nbrx"),
        pivotRegionDf("region_prev_week_prescriber_count"), pivotRegionDf("region_4_week_nbrx"), pivotRegionDf("region_4_week_prescriber_count"),
        pivotRegionDf("region_nbrx_perc_change"), pivotRegionDf("region_prescriber_count_perc_change"))

    // join district and region aggregations
    aggDf = aggDf.join(aggRegionDf, Seq("tenant_id", "st_id", "market_name", "brand_name", "region_name", "segment", "segment_type", "week_id"))
      .select(aggDf("*"), aggRegionDf("region_nbrx"), aggRegionDf("region_prescriber_count"),
        aggRegionDf("region_current_week_nbrx"), aggRegionDf("region_current_prescriber_count"),
        aggRegionDf("region_prev_week_nbrx"), aggRegionDf("region_prev_week_prescriber_count"),
        aggRegionDf("region_4_week_nbrx"), aggRegionDf("region_4_week_prescriber_count"),
        aggRegionDf("region_nbrx_perc_change"), aggRegionDf("region_prescriber_count_perc_change"))

    // metric_type - NBRx
    aggDf = aggDf.withColumn("metric_type", lit("NBRX"))

    // resolve week_code
    aggDf.withColumn("week_code", getWeekCode(col("week_id")))
  }
}