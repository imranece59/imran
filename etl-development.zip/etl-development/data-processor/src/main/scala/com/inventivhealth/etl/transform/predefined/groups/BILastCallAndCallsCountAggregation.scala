package com.inventivhealth.etl.transform.predefined.groups

import java.sql.Timestamp
import java.time.{LocalDate, ZoneOffset}
import java.time.format.DateTimeFormatter

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class BILastCallAndCallsCountAggregation extends GroupOperation {
  override val name: String = "biLastCallAndCallsCountAggregation"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val parseCallDate = udf { (callDate: String) =>
      val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
      val time = LocalDate.parse(callDate, formatter).atStartOfDay(ZoneOffset.UTC).toInstant.toEpochMilli
      new Timestamp(time)
    }
    val defaultTarget = udf { (target: String) => if (target == null) "N" else target }
    df
      .withColumn("call_dt_c", parseCallDate($"call_dt_c"))
      .withColumn("target", defaultTarget($"cust_attrib3"))
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "segment_type", "segment", "target", "territory_name", "month_id", "month_name", "customer_full_name")
      .agg(count("call_dt_c") as "call_count", max("call_dt_c") as "last_call_date")
  }
}
