package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class MedInquiryLkp extends GroupOperation {
  override val name: String = "medInqLkp"
  override def execute(inputdf: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import inputdf.sqlContext.implicits._
    val defVal = udf((a: String) => {if (a == null) {"9999-99-99"} else a })

    val dataExtr1 = new CassandraDataExtractor("ods", "d_rep_roster")
    val dataExtr2 = new CassandraDataExtractor("ods", "d_product_sales_calls")
    val extRepDf = dataExtr1.extractData(inputdf.sqlContext).cache()
    val extPrdDf = dataExtr2.extractData(inputdf.sqlContext).cache()

    val repDf = extRepDf.withColumn("end_dt", defVal(extRepDf("end_dt")))
    val gRepDf = repDf.groupBy("usr_id").agg("end_dt" -> "max").withColumnRenamed("max(end_dt)", "end_dt")

    val finRepDf = repDf.as("t1").join(gRepDf.as("t2"),
      repDf("usr_id") === gRepDf("usr_id")
      &&  repDf("end_dt") === gRepDf("end_dt"), "inner").select($"t1.usr_id",$"t1.st_id",$"t1.geo_id")

    val tempDf1 = inputdf.as("t1").join(finRepDf.as("t2"),
      inputdf("usr_id") === finRepDf("usr_id"), "leftouter").select($"t1.*",$"t2.st_id",$"t2.geo_id")

    val returnDf = tempDf1.as("t1").join(extPrdDf.as("t2"),
      tempDf1("prdct_c") === extPrdDf("product_name"), "leftouter").select($"t1.*",$"t2.product_id".as("prdct_id"))
    returnDf
  }
}