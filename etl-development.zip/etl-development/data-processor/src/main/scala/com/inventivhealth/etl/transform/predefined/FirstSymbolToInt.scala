package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import scala.util.{ Try, Failure, Success }

class FirstSymbolToInt extends EtlFunction1[String, Int] {
  override val name: String = "firstSymbolToInt"

  override def execute(source: String): Int= {
   Try(source.substring(0, 1).toInt) match {
      case Success(id) => id
      case Failure(_) => -1
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
