package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class BIFAccountCallTypeFilter extends GroupOperation {
  override val name: String = "biFAccountCallTypeFilter"

  private val typesParam = "callTypes"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val types = operationParams.get(typesParam).map(_.split(",").map(_.trim)).getOrElse(Array.empty)
    if (types.nonEmpty) {
      df.where(df("calltyp_c").isin(types:_*) and df("status_c").equalTo(lit("Submitted_vod")))
    } else {
      df.where(df("status_c").equalTo(lit("Submitted_vod")))
    }
  }
}
