package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class ActdbSelectExpr extends GroupOperation {

  override val name: String = "actdbSelectExpr"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val sep = operationParams.getOrElse("sep", ";")
    val cols = operationParams("select").split(sep)
    df.selectExpr(cols: _*)

  }
}
