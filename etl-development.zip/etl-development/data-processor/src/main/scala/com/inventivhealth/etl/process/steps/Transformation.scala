package com.inventivhealth.etl.process.steps

import com.inventivhealth.etl.config.model.ETLMapping
import com.inventivhealth.etl.transform.ETLFunctionsComponent
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame}

trait Transformation {
  this: ETLFunctionsComponent =>

  /**
    * Transforms source data into target data according to mapping_config rules.
    * Only columns present on mapping list are selected into target data frame
    *
    * @param source  - source data frame
    * @param mapping - transformation mappings
    * @return - transformed data frame
    */
  def transform(source: DataFrame, mapping: List[ETLMapping]): DataFrame = {
    val cols = getTransformedColumns(mapping)
    source.select(cols :+ col("row") : _*)
  }

  /**
    * Partially transforms source data. This means only colums present in mapping transformed.
    * Columns which not present in mapping but exist in source data also selected into target data frame.
    *
    * @param source - source data frame
    * @param mapping - transformation mappings
    * @return - transformed data frame
    */
  def partialTransform(source: DataFrame, mapping: List[ETLMapping]): DataFrame = {
    if (mapping.nonEmpty) {
      val cols = getTransformedColumns(mapping)
      val transformed = mapping.filter(_.sourceField.isDefined).map(_.sourceField.get).toSet
      val newColumns = mapping.map(_.targetField).map(col)
      val oldColumns = source.schema.fieldNames.filterNot(transformed.contains).map(col).toList
      source
        .select(source("*") +: cols : _*)
        .select(oldColumns ++ newColumns : _*)
    } else source
  }

  private def getTransformedColumns(mapping: List[ETLMapping]): List[Column] = mapping.map { m =>
    val columnName = m.targetField
    val replaceNull = udf { (v: String) => if ("null" == v) null else v }
    m.transformation match {
      case Some(t) =>
        m.sourceField match {
          case Some(sourceField) =>
            val udfParams = sourceField.split(",").map(col)
            val func = transformations(t)
            func(udfParams: _*).as(columnName)
          case None => transformations(t)().as(columnName)
        }
      case None => replaceNull(col(m.sourceField.get)).as(columnName)
    }
  }
}
