package com.inventivhealth.etl.transform.predefined.groups

import java.sql.Timestamp
import java.time.format.{DateTimeFormatter, TextStyle}
import java.time.{LocalDate, ZoneOffset}
import java.util.Locale

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class BIGetMonthAndFilterByCallDate extends GroupOperation {
  override val name: String = "biGetMonthAndFilterByCallDate"

  private val countParam = "count"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val count = operationParams.getOrElse(countParam, "12").toString.toInt
    val yearAgo = new Timestamp(LocalDate.now().atStartOfDay().minusMonths(count).toInstant(ZoneOffset.UTC).toEpochMilli)

    val getMonth = udf { (callDate: Timestamp) =>
      val format = DateTimeFormatter.ofPattern("yyyyMM")
      val localDate = callDate.toLocalDateTime
      val monthId = localDate.format(format)
      val monthName = localDate.getMonth.getDisplayName(TextStyle.SHORT, Locale.getDefault)
      (monthId, s"$monthName ${localDate.getYear}")
    }

    df.where($"call_dt_c" >= lit(yearAgo))
      .withColumn("month_info", getMonth($"call_dt_c"))
      .withColumn("month_id", $"month_info._1")
      .withColumn("month_name", $"month_info._2")
      .drop("month_info")
  }

}
