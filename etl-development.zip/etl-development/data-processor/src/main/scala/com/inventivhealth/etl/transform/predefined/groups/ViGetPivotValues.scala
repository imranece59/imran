package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class ViGetPivotValues extends GroupOperation {
  override val name: String = "viGetPivotValues"

  private val pivotColumnParam = "pivotColumn"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val pivotColumn = operationParams.getOrElse(pivotColumnParam, "wk_id")

    // distinct pivot values
    val pivotValues = df.select(pivotColumn).distinct().sort(col(pivotColumn).desc).collect().map(row => row.getAs[Int](pivotColumn)).toSeq

    GroupObject.pivotValues = pivotValues

    df
 }
}