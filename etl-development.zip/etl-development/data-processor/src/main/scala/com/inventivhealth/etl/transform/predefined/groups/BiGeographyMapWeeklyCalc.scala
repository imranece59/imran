package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.bi._
import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

class BiGeographyMapWeeklyCalc extends GroupOperation {
  override val name: String = "biGeoMapWeekCalc"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    // first friday
    val firstFriday = GroupObject.broadcasts.value("first_friday").toInt

    // filter out empty customer name
    var allDf = df.where((col("frst_nm").isNotNull || col("lst_nm").isNotNull || col("mddl_nm").isNotNull))

    allDf = allDf
      .withColumn("customer_full_name", getCustomerFullName(col("lst_nm"), col("frst_nm"), col("mddl_nm")))
      .drop("lst_nm")
      .drop("frst_nm")
      .drop("mddl_nm")

    // distinct payer rows after joins
    allDf = allDf
      .select("wk_id", "fin_brnd_id", "mkt_pid", "sls_chnl_desc", "prsc_cid", "tenant_id", "st_id", "market_name",
        "brand_name", "territory_name", "rx_vol", "group_id", "customer_full_name", "zip", "latitude", "longitude")
      .distinct()

    // add metric column
    allDf = allDf.withColumn("metric_type", lit("NBRX"))

    // calculate brand_rx and market_rx
    var aggDf = allDf
      .withColumn("brand_rx",
        sum(col("rx_vol"))
          .over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "metric_type", "group_id",
            "customer_full_name", "zip", "latitude", "longitude")))
      .withColumn("market_rx",
        sum(col("rx_vol"))
          .over(Window.partitionBy("tenant_id", "st_id", "market_name", "territory_name", "metric_type", "group_id",
            "customer_full_name", "zip", "latitude", "longitude")))
      .select("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "metric_type", "group_id",
        "customer_full_name", "zip", "latitude", "longitude", "brand_rx", "market_rx")
      .distinct()

    // calculate prev_brand_rx and prev_market_rx, get prev group_id
    aggDf = aggDf
      .withColumn("prev_brand_rx",
        lag("brand_rx", 1)
          .over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "metric_type",
            "customer_full_name", "zip", "latitude", "longitude").orderBy("group_id")))
      .withColumn("prev_market_rx",
        lag("market_rx", 1)
          .over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "metric_type",
            "customer_full_name", "zip", "latitude", "longitude").orderBy("group_id")))
      .withColumn("prev_group_id",
        lag("group_id", 1)
          .over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "metric_type",
            "customer_full_name", "zip", "latitude", "longitude").orderBy("group_id")))

    aggDf = aggDf
      .withColumn("market_share", marketShare(col("brand_rx"), col("market_rx")))

    // replace null values for prev_ columns
    aggDf = aggDf
      .withColumn("prev_brand_rx", when(col("prev_brand_rx").isNull, lit(0)).otherwise(col("prev_brand_rx")))
      .withColumn("prev_market_rx", when(col("prev_market_rx").isNull, lit(0)).otherwise(col("prev_market_rx")))
      .withColumn("prev_group_id", when(col("prev_group_id").isNull, lit(0)).otherwise(col("prev_group_id")))

    aggDf = aggDf
      .withColumn("brand_rx_perc_change", brandRxPercentChangeWeek(col("brand_rx"), col("prev_brand_rx"),
        col("group_id"), col("prev_group_id")))

    aggDf = aggDf
      .withColumn("market_share_change", marketShareChangeWeek(col("brand_rx"), col("market_rx"), col("prev_brand_rx"),
        col("prev_market_rx"), col("group_id"), col("prev_group_id")))

    // filter out first week
    aggDf = aggDf
      .where(col("group_id").notEqual(lit(firstFriday)))
      .drop("prev_brand_rx")
      .drop("prev_market_rx")
      .drop("prev_group_id")

    aggDf
      .withColumn("week_code", getWeekCode(col("group_id")))
      .withColumnRenamed("group_id", "week_id")
  }
}