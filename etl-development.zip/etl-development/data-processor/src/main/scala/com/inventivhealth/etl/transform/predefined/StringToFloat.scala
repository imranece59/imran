package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

import scala.util.{Failure, Success, Try}

class StringToFloat extends EtlFunction1[String, Float] {
  override val name: String = "convertStringToFloat"

  override def execute(s: String): Float = Try(s.toFloat) match {
    case Success(v) => v
    case Failure(ex) => 0
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
