package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class FilterByTenantId extends GroupOperation {
  override val name: String = "filterByTenantId"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val tenantId = parameters(ETLProcess.tenantIdParam)

    df.where(col("tenant_id").equalTo(tenantId))
  }
}