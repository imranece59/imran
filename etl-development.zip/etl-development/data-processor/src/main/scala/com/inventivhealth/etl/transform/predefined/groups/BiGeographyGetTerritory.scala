package com.inventivhealth.etl.transform.predefined.groups


import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class BiGeographyGetTerritory extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biGeoGetTer"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val tenantId = parameters(ETLProcess.tenantIdParam)
    val sqlContext = df.sqlContext

    val hierarchyDataExtractor = getDataExtractor(sourceName, "d_geography_hierarchy", false)
    var hierarchyDf = hierarchyDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (hierarchyDf.schema.fieldNames.contains("active_inactive"))  {
      hierarchyDf = hierarchyDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }
    hierarchyDf = hierarchyDf.select("geo_id", "geo_lvl_rnk", "prnt1_geo_id", "st_id")

    val geographyDataExtractor = getDataExtractor(sourceName, "d_geography", false)
    var geographyDf = geographyDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (geographyDf.schema.fieldNames.contains("active_inactive"))  {
      geographyDf = geographyDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }
    geographyDf = geographyDf.select("geo_id", "geo_nm")

    // join with hierarchy of 1st level
    var res = df.join(hierarchyDf, df("geo_id") === hierarchyDf("geo_id") and df("st_id") === hierarchyDf("st_id") and hierarchyDf("geo_lvl_rnk").cast("int") === lit(1))
      .select(df("*"))

    // join with geography and get territory name
    res = res.join(geographyDf, res("geo_id") === geographyDf("geo_id"))
      .select(res("*"), geographyDf("geo_nm") as "territory_name")

    res.drop("geo_id")
  }
}