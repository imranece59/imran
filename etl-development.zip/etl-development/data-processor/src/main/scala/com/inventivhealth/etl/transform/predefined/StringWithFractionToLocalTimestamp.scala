package com.inventivhealth.etl.transform.predefined

import java.sql.Timestamp
import java.time.format.DateTimeFormatter
import java.time.{LocalDateTime, ZoneOffset}

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

import scala.util.{Failure, Success, Try}

class StringWithFractionToLocalTimestamp extends EtlFunction1[String, Option[Timestamp]] {
  override val name: String = "convertWithFractionToLocalTimestamp"

  override def execute(s: String): Option[Timestamp] = Option(s) match {
    case Some(srt) =>
      val format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S")
      Try(LocalDateTime.parse(srt, format)) match {
        case Success(dt) =>
          val time = dt.toInstant(ZoneOffset.UTC).toEpochMilli
          Some(new Timestamp(time))
        case Failure(_) => None
      }
    case None => None
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}