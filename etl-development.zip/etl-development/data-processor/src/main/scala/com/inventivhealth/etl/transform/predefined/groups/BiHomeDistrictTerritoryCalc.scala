package com.inventivhealth.etl.transform.predefined.groups

import java.time.{LocalDate, ZoneOffset}
import java.time.format.DateTimeFormatter
import java.time.temporal.WeekFields

import com.inventivhealth.etl.bi._
import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

class BiHomeDistrictTerritoryCalc extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biHomeDistTerCalc"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    // get current week
    val currentWeek = GroupObject.broadcasts.value("current_week")

    // previous, 3rd and 4th weeks
    val format = DateTimeFormatter.ofPattern("yyyyMMdd")
    val field = WeekFields.ISO.dayOfWeek()
    val prevWeekDate = LocalDate.parse(currentWeek, format).atStartOfDay(ZoneOffset.UTC).minusWeeks(1).`with`(field, 5)
    val thirdWeekDate = LocalDate.parse(currentWeek, format).atStartOfDay(ZoneOffset.UTC).minusWeeks(2).`with`(field, 5)
    val fourthWeekDate = LocalDate.parse(currentWeek, format).atStartOfDay(ZoneOffset.UTC).minusWeeks(3).`with`(field, 5)
    val previousWeek = prevWeekDate.format(format)
    val thirdWeek = thirdWeekDate.format(format)
    val fourthWeek = fourthWeekDate.format(format)

    // cache input df
    df.persist(StorageLevel.MEMORY_AND_DISK_SER)

    /**
      * get territory level
      * distinct payer rows after joins
      */
    val allDf = df
      .select("wk_id", "fin_brnd_id", "mkt_pid", "sls_chnl_desc", "prsc_cid", "tenant_id", "st_id", "market_name",
        "brand_name", "territory_name", "district_name", "rx", "week_id", "segment", "segment_type")
      .distinct()

    // get only district level
    val allDistrictDf = df
      .select("wk_id", "fin_brnd_id", "mkt_pid", "sls_chnl_desc", "prsc_cid", "tenant_id", "st_id", "market_name",
        "brand_name", "district_name", "rx", "week_id", "segment", "segment_type")
      .distinct()

    // territory level
    // territory_NBRx/territory_prescriber_count
    var aggDf = allDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "district_name", "week_id", "segment", "segment_type")
      .agg(sum("rx") as "territory_nbrx", expr("count(case when rx > 0 then tenant_id else null end)") as "territory_prescriber_count")

    // territory_current_week_NBRx/territory_current_prescriber_count/territory_prev_week_nbrx/territory_prev_week_prescriber_count/3rd/4th
    var pivotDf = aggDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "district_name", "segment", "segment_type")
        .pivot("week_id", Seq(currentWeek, previousWeek, thirdWeek, fourthWeek))
        .max("territory_nbrx", "territory_prescriber_count")
      .withColumnRenamed(currentWeek + "_max(territory_nbrx)", "territory_current_week_nbrx")
      .withColumnRenamed(currentWeek + "_max(territory_prescriber_count)", "territory_current_prescriber_count")
      .withColumnRenamed(previousWeek + "_max(territory_nbrx)", "territory_prev_week_nbrx")
      .withColumnRenamed(previousWeek + "_max(territory_prescriber_count)", "territory_prev_week_prescriber_count")
      .withColumnRenamed(thirdWeek + "_max(territory_nbrx)", "territory_3rd_week_nbrx")
      .withColumnRenamed(thirdWeek + "_max(territory_prescriber_count)", "territory_3rd_week_prescriber_count")
      .withColumnRenamed(fourthWeek + "_max(territory_nbrx)", "territory_4th_week_nbrx")
      .withColumnRenamed(fourthWeek + "_max(territory_prescriber_count)", "territory_4th_week_prescriber_count")

    // replace nulls with zeros
    pivotDf = pivotDf
      .withColumn("territory_current_week_nbrx", when(col("territory_current_week_nbrx").isNull, lit(0)).otherwise(col("territory_current_week_nbrx")))
      .withColumn("territory_current_prescriber_count", when(col("territory_current_prescriber_count").isNull, lit(0)).otherwise(col("territory_current_prescriber_count")))
      .withColumn("territory_prev_week_nbrx", when(col("territory_prev_week_nbrx").isNull, lit(0)).otherwise(col("territory_prev_week_nbrx")))
      .withColumn("territory_prev_week_prescriber_count", when(col("territory_prev_week_prescriber_count").isNull, lit(0)).otherwise(col("territory_prev_week_prescriber_count")))
      .withColumn("territory_3rd_week_nbrx", when(col("territory_3rd_week_nbrx").isNull, lit(0)).otherwise(col("territory_3rd_week_nbrx")))
      .withColumn("territory_3rd_week_prescriber_count", when(col("territory_3rd_week_prescriber_count").isNull, lit(0)).otherwise(col("territory_3rd_week_prescriber_count")))
      .withColumn("territory_4th_week_nbrx", when(col("territory_4th_week_nbrx").isNull, lit(0)).otherwise(col("territory_4th_week_nbrx")))
      .withColumn("territory_4th_week_prescriber_count", when(col("territory_4th_week_prescriber_count").isNull, lit(0)).otherwise(col("territory_4th_week_prescriber_count")))

    // territory_4_week_NBRx/territory_4_week_prescriber_count
    pivotDf = pivotDf
      .withColumn("territory_4_week_nbrx", col("territory_current_week_nbrx") + col("territory_prev_week_nbrx") + col("territory_3rd_week_nbrx") + col("territory_4th_week_nbrx"))
      .withColumn("territory_4_week_prescriber_count", col("territory_current_prescriber_count") + col("territory_prev_week_prescriber_count") + col("territory_3rd_week_prescriber_count") + col("territory_4th_week_prescriber_count"))
      .drop("territory_3rd_week_nbrx")
      .drop("territory_3rd_week_prescriber_count")
      .drop("territory_4th_week_nbrx")
      .drop("territory_4th_week_prescriber_count")

    // territory_NBRx_perc_change/territory_prescriber_count_perc_change
    pivotDf = pivotDf
      .withColumn("territory_nbrx_perc_change", brandRxPercentChange(col("territory_current_week_nbrx"), col("territory_prev_week_nbrx")))
      .withColumn("territory_prescriber_count_perc_change", brandRxPercentChange(col("territory_current_prescriber_count"), col("territory_prev_week_prescriber_count")))

    // join weekly and pivot data
    aggDf = aggDf.join(pivotDf, Seq("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "district_name", "segment", "segment_type"))
      .select(aggDf("*"), pivotDf("territory_current_week_nbrx"), pivotDf("territory_current_prescriber_count"), pivotDf("territory_prev_week_nbrx"), pivotDf("territory_prev_week_prescriber_count"),
        pivotDf("territory_4_week_nbrx"), pivotDf("territory_4_week_prescriber_count"), pivotDf("territory_nbrx_perc_change"), pivotDf("territory_prescriber_count_perc_change"))

    // district level
    // district_NBRx/district_prescriber_count
    var aggDistrictDf = allDistrictDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "district_name", "week_id", "segment", "segment_type")
      .agg(sum("rx") as "district_nbrx", expr("count(case when rx > 0 then tenant_id else null end)") as "district_prescriber_count")

    // district_current_week_NBRx/district_current_prescriber_count/district_prev_week_NBRx/district_prev_week_prescriber_count/3rd/4th
    var pivotDistrictDf = aggDistrictDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "district_name", "segment", "segment_type")
      .pivot("week_id", Seq(currentWeek, previousWeek, thirdWeek, fourthWeek))
      .max("district_nbrx", "district_prescriber_count")
      .withColumnRenamed(currentWeek + "_max(district_nbrx)", "district_current_week_nbrx")
      .withColumnRenamed(currentWeek + "_max(district_prescriber_count)", "district_current_prescriber_count")
      .withColumnRenamed(previousWeek + "_max(district_nbrx)", "district_prev_week_nbrx")
      .withColumnRenamed(previousWeek + "_max(district_prescriber_count)", "district_prev_week_prescriber_count")
      .withColumnRenamed(thirdWeek + "_max(district_nbrx)", "district_3rd_week_nbrx")
      .withColumnRenamed(thirdWeek + "_max(district_prescriber_count)", "district_3rd_week_prescriber_count")
      .withColumnRenamed(fourthWeek + "_max(district_nbrx)", "district_4th_week_nbrx")
      .withColumnRenamed(fourthWeek + "_max(district_prescriber_count)", "district_4th_week_prescriber_count")

    // replace nulls with zeros
    pivotDistrictDf = pivotDistrictDf
      .withColumn("district_current_week_nbrx", when(col("district_current_week_nbrx").isNull, lit(0)).otherwise(col("district_current_week_nbrx")))
      .withColumn("district_current_prescriber_count", when(col("district_current_prescriber_count").isNull, lit(0)).otherwise(col("district_current_prescriber_count")))
      .withColumn("district_prev_week_nbrx", when(col("district_prev_week_nbrx").isNull, lit(0)).otherwise(col("district_prev_week_nbrx")))
      .withColumn("district_prev_week_prescriber_count", when(col("district_prev_week_prescriber_count").isNull, lit(0)).otherwise(col("district_prev_week_prescriber_count")))
      .withColumn("district_3rd_week_nbrx", when(col("district_3rd_week_nbrx").isNull, lit(0)).otherwise(col("district_3rd_week_nbrx")))
      .withColumn("district_3rd_week_prescriber_count", when(col("district_3rd_week_prescriber_count").isNull, lit(0)).otherwise(col("district_3rd_week_prescriber_count")))
      .withColumn("district_4th_week_nbrx", when(col("district_4th_week_nbrx").isNull, lit(0)).otherwise(col("district_4th_week_nbrx")))
      .withColumn("district_4th_week_prescriber_count", when(col("district_4th_week_prescriber_count").isNull, lit(0)).otherwise(col("district_4th_week_prescriber_count")))

    // district_4_week_NBRx/district_4_week_prescriber_count
    pivotDistrictDf = pivotDistrictDf
      .withColumn("district_4_week_nbrx", col("district_current_week_nbrx") + col("district_prev_week_nbrx") + col("district_3rd_week_nbrx") + col("district_4th_week_nbrx"))
      .withColumn("district_4_week_prescriber_count", col("district_current_prescriber_count") + col("district_prev_week_prescriber_count") + col("district_3rd_week_prescriber_count") + col("district_4th_week_prescriber_count"))
      .drop("district_3rd_week_nbrx")
      .drop("district_3rd_week_prescriber_count")
      .drop("district_4th_week_nbrx")
      .drop("district_4th_week_prescriber_count")

    // district_NBRx_perc_change/district_prescriber_count_perc_change
    pivotDistrictDf = pivotDistrictDf
      .withColumn("district_nbrx_perc_change", brandRxPercentChange(col("district_current_week_nbrx"), col("district_prev_week_nbrx")))
      .withColumn("district_prescriber_count_perc_change", brandRxPercentChange(col("district_current_prescriber_count"), col("district_prev_week_prescriber_count")))

    // join weekly and pivot data
    aggDistrictDf = aggDistrictDf.join(pivotDistrictDf, Seq("tenant_id", "st_id", "market_name", "brand_name", "district_name", "segment", "segment_type"))
      .select(aggDistrictDf("*"), pivotDistrictDf("district_current_week_nbrx"), pivotDistrictDf("district_current_prescriber_count"), pivotDistrictDf("district_prev_week_nbrx"),
        pivotDistrictDf("district_prev_week_prescriber_count"), pivotDistrictDf("district_4_week_nbrx"), pivotDistrictDf("district_4_week_prescriber_count"),
        pivotDistrictDf("district_nbrx_perc_change"), pivotDistrictDf("district_prescriber_count_perc_change"))

    // join territory and district aggregations
    aggDf = aggDf.join(aggDistrictDf, Seq("tenant_id", "st_id", "market_name", "brand_name", "district_name", "segment", "segment_type", "week_id"))
      .select(aggDf("*"), aggDistrictDf("district_nbrx"), aggDistrictDf("district_prescriber_count"),
        aggDistrictDf("district_current_week_nbrx"), aggDistrictDf("district_current_prescriber_count"),
        aggDistrictDf("district_prev_week_nbrx"), aggDistrictDf("district_prev_week_prescriber_count"),
        aggDistrictDf("district_4_week_nbrx"), aggDistrictDf("district_4_week_prescriber_count"),
        aggDistrictDf("district_nbrx_perc_change"), aggDistrictDf("district_prescriber_count_perc_change"))

    // metric_type - NBRx
    aggDf = aggDf.withColumn("metric_type", lit("NBRX"))

    // resolve week_code
    aggDf.withColumn("week_code", getWeekCode(col("week_id")))
  }
}