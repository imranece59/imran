package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class DSfaStIdLookup extends EtlFunction0[Int] {
  override val name: String = "dSfaStIdLkp"

  override def execute(): Int = {
    broadcasts.value.get("d_sfa").flatMap {
      _.filter(row => row.getAs[String]("st_nm").equals("ADVAIR TEAM"))
        .map(_.getAs[Int]("st_id"))
        .headOption
    }.getOrElse(-1)
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}