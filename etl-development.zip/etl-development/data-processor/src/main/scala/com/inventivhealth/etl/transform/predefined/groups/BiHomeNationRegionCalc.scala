package com.inventivhealth.etl.transform.predefined.groups

import java.time.{LocalDate, ZoneOffset}
import java.time.format.DateTimeFormatter
import java.time.temporal.WeekFields

import com.inventivhealth.etl.bi._
import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

class BiHomeNationRegionCalc extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biHomeNatRegCalc"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    // get current week
    val currentWeek = GroupObject.broadcasts.value("current_week")

    // previous, 3rd and 4th weeks
    val format = DateTimeFormatter.ofPattern("yyyyMMdd")
    val field = WeekFields.ISO.dayOfWeek()
    val prevWeekDate = LocalDate.parse(currentWeek, format).atStartOfDay(ZoneOffset.UTC).minusWeeks(1).`with`(field, 5)
    val thirdWeekDate = LocalDate.parse(currentWeek, format).atStartOfDay(ZoneOffset.UTC).minusWeeks(2).`with`(field, 5)
    val fourthWeekDate = LocalDate.parse(currentWeek, format).atStartOfDay(ZoneOffset.UTC).minusWeeks(3).`with`(field, 5)
    val previousWeek = prevWeekDate.format(format)
    val thirdWeek = thirdWeekDate.format(format)
    val fourthWeek = fourthWeekDate.format(format)

    // cache input df
    df.persist(StorageLevel.MEMORY_AND_DISK_SER)

    /**
      * get region level
      * distinct payer rows after joins
      */
    val allDf = df
      .select("wk_id", "fin_brnd_id", "mkt_pid", "sls_chnl_desc", "prsc_cid", "tenant_id", "st_id", "market_name",
        "brand_name", "region_name", "nation_name", "rx", "week_id", "segment", "segment_type")
      .distinct()

    // get only nation level
    val allNationDf = df
      .select("wk_id", "fin_brnd_id", "mkt_pid", "sls_chnl_desc", "prsc_cid", "tenant_id", "st_id", "market_name",
        "brand_name", "nation_name", "rx", "week_id", "segment", "segment_type")
      .distinct()

    // region level
    // region_NBRx/region_prescriber_count
    var aggDf = allDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "region_name", "nation_name", "week_id", "segment", "segment_type")
      .agg(sum("rx") as "region_nbrx", expr("count(case when rx > 0 then tenant_id else null end)") as "region_prescriber_count")

    // region_current_week_NBRx/region_current_prescriber_count/region_prev_week_nbrx/region_prev_week_prescriber_count/3rd/4th
    var pivotDf = aggDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "region_name", "nation_name", "segment", "segment_type")
      .pivot("week_id", Seq(currentWeek, previousWeek, thirdWeek, fourthWeek))
      .max("region_nbrx", "region_prescriber_count")
      .withColumnRenamed(currentWeek + "_max(region_nbrx)", "region_current_week_nbrx")
      .withColumnRenamed(currentWeek + "_max(region_prescriber_count)", "region_current_prescriber_count")
      .withColumnRenamed(previousWeek + "_max(region_nbrx)", "region_prev_week_nbrx")
      .withColumnRenamed(previousWeek + "_max(region_prescriber_count)", "region_prev_week_prescriber_count")
      .withColumnRenamed(thirdWeek + "_max(region_nbrx)", "region_3rd_week_nbrx")
      .withColumnRenamed(thirdWeek + "_max(region_prescriber_count)", "region_3rd_week_prescriber_count")
      .withColumnRenamed(fourthWeek + "_max(region_nbrx)", "region_4th_week_nbrx")
      .withColumnRenamed(fourthWeek + "_max(region_prescriber_count)", "region_4th_week_prescriber_count")

    // replace nulls with zeros
    pivotDf = pivotDf
      .withColumn("region_current_week_nbrx", when(col("region_current_week_nbrx").isNull, lit(0)).otherwise(col("region_current_week_nbrx")))
      .withColumn("region_current_prescriber_count", when(col("region_current_prescriber_count").isNull, lit(0)).otherwise(col("region_current_prescriber_count")))
      .withColumn("region_prev_week_nbrx", when(col("region_prev_week_nbrx").isNull, lit(0)).otherwise(col("region_prev_week_nbrx")))
      .withColumn("region_prev_week_prescriber_count", when(col("region_prev_week_prescriber_count").isNull, lit(0)).otherwise(col("region_prev_week_prescriber_count")))
      .withColumn("region_3rd_week_nbrx", when(col("region_3rd_week_nbrx").isNull, lit(0)).otherwise(col("region_3rd_week_nbrx")))
      .withColumn("region_3rd_week_prescriber_count", when(col("region_3rd_week_prescriber_count").isNull, lit(0)).otherwise(col("region_3rd_week_prescriber_count")))
      .withColumn("region_4th_week_nbrx", when(col("region_4th_week_nbrx").isNull, lit(0)).otherwise(col("region_4th_week_nbrx")))
      .withColumn("region_4th_week_prescriber_count", when(col("region_4th_week_prescriber_count").isNull, lit(0)).otherwise(col("region_4th_week_prescriber_count")))

    // region_4_week_NBRx/region_4_week_prescriber_count
    pivotDf = pivotDf
      .withColumn("region_4_week_nbrx", col("region_current_week_nbrx") + col("region_prev_week_nbrx") + col("region_3rd_week_nbrx") + col("region_4th_week_nbrx"))
      .withColumn("region_4_week_prescriber_count", col("region_current_prescriber_count") + col("region_prev_week_prescriber_count") + col("region_3rd_week_prescriber_count") + col("region_4th_week_prescriber_count"))
      .drop("region_3rd_week_nbrx")
      .drop("region_3rd_week_prescriber_count")
      .drop("region_4th_week_nbrx")
      .drop("region_4th_week_prescriber_count")

    // region_NBRx_perc_change/region_prescriber_count_perc_change
    pivotDf = pivotDf
      .withColumn("region_nbrx_perc_change", brandRxPercentChange(col("region_current_week_nbrx"), col("region_prev_week_nbrx")))
      .withColumn("region_prescriber_count_perc_change", brandRxPercentChange(col("region_current_prescriber_count"), col("region_prev_week_prescriber_count")))

    // join weekly and pivot data
    aggDf = aggDf.join(pivotDf, Seq("tenant_id", "st_id", "market_name", "brand_name", "region_name", "nation_name", "segment", "segment_type"))
      .select(aggDf("*"), pivotDf("region_current_week_nbrx"), pivotDf("region_current_prescriber_count"), pivotDf("region_prev_week_nbrx"), pivotDf("region_prev_week_prescriber_count"),
        pivotDf("region_4_week_nbrx"), pivotDf("region_4_week_prescriber_count"), pivotDf("region_nbrx_perc_change"), pivotDf("region_prescriber_count_perc_change"))

    // nation level
    // nation_NBRx/nation_prescriber_count
    var aggNationDf = allNationDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "nation_name", "week_id", "segment", "segment_type")
      .agg(sum("rx") as "nation_nbrx", expr("count(case when rx > 0 then tenant_id else null end)") as "nation_prescriber_count")

    // nation_current_week_NBRx/nation_current_prescriber_count/nation_prev_week_NBRx/nation_prev_week_prescriber_count/3rd/4th
    var pivotNationDf = aggNationDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "nation_name", "segment", "segment_type")
      .pivot("week_id", Seq(currentWeek, previousWeek, thirdWeek, fourthWeek))
      .max("nation_nbrx", "nation_prescriber_count")
      .withColumnRenamed(currentWeek + "_max(nation_nbrx)", "nation_current_week_nbrx")
      .withColumnRenamed(currentWeek + "_max(nation_prescriber_count)", "nation_current_prescriber_count")
      .withColumnRenamed(previousWeek + "_max(nation_nbrx)", "nation_prev_week_nbrx")
      .withColumnRenamed(previousWeek + "_max(nation_prescriber_count)", "nation_prev_week_prescriber_count")
      .withColumnRenamed(thirdWeek + "_max(nation_nbrx)", "nation_3rd_week_nbrx")
      .withColumnRenamed(thirdWeek + "_max(nation_prescriber_count)", "nation_3rd_week_prescriber_count")
      .withColumnRenamed(fourthWeek + "_max(nation_nbrx)", "nation_4th_week_nbrx")
      .withColumnRenamed(fourthWeek + "_max(nation_prescriber_count)", "nation_4th_week_prescriber_count")

    // replace nulls with zeros
    pivotNationDf = pivotNationDf
      .withColumn("nation_current_week_nbrx", when(col("nation_current_week_nbrx").isNull, lit(0)).otherwise(col("nation_current_week_nbrx")))
      .withColumn("nation_current_prescriber_count", when(col("nation_current_prescriber_count").isNull, lit(0)).otherwise(col("nation_current_prescriber_count")))
      .withColumn("nation_prev_week_nbrx", when(col("nation_prev_week_nbrx").isNull, lit(0)).otherwise(col("nation_prev_week_nbrx")))
      .withColumn("nation_prev_week_prescriber_count", when(col("nation_prev_week_prescriber_count").isNull, lit(0)).otherwise(col("nation_prev_week_prescriber_count")))
      .withColumn("nation_3rd_week_nbrx", when(col("nation_3rd_week_nbrx").isNull, lit(0)).otherwise(col("nation_3rd_week_nbrx")))
      .withColumn("nation_3rd_week_prescriber_count", when(col("nation_3rd_week_prescriber_count").isNull, lit(0)).otherwise(col("nation_3rd_week_prescriber_count")))
      .withColumn("nation_4th_week_nbrx", when(col("nation_4th_week_nbrx").isNull, lit(0)).otherwise(col("nation_4th_week_nbrx")))
      .withColumn("nation_4th_week_prescriber_count", when(col("nation_4th_week_prescriber_count").isNull, lit(0)).otherwise(col("nation_4th_week_prescriber_count")))

    // nation_4_week_NBRx/nation_4_week_prescriber_count
    pivotNationDf = pivotNationDf
      .withColumn("nation_4_week_nbrx", col("nation_current_week_nbrx") + col("nation_prev_week_nbrx") + col("nation_3rd_week_nbrx") + col("nation_4th_week_nbrx"))
      .withColumn("nation_4_week_prescriber_count", col("nation_current_prescriber_count") + col("nation_prev_week_prescriber_count") + col("nation_3rd_week_prescriber_count") + col("nation_4th_week_prescriber_count"))
      .drop("nation_3rd_week_nbrx")
      .drop("nation_3rd_week_prescriber_count")
      .drop("nation_4th_week_nbrx")
      .drop("nation_4th_week_prescriber_count")

    // nation_NBRx_perc_change/nation_prescriber_count_perc_change
    pivotNationDf = pivotNationDf
      .withColumn("nation_nbrx_perc_change", brandRxPercentChange(col("nation_current_week_nbrx"), col("nation_prev_week_nbrx")))
      .withColumn("nation_prescriber_count_perc_change", brandRxPercentChange(col("nation_current_prescriber_count"), col("nation_prev_week_prescriber_count")))

    // join weekly and pivot data
    aggNationDf = aggNationDf.join(pivotNationDf, Seq("tenant_id", "st_id", "market_name", "brand_name", "nation_name", "segment", "segment_type"))
      .select(aggNationDf("*"), pivotNationDf("nation_current_week_nbrx"), pivotNationDf("nation_current_prescriber_count"), pivotNationDf("nation_prev_week_nbrx"),
        pivotNationDf("nation_prev_week_prescriber_count"), pivotNationDf("nation_4_week_nbrx"), pivotNationDf("nation_4_week_prescriber_count"),
        pivotNationDf("nation_nbrx_perc_change"), pivotNationDf("nation_prescriber_count_perc_change"))

    // join region and nation aggregations
    aggDf = aggDf.join(aggNationDf, Seq("tenant_id", "st_id", "market_name", "brand_name", "nation_name", "segment", "segment_type", "week_id"))
      .select(aggDf("*"), aggNationDf("nation_nbrx"), aggNationDf("nation_prescriber_count"),
        aggNationDf("nation_current_week_nbrx"), aggNationDf("nation_current_prescriber_count"),
        aggNationDf("nation_prev_week_nbrx"), aggNationDf("nation_prev_week_prescriber_count"),
        aggNationDf("nation_4_week_nbrx"), aggNationDf("nation_4_week_prescriber_count"),
        aggNationDf("nation_nbrx_perc_change"), aggNationDf("nation_prescriber_count_perc_change"))

    // metric_type - NBRx
    aggDf = aggDf.withColumn("metric_type", lit("NBRX"))

    // resolve week_code
    aggDf.withColumn("week_code", getWeekCode(col("week_id")))
  }
}