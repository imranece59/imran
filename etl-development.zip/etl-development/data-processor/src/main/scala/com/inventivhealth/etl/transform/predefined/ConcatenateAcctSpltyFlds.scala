package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.process.ETLProcess._
import com.inventivhealth.etl.transform.api.EtlFunction2
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class ConcatenateAcctSpltyFlds extends EtlFunction2[String, String, String] {
  override val name: String = "concatAcctSpltyFlds"

  override def execute(a: String, b: String): String = {
    if (a == null || b == null) {
      null
    } else {
      val tenantId = parameters(tenantIdParam).toString
      val f = a.trim
      val s = b.trim
      s"$tenantId:$f:$s"
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
