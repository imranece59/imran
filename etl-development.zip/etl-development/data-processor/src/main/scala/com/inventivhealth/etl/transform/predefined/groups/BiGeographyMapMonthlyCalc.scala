package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.bi._
import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

class BiGeographyMapMonthlyCalc extends GroupOperation {
  override val name: String = "biGeoMapMonthCalc"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    // start month date
    val startMonth = GroupObject.broadcasts.value("start_month").toInt

    // filter out empty customer name
    var allDf = df.where((col("frst_nm").isNotNull || col("lst_nm").isNotNull || col("mddl_nm").isNotNull))

    allDf = allDf
      .withColumn("customer_full_name", getCustomerFullName(col("lst_nm"), col("frst_nm"), col("mddl_nm")))
      .drop("lst_nm")
      .drop("frst_nm")
      .drop("mddl_nm")

    // distinct payer rows after joins
    allDf = allDf
      .select("month_date", "fin_brnd_id", "mkt_pid", "prsc_cid", "pyr_id", "id", "payment_type", "tenant_id",
        "st_id", "market_name", "brand_name", "territory_name", "trx_vol", "nrx_vol", "customer_full_name",
        "plan", "zip", "latitude", "longitude")
      .distinct()

    // explode nrx and trx columns to 2 rows
    val toArray = udf { (nrx: Double, trx: Double) => Array(nrx -> "NRX", trx -> "TRX") }

    allDf = allDf
      .withColumn("rx_array", toArray(col("nrx_vol"), col("trx_vol")))
      .withColumn("rx_", explode(col("rx_array")))
      .drop("rx_array")
      .select(allDf("*"), col("rx_.*"))
      .drop("nrx_vol")
      .drop("trx_vol")
      .withColumnRenamed("_1", "rx_vol")
      .withColumnRenamed("_2", "metric_type")

    // calculate brand_rx, total_brand_rx and market_rx
    var aggDf = allDf
      .withColumn("brand_rx",
        sum(col("rx_vol"))
          .over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "metric_type", "month_date",
            "customer_full_name", "zip", "plan", "payment_type", "latitude", "longitude")))
      .withColumn("total_brand_rx",
        sum(col("rx_vol"))
          .over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "metric_type", "month_date",
            "customer_full_name", "zip", "latitude", "longitude")))
      .withColumn("market_rx",
        sum(col("rx_vol"))
          .over(Window.partitionBy("tenant_id", "st_id", "market_name", "territory_name", "metric_type", "month_date",
            "customer_full_name", "zip", "plan", "payment_type", "latitude", "longitude")))
      .select("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "metric_type", "month_date",
        "customer_full_name", "zip", "plan", "payment_type", "latitude", "longitude", "brand_rx", "total_brand_rx", "market_rx")
      .distinct()

    // calculate prev_brand_rx and prev_market_rx, get prev month_date
    aggDf = aggDf
      .withColumn("prev_brand_rx",
        lag("brand_rx", 1)
          .over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "metric_type",
            "customer_full_name", "zip", "plan", "payment_type", "latitude", "longitude").orderBy("month_date")))
      .withColumn("prev_market_rx",
        lag("market_rx", 1)
          .over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "metric_type",
            "customer_full_name", "zip", "plan", "payment_type", "latitude", "longitude").orderBy("month_date")))
      .withColumn("prev_month_date",
        lag("month_date", 1)
          .over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "territory_name", "metric_type",
            "customer_full_name", "zip", "plan", "payment_type", "latitude", "longitude").orderBy("month_date")))

    aggDf = aggDf
      .withColumn("percent_of_bus", marketShare(col("brand_rx"), col("total_brand_rx")))

    aggDf = aggDf
      .withColumn("market_share", marketShare(col("brand_rx"), col("market_rx")))

    // replace null values for prev_ columns
    aggDf = aggDf
      .withColumn("prev_brand_rx", when(col("prev_brand_rx").isNull, lit(0)).otherwise(col("prev_brand_rx")))
      .withColumn("prev_market_rx", when(col("prev_market_rx").isNull, lit(0)).otherwise(col("prev_market_rx")))
      .withColumn("prev_month_date", when(col("prev_month_date").isNull, lit(0)).otherwise(col("prev_month_date")))

    aggDf = aggDf
      .withColumn("brand_rx_perc_change", brandRxPercentChangeMonth(col("brand_rx"), col("prev_brand_rx"),
        col("month_date"), col("prev_month_date")))

    aggDf = aggDf
      .withColumn("market_share_change", marketShareChangeMonth(col("brand_rx"), col("market_rx"), col("prev_brand_rx"),
        col("prev_market_rx"), col("month_date"), col("prev_month_date")))

    aggDf = aggDf
      .drop("total_brand_rx")
      .drop("prev_brand_rx")
      .drop("prev_market_rx")

    // filter out first month
    aggDf = aggDf.where(col("month_date") !== lit(startMonth))

    aggDf
      .withColumn("month_info", getMonthInfo(col("month_date")))
      .withColumn("month_id" , col("month_info._1"))
      .withColumn("month_name", col("month_info._2"))
      .drop("month_info")
      .drop("month_date")
      .drop("prev_month_date")
  }
}