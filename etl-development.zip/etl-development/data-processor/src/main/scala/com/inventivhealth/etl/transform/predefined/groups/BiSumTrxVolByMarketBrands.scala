package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class BiSumTrxVolByMarketBrands extends GroupOperation {
  override val name: String = "biSumTrxVolByMarketBrands"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val replaceEmptyString = udf { (in: String) =>
      if (in == null || in.isEmpty) "N/A" else in
    }
    val dfWithTrxYtdBrand =
    df.groupBy("tenant_id", "st_id", "segment", "market_name", "brand_name", "segment_type",  "territory_name", "geo_nbr",
      "district_name", "customer_full_name", "accnt_id", "state", "zip", "address", "city", "month_id", "month_name")
      .agg(sum($"trx_vol") as "trx_vol_ytd")

    val dfWithTrxYtdMarket =
      dfWithTrxYtdBrand
      .withColumn("resp_market_trx", sum($"trx_vol_ytd").over(
        Window.partitionBy("tenant_id", "st_id", "market_name", "territory_name", "segment", "segment_type",
          "district_name", "accnt_id", "customer_full_name")))

    dfWithTrxYtdMarket
          .groupBy("tenant_id", "st_id", "market_name", "territory_name",  "segment", "segment_type", "month_id", "geo_nbr",
            "district_name", "month_name", "accnt_id", "customer_full_name", "resp_market_trx", "state",
            "zip", "address", "city")
          .pivot("brand_name", Seq("ADVAIR", "BREO", "DULERA", "SYMBICORT"))
          .sum("trx_vol_ytd")
          .drop($"market_name")
          .drop($"brand_name")
          .withColumnRenamed("ADVAIR", "advair_trx_ytd")
          .withColumnRenamed("BREO", "breo_trx_ytd")
          .withColumnRenamed("DULERA", "dulera_trx_ytd")
          .withColumnRenamed("SYMBICORT", "symbicort_trx_ytd")
          .withColumn("zip", replaceEmptyString($"zip"))
          .withColumn("state", replaceEmptyString($"state"))
          .withColumn("address", replaceEmptyString($"address"))
          .withColumn("city", replaceEmptyString($"city"))
  }

}
