package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class YNToTrueFalse extends EtlFunction1[String, Int] {
  override val name: String = "yNToOneZero"

  override def execute(s: String): Int = s match {
    case "Y" => 1
    case "N" => 0
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
