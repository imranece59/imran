package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils

class ActdbCustFullName extends GroupOperation {

  override val name: String = "actdbCustFullName"
  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    def concatName(a: String, b: String, c: String): String = { s"$a, $b $c" }
    val nameUDF = udf(concatName(_: String, _: String, _: String))
    df.withColumn("customer_full_name", nameUDF(df("lst_nm"), df("frst_nm"), df("mddl_nm")))
  }
}
