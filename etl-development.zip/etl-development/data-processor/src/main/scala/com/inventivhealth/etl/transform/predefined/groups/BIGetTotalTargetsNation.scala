package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class BIGetTotalTargetsNation extends GroupOperation {
  override val name: String = "biGetTotalTargetsNation"

  val cacheParam = "cache"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val defaultTarget = udf { (target: String) => if (target == null) "N" else target }

    if (operationParams.get(cacheParam).exists(_.toBoolean)) {
      df.cache()
      df.count()
    }

    val numWD = df.groupBy("tenant_id", "st_id", "geo_id", "district_id", "region_id", "nation_id", "month_id")
      .agg(countDistinct("call_dt_c") as "terr_number_working_days")
      .withColumn("reg_number_working_days", sum("terr_number_working_days").over(Window.partitionBy("tenant_id", "st_id", "region_id", "nation_id", "month_id")))
      .withColumn("nat_number_working_days", sum("terr_number_working_days").over(Window.partitionBy("tenant_id", "st_id", "nation_id", "month_id")))

    val tenantId = parameters(ETLProcess.tenantIdParam).asInstanceOf[Int]
    val alignments = df.sqlContext.read.format("org.apache.spark.sql.cassandra")
      .options(Map("table" -> "d_account_alignment", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]))
      .load()
      .where($"tenant_id" === lit(tenantId) and $"active_inactive" === lit("ACTIVE") and $"cust_attrib3" === lit("Y"))
      .select("geo_id", "accnt_id").distinct()

    val targets = df.select("geo_id", "district_id", "region_id", "nation_id").distinct()
      .join(alignments, Seq("geo_id"))

    val regTargets = targets.groupBy("region_id", "nation_id").agg(countDistinct("accnt_id") as "region_total_targets")
    val natTargets = targets.groupBy("nation_id").agg(countDistinct("accnt_id") as "nation_total_targets")

    df.join(numWD, Seq("tenant_id", "st_id", "geo_id", "district_id", "region_id", "nation_id", "month_id"))
      .join(regTargets, Seq("region_id", "nation_id"))
      .join(natTargets, Seq("nation_id"))
      .select(df("*"),
        numWD("reg_number_working_days"),
        numWD("nat_number_working_days"),
        regTargets("region_total_targets"),
        natTargets("nation_total_targets"))
      .withColumn("target", defaultTarget($"target"))
  }
}
