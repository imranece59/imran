package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class BIFAccountCallBrandMarketFilter extends GroupOperation {
  override val name: String = "biFAccountCallBrandMarketFilter"

  private val marketParam = "markets"
  private val brandParam = "brands"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val markets = operationParams.get(marketParam).map(_.split(","))
    val brands = operationParams.get(brandParam).map(_.split(","))

    val callDetails = df.sqlContext.read.format("org.apache.spark.sql.cassandra")
      .options(Map("table" -> "f_account_call_detail", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String])).load()

    var result = df.join(callDetails, Seq("accnt_call_id")).select(df("*"), callDetails("prdct_id"))

    var products = df.sqlContext.read.format("org.apache.spark.sql.cassandra")
      .options(Map("table" -> "d_product_sales_calls", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String])).load()
    if (brands.isDefined && brands.get.nonEmpty) {
      products = products.where($"brand_id".isin(brands.get: _*))
    }
    result = result.join(products, result("prdct_id") === products("product_id")).select(result("*"), products("brand_id"))

    val xref = df.sqlContext.read.format("org.apache.spark.sql.cassandra")
      .options(Map("table" -> "xref_mkt_def_brand_rx_nbrx", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String])).load()

    result = result.join(xref, result("brand_id") === xref("brand_id")).select(result("*"), xref("market_name"))

    if (markets.isDefined && markets.get.nonEmpty) {
      result = result.where(upper($"market_name").isin(markets.get:_*))
    }

    result
  }
}
