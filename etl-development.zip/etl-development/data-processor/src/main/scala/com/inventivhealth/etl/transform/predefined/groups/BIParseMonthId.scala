package com.inventivhealth.etl.transform.predefined.groups

import java.sql.Timestamp
import java.time.{YearMonth, ZoneOffset}
import java.time.format.{DateTimeFormatter, TextStyle}
import java.util.Locale

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.udf

class BIParseMonthId extends GroupOperation {
  override val name: String = "biParseMonthId"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val getMonth = udf { (moId: String) =>
      val format = DateTimeFormatter.ofPattern("yyyyMM")
      val date = YearMonth.parse(moId, format).atDay(1).atStartOfDay(ZoneOffset.UTC)
      val timestamp = new Timestamp(date.toInstant.toEpochMilli)
      val monthName = date.getMonth.getDisplayName(TextStyle.SHORT, Locale.getDefault)

      (timestamp, s"$monthName ${date.getYear}")
    }
    import df.sqlContext.implicits._
    df.withColumn("month_info", getMonth($"mo_id"))
      .withColumn("month_start", $"month_info._1")
      .withColumn("month_name", $"month_info._2")
      .withColumnRenamed("mo_id", "month_id")
      .drop("month_info")
  }

}
