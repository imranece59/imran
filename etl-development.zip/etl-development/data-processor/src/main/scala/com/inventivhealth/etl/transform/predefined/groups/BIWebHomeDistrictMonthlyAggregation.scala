package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.bi._
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class BIWebHomeDistrictMonthlyAggregation extends GroupOperation {
  override val name: String = "biWebHomeDistrictMonthlyAggregation"

  val cacheParam = "cache"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._

    if (operationParams.get(cacheParam).exists(_.toBoolean)) {
      df.cache()
      df.count()
    }

    val territoryAll = df
      .groupBy("tenant_id", "st_id", "territory_name", "district_name", "segment_type", "segment", "month_id", "month_name")
      .agg(countDistinct("accnt_call_id") as "total_prescriber_calls",
        first("terr_number_working_days") as "number_working_days", first("territory_total_targets") as "total_targets")

    val territoryTargets = df
      .where($"target" === lit("Y"))
      .groupBy("tenant_id", "st_id", "territory_name", "district_name", "segment_type", "segment", "month_id", "month_name")
      .agg(countDistinct("accnt_call_id") as "target_calls", countDistinct("accnt_id") as "targets_called")

    val districtAll = df
      .groupBy("tenant_id", "st_id", "district_name", "segment_type", "segment", "month_id", "month_name")
      .agg(countDistinct("accnt_call_id") as "total_prescriber_calls",
        first("dist_number_working_days") as "number_working_days", first("district_total_targets") as "total_targets")

    val districtTargets = df
      .where($"target" === lit("Y"))
      .groupBy("tenant_id", "st_id", "district_name", "segment_type", "segment", "month_id", "month_name")
      .agg(countDistinct("accnt_call_id") as "target_calls", countDistinct("accnt_id") as "targets_called")

    val territory = territoryAll
      .join(territoryTargets, Seq("tenant_id", "st_id", "territory_name", "district_name", "segment_type", "segment", "month_id", "month_name"), "left_outer")
      .select(territoryAll("*"), territoryTargets("target_calls"), territoryTargets("targets_called"))
      .withColumn("territory_avg_target_frequency", avgTargetFrequency($"target_calls", $"targets_called"))
      .withColumn("territory_avg_prescriber_calls_per_day", avgPrescriberCallsPerDay($"total_prescriber_calls", $"number_working_days"))
      .withColumn("territory_target_calls_per_day", targetCallsPerDay($"target_calls", $"number_working_days"))
      .withColumn("territory_percent_calls_to_targets", percentCallsToTargets($"target_calls", $"total_prescriber_calls"))
      .withColumn("territory_reach", reach($"targets_called", $"total_targets"))

    val district = districtAll
      .join(districtTargets, Seq("tenant_id", "st_id", "district_name", "segment_type", "segment", "month_id", "month_name"), "left_outer")
      .select(districtAll("*"), districtTargets("target_calls"), districtTargets("targets_called"))
      .withColumn("district_avg_target_frequency", avgTargetFrequency($"target_calls", $"targets_called"))
      .withColumn("district_avg_prescriber_calls_per_day", avgPrescriberCallsPerDay($"total_prescriber_calls", $"number_working_days"))
      .withColumn("district_target_calls_per_day", targetCallsPerDay($"target_calls", $"number_working_days"))
      .withColumn("district_percent_calls_to_targets", percentCallsToTargets($"target_calls", $"total_prescriber_calls"))
      .withColumn("district_reach", reach($"targets_called", $"total_targets"))

    territory
      .join(district, Seq("tenant_id", "st_id", "district_name", "segment_type", "segment", "month_id", "month_name"))
      .select(
        territory("tenant_id"),
        territory("st_id"),
        territory("territory_name"),
        territory("district_name"),
        territory("segment_type"),
        territory("segment"),
        territory("month_id"),
        territory("month_name"),
        territory("territory_avg_target_frequency"),
        territory("territory_avg_prescriber_calls_per_day"),
        territory("territory_target_calls_per_day"),
        territory("territory_percent_calls_to_targets"),
        territory("territory_reach"),
        district("district_avg_target_frequency"),
        district("district_avg_prescriber_calls_per_day"),
        district("district_target_calls_per_day"),
        district("district_percent_calls_to_targets"),
        district("district_reach"),

        territory("target_calls") as "territory_target_calls",
        territory("targets_called") as "territory_number_of_targets_called",
        territory("total_prescriber_calls") as "territory_total_prescriber_calls",
        territory("number_working_days") as "territory_number_of_work_days",
        territory("targets_called") as "territory_call_count", // identical
        territory("number_working_days") as "territory_target_number_of_work_days", //identical
        territory("total_targets") as "territory_total_targets",
        district("target_calls") as "district_target_calls",
        district("targets_called") as "district_number_of_targets_called",
        district("total_prescriber_calls") as "district_total_prescriber_calls",
        district("number_working_days") as "district_number_of_work_days",
        district("targets_called") as "district_call_count", // identical
        district("number_working_days") as "district_target_number_of_work_days", //identical
        district("total_targets") as "district_total_targets"
      )
  }

}
