package com.inventivhealth.etl.actdb

import org.joda.time.DateTime
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess

object ActdbHelper {

  val dfCacheMap = scala.collection.mutable.Map[String, DataFrame]()

  def leftOuterJoin(dfLeft: DataFrame, dfRight: DataFrame, joinCols: Array[String], selectFromRight: String): DataFrame = {

    val dfRight1 = joinCols.foldLeft(dfRight) { (frame, c) => frame.withColumnRenamed(c, c + "_temp") }

    val joinCond = joinCols.zip(joinCols.map(_ + "_temp")).
      map { case (s, l) => dfLeft(s) === dfRight1(l) }.
      reduceLeft(_ && _)

    dfLeft.join(dfRight1, joinCond, "left_outer").
      select(selectFromRight, dfLeft.columns: _*)

  }

  def leftOuterJoin(dfLeft: DataFrame, dfRight: DataFrame, joinCols: Array[String], selectFromRight: Array[String]): DataFrame = {

    val dfRight1 = joinCols.foldLeft(dfRight) { (frame, c) => frame.withColumnRenamed(c, c + "_temp") }

    val joinCond = joinCols.zip(joinCols.map(_ + "_temp")).
      map { case (s, l) => dfLeft(s) === dfRight1(l) }.
      reduceLeft(_ && _)

    dfLeft.join(dfRight1, joinCond, "left_outer").
      select(dfLeft("*") +: selectFromRight.map(dfRight(_)).toSeq: _*)

  }

  // Managing the DataFrame cache across group transformation
  // Will revise design later for more optimum one
  def persistDf(key: String, df: DataFrame) = {

    if (dfCacheMap.contains(key)) {
      val oldDf = dfCacheMap(key)
      if (oldDf eq df)
        println("The DataFrame is already persisted!")
      else {
        df.persist
        oldDf.unpersist
        dfCacheMap(key) = df
      }

    } else {

      df.persist
      dfCacheMap(key) = df

    }
  }

  def unpersistDf(key: String) = {

    if (dfCacheMap.contains(key)) {

      dfCacheMap(key).unpersist

    }
  }

}