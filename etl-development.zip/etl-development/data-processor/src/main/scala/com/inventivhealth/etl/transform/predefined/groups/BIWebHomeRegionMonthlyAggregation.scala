package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.bi._
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{countDistinct, first, lit}

class BIWebHomeRegionMonthlyAggregation extends GroupOperation {
  override val name: String = "biWebHomeRegionMonthlyAggregation"

  val cacheParam = "cache"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._

    if (operationParams.get(cacheParam).exists(_.toBoolean)) {
      df.cache()
      df.count()
    }

    val districtAll = df
      .groupBy("tenant_id", "st_id", "district_name", "region_name", "segment_type", "segment", "month_id", "month_name")
      .agg(countDistinct("accnt_call_id") as "total_prescriber_calls",
        first("dist_number_working_days") as "number_working_days", first("district_total_targets") as "total_targets")

    val districtTargets = df
      .where($"target" === lit("Y"))
      .groupBy("tenant_id", "st_id", "district_name", "region_name", "segment_type", "segment", "month_id", "month_name")
      .agg(countDistinct("accnt_call_id") as "target_calls", countDistinct("accnt_id") as "targets_called")

    val regionAll = df
      .groupBy("tenant_id", "st_id", "region_name", "segment_type", "segment", "month_id", "month_name")
      .agg(countDistinct("accnt_call_id") as "total_prescriber_calls",
        first("reg_number_working_days") as "number_working_days", first("region_total_targets") as "total_targets")

    val regionTargets = df
      .where($"target" === lit("Y"))
      .groupBy("tenant_id", "st_id", "region_name", "segment_type", "segment", "month_id", "month_name")
      .agg(countDistinct("accnt_call_id") as "target_calls", countDistinct("accnt_id") as "targets_called")

    val district = districtAll
      .join(districtTargets, Seq("tenant_id", "st_id", "district_name", "region_name", "segment_type", "segment", "month_id", "month_name"), "left_outer")
      .select(districtAll("*"), districtTargets("target_calls"), districtTargets("targets_called"))
      .withColumn("district_avg_target_frequency", avgTargetFrequency($"target_calls", $"targets_called"))
      .withColumn("district_avg_prescriber_calls_per_day", avgPrescriberCallsPerDay($"total_prescriber_calls", $"number_working_days"))
      .withColumn("district_target_calls_per_day", targetCallsPerDay($"target_calls", $"number_working_days"))
      .withColumn("district_percent_calls_to_targets", percentCallsToTargets($"target_calls", $"total_prescriber_calls"))
      .withColumn("district_reach", reach($"targets_called", $"total_targets"))

    val region = regionAll
      .join(regionTargets, Seq("tenant_id", "st_id", "region_name", "segment_type", "segment", "month_id", "month_name"), "left_outer")
      .select(regionAll("*"), regionTargets("target_calls"), regionTargets("targets_called"))
      .withColumn("region_avg_target_frequency", avgTargetFrequency($"target_calls", $"targets_called"))
      .withColumn("region_avg_prescriber_calls_per_day", avgPrescriberCallsPerDay($"total_prescriber_calls", $"number_working_days"))
      .withColumn("region_target_calls_per_day", targetCallsPerDay($"target_calls", $"number_working_days"))
      .withColumn("region_percent_calls_to_targets", percentCallsToTargets($"target_calls", $"total_prescriber_calls"))
      .withColumn("region_reach", reach($"targets_called", $"total_targets"))

    district
      .join(region, Seq("tenant_id", "st_id", "region_name", "segment_type", "segment", "month_id", "month_name"))
      .select(
        district("tenant_id"),
        district("st_id"),
        district("district_name"),
        district("region_name"),
        district("segment_type"),
        district("segment"),
        district("month_id"),
        district("month_name"),
        district("district_avg_target_frequency"),
        district("district_avg_prescriber_calls_per_day"),
        district("district_target_calls_per_day"),
        district("district_percent_calls_to_targets"),
        district("district_reach"),
        region("region_avg_target_frequency"),
        region("region_avg_prescriber_calls_per_day"),
        region("region_target_calls_per_day"),
        region("region_percent_calls_to_targets"),
        region("region_reach"),

        district("target_calls") as "district_target_calls",
        district("targets_called") as "district_number_of_targets_called",
        district("total_prescriber_calls") as "district_total_prescriber_calls",
        district("number_working_days") as "district_number_of_work_days",
        district("targets_called") as "district_call_count", // identical
        district("number_working_days") as "district_target_number_of_work_days", //identical
        district("total_targets") as "district_total_targets",
        region("target_calls") as "region_target_calls",
        region("targets_called") as "region_number_of_targets_called",
        region("total_prescriber_calls") as "region_total_prescriber_calls",
        region("number_working_days") as "region_number_of_work_days",
        region("targets_called") as "region_call_count", // identical
        region("number_working_days") as "region_target_number_of_work_days", //identical
        region("total_targets") as "region_total_targets"
      )
  }
}
