package com.inventivhealth.etl.config

import com.inventivhealth.etl.Args

trait ConfigComponent {
  val args: Args
  val appConfig: AppConfig
}
