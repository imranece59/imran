package com.inventivhealth.etl.persist

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SaveMode

trait DataSaver {
  def saveData(df: DataFrame): Unit
}

class CassandraDataSaver(keyspace: String, table: String) extends DataSaver {
  override def saveData(df: DataFrame): Unit = {
    df.write
      .format("org.apache.spark.sql.cassandra")
      .options(Map("table" -> table, "keyspace" -> keyspace))
      .mode(SaveMode.Append)
      .save()
  }
}

class CsvDataSaver(path: String, header: Boolean, delimiter: String) extends DataSaver {
  override def saveData(df: DataFrame): Unit = {
    df.write
      .format("com.databricks.spark.csv")
      .option("header", header.toString)
      .option("delimiter", delimiter)
      .save(path)
  }
}

class S3DataSaver(path: String, header: Boolean, delimiter: String) extends CsvDataSaver(s"s3a://$path", header, delimiter) {
  override def saveData(df: DataFrame): Unit = {
    super.saveData(df)
  }
}