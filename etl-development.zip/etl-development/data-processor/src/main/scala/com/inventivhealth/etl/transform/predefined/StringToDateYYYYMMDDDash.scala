package com.inventivhealth.etl.transform.predefined

import java.sql.{Date}
import java.text.SimpleDateFormat

import scala.reflect.runtime.universe
import scala.util.Failure
import scala.util.Success
import scala.util.Try
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import com.inventivhealth.etl.transform.api.EtlFunction1

class StringToDateDash extends EtlFunction1[String, Option[Date]] {
  override val name: String = "cnvrtToDtYYYY-MM-DD"

  override def execute(source: String): Option[Date] = {
    val format = new SimpleDateFormat("yyyy-MM-dd")
    Try(new Date(format.parse(source).getTime)) match {
      case Success(t) => Some(t)
      case Failure(_) => None
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
