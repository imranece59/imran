package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction2
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class DegreeTypeDescriptionLookup extends EtlFunction2[String, String, String] {
  override val name: String = "degTypDescLkp"

  override def execute(degCode: String, degTypeCode: String): String = {
    broadcasts.value.get("degree_lkp").flatMap {
      _.filter(row => row.getAs[String]("deg_cd") == degCode && row.getAs[String]("deg_typ_cd") == degTypeCode)
        .map(_.getAs[String]("deg_typ_desc"))
        .headOption
    }.orNull
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}