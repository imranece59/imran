package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class HardcodeDetailOnly extends EtlFunction0[String] {
  override val name: String = "hardcodeDetailOnly"

  override def execute(): String = "Detail Only"

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
