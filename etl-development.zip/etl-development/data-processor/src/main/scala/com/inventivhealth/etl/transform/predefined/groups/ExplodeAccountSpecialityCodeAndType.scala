package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class ExplodeAccountSpecialityCodeAndType extends GroupOperation {
  override val name: String = "explodeAccntSpecCode"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val toArray = udf { (amxSpecDesc: String, amxSpecSecnDesc: String, cnsnsSpecDesc: String, cnsnsSubSpecDesc: String) =>
      Array(
        amxSpecDesc -> "Primary",
        amxSpecSecnDesc -> "Secondary",
        cnsnsSpecDesc -> "Consensus",
        cnsnsSubSpecDesc -> "Sub Concensus")
    }

    val newDf = df
      .withColumn("SPCLTY_CDs", toArray(col("AMX_SPEC_DESC"), col("AMX_SPEC_SECN_SPEC_DESC"), col("CNSNS_SPEC_DESC"), col("CNSNS_SUB_SPEC_DESC")))
      .withColumn("spclty_cd_struct", explode(col("SPCLTY_CDs")))
      .drop("SPCLTY_CDs")
      .select(df("*"), col("spclty_cd_struct.*"))
      .drop("AMX_SPEC_DESC")
      .drop("AMX_SPEC_SECN_SPEC_DESC")
      .drop("CNSNS_SPEC_DESC")
      .drop("CNSNS_SUB_SPEC_DESC")
      .withColumnRenamed("_1", "spclty_desc")
      .withColumnRenamed("_2", "spclty_typ")
    newDf
  }
}
