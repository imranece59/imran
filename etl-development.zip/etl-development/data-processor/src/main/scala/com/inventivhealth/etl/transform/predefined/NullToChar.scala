package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

import scala.util.{Failure, Success, Try}

class NullToChar extends EtlFunction1[String, String] {
  override val name: String = "nullToChar"
  override def execute(s: String): String =  {
    if (s == null) {
      " "
    } else {
      s
    }
  }
  override def createUdf: UserDefinedFunction = udf { execute _ }
}
