package com.inventivhealth.etl.process.steps

import com.inventivhealth.etl.dao.ETLConfigComponent
import com.inventivhealth.etl.process.ETLProcess.validationsColumn
import com.inventivhealth.etl.transform.ETLFunctionsComponent
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType

trait Validation {
  this: ETLConfigComponent with ETLFunctionsComponent =>

  /**
    * Performs validation step according to business rules.
    *
    * @param source - data frame with source data
    * @return Tuple with two objects:
    *         - data frame with valid data
    *         - data frame with invalid data
    */
  def validate(source: DataFrame): (DataFrame, DataFrame) = {
    //system validation: not null and data type
    val notNullMappings = mappings.
      filter(_.sourceField.isDefined).
      filter(!_.sfNullable).
      flatMap { mapping =>
        val fields = mapping.sourceField.get.split(",").map(_.trim)
        fields.map(f => mapping.copy(sourceField = Some(f)))
      }
    val sourceTypeMappings = mappings.filter(m => m.sourceField.isDefined && m.sourceFieldType.isDefined)

    val genericValidationMapping = sourceTypeMappings.filter(m => m.validation.isDefined)

    var df = source.withColumn(validationsColumn, lit(null))

    df = notNullMappings.foldLeft(df) { (validateDf, m) =>
      val field = m.sourceField.get
      validateDf.withColumn(validationsColumn,
        validations("validateNotNull")(col(field), lit(field), lit(null), col(validationsColumn)))
    }

    df = sourceTypeMappings.foldLeft(df) { (validateDf, m) =>
      val field = m.sourceField.get
      validateDf.withColumn(validationsColumn,
        validations("validateDataType")(col(field).cast(StringType), lit(field), lit(m.sourceFieldType.get), col(validationsColumn)))
    }

    df = genericValidationMapping.foldLeft(df) { (validateDf, m) =>
      val field = m.sourceField.get
      validateDf.withColumn(validationsColumn,
        validations(m.validation.get.trim)(col(field).cast(StringType), lit(field), lit(null), col(validationsColumn)))
    }

    val valid = df.where(col(validationsColumn).isNull).drop(col(validationsColumn))
    val invalid = df.where(col(validationsColumn).isNotNull)

    (valid, invalid)
  }

}
