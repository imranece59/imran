package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class PartyCodeFunc extends EtlFunction1[String, Int] {
  override val name: String = "partyCode"

  override def execute(partyCode: String): Int = {
    if ("MAJOR".equals(partyCode)) 1
    else 2
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
