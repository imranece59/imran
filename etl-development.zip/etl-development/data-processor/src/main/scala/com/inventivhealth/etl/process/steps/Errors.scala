package com.inventivhealth.etl.process.steps

import com.datastax.driver.core.utils.UUIDs
import com.inventivhealth.etl.config.ConfigComponent
import com.inventivhealth.etl.dao.ETLConfigComponent
import com.inventivhealth.etl.persist.DataSaverFactory
import com.inventivhealth.etl.spark.SparkComponent
import org.apache.spark.executor.OutputMetrics
import org.apache.spark.scheduler.{SparkListener, SparkListenerTaskEnd}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.sql.functions._
import org.joda.time.DateTime
import java.util.Random

import scala.collection.mutable

trait Errors extends SparkComponent {
  this: ConfigComponent with ETLConfigComponent with DataSaverFactory =>

  /**
    * Converts invalid data (received from validation step) into data frame ready to be saved to err_table (C*)
    *
    * @param invalid - data frame with records which didn't pass validation
    */
  def convertToErrorRecords(invalid: DataFrame, `type`: String): DataFrame = {
    val validationsToString = udf { (validations: mutable.WrappedArray[GenericRowWithSchema]) =>
      validations.map { row =>
        val value = row.getString(0)
        val name = row.getString(1)
        val reason = row.getString(2)
        s"[error = $reason, field = $name, value = '$value']"
      }.mkString(" ")
    }
    val getTimeUUID = udf { () => UUIDs.timeBased().toString }
    val getTimestamp = udf { () => System.currentTimeMillis() }
    val status = `type` match {
      case "RI_VALIDATION" => "PENDING"
      case _ => "NOT_APPLICABLE"
    }
    val now = DateTime.now()
    val genRandomNumber = udf { () =>
         val randGen = new Random();
         randGen.nextInt(1000); }
    invalid.select(
      col("row"),
      validationsToString(col("validations")) as "err_message",
      lit(etlConfig.tenantId) as "tenant_id",
      lit(args.groupId.getOrElse(-1)) as "group_id",
      lit(etlConfig.sourceName) as "source",
      lit(etlConfig.sourceEntityName) as "source_entity",
      lit(etlConfig.targetName) as "target",
      lit(etlConfig.targetEntityName) as "target_entity",
      lit(appConfig.dataProcessorStepName) as "subcategory",
      lit(etlConfig.processId) as "process_id",
      lit(now.getMinuteOfHour) as "err_min",
      lit(now.getHourOfDay) as "err_hour",
      lit(now.getDayOfMonth) as "err_day",
      lit(now.getMonthOfYear) as "err_month",
      lit(now.getYear) as "err_year",
      getTimeUUID() as "err_timestamp",
      getTimestamp() as "status_dt",
      lit(`type`) as "step",
      lit(status) as "status",
      genRandomNumber() as "r_part"
    )
  }

  /**
    * Saves errors into err_table (C*)
    *
    * @param errors - data frame
    */
  def saveErrors(errors: DataFrame): Long = {
    var errorsCount = 0L
    var outputMetrics: Option[OutputMetrics] = None

    sqlContext.sparkContext.addSparkListener(new SparkListener() {
      override def onTaskEnd(taskEnd: SparkListenerTaskEnd) {
        outputMetrics = taskEnd.taskMetrics.outputMetrics
        if(outputMetrics.isDefined) {
          errorsCount += outputMetrics.get.recordsWritten
        }
      }
    })

    val saver = getDataSaver("ods", "err_table")
    saver.saveData(errors)
    errorsCount
  }

}
