package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils

class ActdbComputeChange extends GroupOperation {

  override val name: String = "actdbComputeChange"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val prevCol = df(operationParams("prev"))
    val currCol = df(operationParams("curr"))
    val outputCol = operationParams("output")

    def computeRatio(prev: String, curr: String) =
      {
        if (StringUtils.isBlank(prev) || StringUtils.isBlank(curr)) 0
        else (curr.toDouble - prev.toDouble)
      }

    val computeRatioUDF = udf(computeRatio(_: String, _: String))
    df.withColumn(outputCol, computeRatioUDF(prevCol, currCol))

  }
}

class ActdbComputeChangeAs1 extends ActdbComputeChange {
  override val name: String = "actdbComputeChangeAs1"
}


class ActdbComputeChangeAs2 extends ActdbComputeChange {
  override val name: String = "actdbComputeChangeAs2"
}


class ActdbComputeChangeAs3 extends ActdbComputeChange {
  override val name: String = "actdbComputeChangeAs3"
}


class ActdbComputeChangeAs4 extends ActdbComputeChange {
  override val name: String = "actdbComputeChangeAs4"
}

class ActdbComputeChangeAs5 extends ActdbComputeChange {
  override val name: String = "actdbComputeChangeAs5"
}