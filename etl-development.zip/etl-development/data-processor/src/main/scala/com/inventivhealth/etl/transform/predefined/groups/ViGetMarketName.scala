package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class ViGetMarketName extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "viGetMarketName"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val tenantId = parameters(ETLProcess.tenantIdParam)
    val sqlContext = df.sqlContext
    val sparkContext = sqlContext.sparkContext

    val mktProductDataExtractor = getDataExtractor(sourceName, "xref_mkt_def_brand_product_rx", false)
    var mktProductDf = mktProductDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (mktProductDf.schema.fieldNames.contains("active_inactive"))  {
      mktProductDf = mktProductDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }
    mktProductDf = mktProductDf.select("market_id", "product_id", "market_name")

    val markets = mktProductDf
      .collect()
      .map(row => (row.getAs[String]("market_id"), row.getAs[String]("product_id")) -> row.getAs[String]("market_name"))
      .toMap

    val marketsBc = sparkContext.broadcast(markets)

    val getMarketName = udf { (marketId: String, productId: String) => marketsBc.value.get(marketId, productId) }

    df
      .withColumn("market_name", getMarketName(col("mkt_pid"), col("fin_brnd_id")))
      .where(col("market_name").isNotNull)
  }
}