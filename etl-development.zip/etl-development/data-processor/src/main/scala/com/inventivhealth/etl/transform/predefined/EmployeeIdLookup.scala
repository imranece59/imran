package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import com.inventivhealth.etl.process.ETLProcess.tenantIdParam

class EmployeeIdLookup extends EtlFunction1[String, String] {
  override val name: String = "empIdLkup"

  override def execute(castEmpId: String): String = {
    val tenantId = parameters(tenantIdParam).asInstanceOf[Int]
    val castId = tenantId.toString.concat(":").concat(castEmpId)
    broadcasts.value.get("d_employee").flatMap {
      _.filter(row => row.getAs[Int]("tenant_id") == tenantId && row.getAs[String]("emp_id") == castId)
        .map(_.getAs[String]("emp_id"))
        .headOption
    }.orNull
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}