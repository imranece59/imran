package com.inventivhealth.etl.persist

trait DataSaverFactory {

  def getDataSaver(targetName: String, targetEntityName: String, header: Boolean = false, delimiter: Option[String] = None): DataSaver

}

trait DefaultDataSaverFactory extends DataSaverFactory {

  override def getDataSaver(targetName: String, targetEntityName: String, header: Boolean = false, delimiter: Option[String] = None): DataSaver = {
    DataTargets.withName(targetName) match {
      case DataTargets.`s3` => new S3DataSaver(targetEntityName, header, delimiter.getOrElse(","))
      case DataTargets.`local` => new CsvDataSaver(targetEntityName, header, delimiter.getOrElse(","))
      case DataTargets.`ods` | DataTargets.`bi` => new CassandraDataSaver(targetName, targetEntityName)
      case _ => throw new IllegalArgumentException(s"Not supported data target $targetName")
    }
  }

}
