package com.inventivhealth.etl.transform.predefined.groups

import java.sql.{Date, Timestamp}
import java.time.{LocalDate, ZoneOffset}

import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class BIFilterByDate extends GroupOperation {
  override val name: String = "biFilterByDate"

  private val unitsParam = "units"
  private val countParam = "count"
  private val fieldParam = "field"
  private val startFromParam = "startFrom"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val units = operationParams.getOrElse(unitsParam, "year")
    val count = operationParams.getOrElse(countParam, "1").toInt
    val field = operationParams.getOrElse(fieldParam, "month_start")
    val startFrom = operationParams.getOrElse(startFromParam, "now")

    val baseDate = startFrom match {
      case "now" => LocalDate.now()
      case "max" =>
        val maxRow = df.select(max(col(field)) as "max_date").take(1)
        val maxDate = maxRow.head.getAs[Timestamp]("max_date")
        GroupObject.broadcasts = df.sqlContext.sparkContext.broadcast(Map("max_date" -> maxDate.getTime.toString))
        maxDate.toLocalDateTime.toLocalDate
      case _ => throw new IllegalArgumentException(s"Unknown start from type $startFrom")
    }

    val date = units match {
      case "year" => baseDate.atStartOfDay().minusYears(count)
      case "month" => baseDate.atStartOfDay().minusMonths(count)
      case _ => throw new IllegalArgumentException(s"Unknown time unit type $units")
    }
    val timestamp = new Timestamp(date.toInstant(ZoneOffset.UTC).toEpochMilli)
    df.where(col(field) >= lit(timestamp))
  }
}
