package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit

class BIFAccountCallGetGeoLevels extends GroupOperation {
  override val name: String = "biFAccountCallGetGeoLevels"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val hierarchy = df.sqlContext.read.format("org.apache.spark.sql.cassandra")
      .options(Map("table" -> "d_geography_hierarchy", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]))
      .load()
    val geography = df.sqlContext.read.format("org.apache.spark.sql.cassandra")
      .options(Map("table" -> "d_geography", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]))
      .load()

    var result = df.withColumnRenamed("geo_nm", "territory_name")

    result = result.join(hierarchy, result("geo_id") === hierarchy("geo_id") and hierarchy("geo_lvl_rnk").cast("int") === lit(1))
      .select(result("*"), hierarchy("prnt1_geo_id") as "district_id")
    result = result.join(hierarchy, result("district_id") === hierarchy("geo_id") and hierarchy("geo_lvl_rnk").cast("int") === lit(2))
      .select(result("*"), hierarchy("prnt1_geo_id") as "region_id")
    result = result.join(hierarchy, result("region_id") === hierarchy("geo_id") and hierarchy("geo_lvl_rnk").cast("int") === lit(3))
      .select(result("*"), hierarchy("prnt1_geo_id") as "nation_id")

    result = result.join(geography, result("district_id") === geography("geo_id")).select(result("*"), geography("geo_nm") as "district_name")
    result = result.join(geography, result("region_id") === geography("geo_id")).select(result("*"), geography("geo_nm") as "region_name")
    result = result.join(geography, result("nation_id") === geography("geo_id")).select(result("*"), geography("geo_nm") as "nation_name")

    result
  }

}
