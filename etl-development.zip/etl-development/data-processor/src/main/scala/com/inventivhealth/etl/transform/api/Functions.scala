package com.inventivhealth.etl.transform.api

import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.{DataFrame, Row, UserDefinedFunction}

import scala.collection.mutable

trait NamedFunction {
  val name: String
}

trait ParametrizedFunction {
  val parameters: mutable.Map[String, Any] = mutable.HashMap[String, Any]()
  var broadcasts: Broadcast[Map[String, Array[Row]]] = _
}

trait UDFCreator {
  def createUdf: UserDefinedFunction
}

trait EtlFunction extends NamedFunction with ParametrizedFunction with UDFCreator with Serializable

trait GroupOperation extends NamedFunction with ParametrizedFunction with Serializable {
  def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame
}

trait EtlFunction0[+T] extends EtlFunction {
  def execute(): T
}

trait EtlFunction1[-S, +T] extends EtlFunction {
  def execute(s: S): T
}

trait EtlFunction2[-S1, -S2, +T] extends EtlFunction {
  def execute(s1: S1, s2: S2): T
}

trait EtlFunction3[-S1, -S2, -S3, +T] extends EtlFunction {
  def execute(s1: S1, s2: S2, s3: S3): T
}

trait EtlFunction4[-S1, -S2, -S3, -S4, +T] extends EtlFunction {
  def execute(s1: S1, s2: S2, s3: S3, s4: S4): T
}

trait EtlFunction5[-S1, -S2, -S3, -S4, -S5, +T] extends EtlFunction {
  def execute(s1: S1, s2: S2, s3: S3, s4: S4, s5: S5): T
}