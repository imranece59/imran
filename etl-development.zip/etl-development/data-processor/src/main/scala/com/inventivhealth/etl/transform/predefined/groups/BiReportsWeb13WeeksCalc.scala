package com.inventivhealth.etl.transform.predefined.groups

import java.sql.Timestamp
import java.time.{LocalDate, ZoneOffset}
import java.time.format.DateTimeFormatter
import java.time.temporal.WeekFields

import com.inventivhealth.etl.bi._
import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

class BiReportsWeb13WeeksCalc extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biRepWeb13WeekCalc"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]
  val emptyDate = "30000101"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val tenantId = parameters(ETLProcess.tenantIdParam)
    val sqlContext = df.sqlContext

    // filter out empty customer name
    var allDf = df.where(col("frst_nm").isNotNull || col("lst_nm").isNotNull || col("mddl_nm").isNotNull)

    allDf = allDf
      .withColumn("customer_full_name", getCustomerFullName(col("lst_nm"), col("frst_nm"), col("mddl_nm")))
      .drop("lst_nm")
      .drop("frst_nm")
      .drop("mddl_nm")

    // distinct payer rows after joins
    allDf = allDf
      .select("wk_id", "fin_brnd_id", "mkt_pid", "sls_chnl_desc", "prsc_cid", "tenant_id", "st_id", "market_name",
        "brand_name", "district_name", "territory_name", "territory_nbr", "rx_vol", "group_id", "segment", "segment_type", "accnt_id", "customer_full_name",
        "zip", "state", "city", "address")
      .distinct()

    // get f_account_call data
    val accCallDataExtractor = getDataExtractor(sourceName, "f_account_call", false)
    var accCallDf = accCallDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (accCallDf.schema.fieldNames.contains("active_inactive"))  {
      accCallDf = accCallDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }
    accCallDf = accCallDf.where(col("calltyp_c").isin(Seq("Detail Only", "Detail with Sample"):_*)
      && col("status_c") === lit("Submitted_vod")
      && col("actvty_typ_c").isin(Seq("Extended HCP Prescriber Interaction", "Face to Face Contact with HCP Prescriber"):_*))
      .select("accnt_call_id", "accnt_id", "call_dt_c", "trtry_c", "st_id")

    // cache account_call
    accCallDf.persist(StorageLevel.MEMORY_AND_DISK_SER)

    // get max call_dt_c for each accnt_id
    val aCLastCallDf = accCallDf
        .groupBy("accnt_id", "st_id", "trtry_c")
        .agg(max("call_dt_c") as "last_call_date")

    // convert date to timestamp with UTC zone
    val getTimestamp = udf { (day: Timestamp) =>
      val res = day.toLocalDateTime.toLocalDate.atStartOfDay(ZoneOffset.UTC)
      new Timestamp(res.toInstant.toEpochMilli)
    }

    // get timestamp of call_dt_c
    var aCCount = accCallDf
      .withColumn("call_timestamp", getTimestamp(col("call_dt_c")))

    // max date from f_account_call
    val format = DateTimeFormatter.ofPattern("yyyyMMdd")
    val field = WeekFields.ISO.dayOfWeek()
    val maxRow = aCCount.select(max("call_timestamp") as "max_timestamp").take(1)
    val maxTs = maxRow(0).getTimestamp(0) match {
      case null =>
        val date = LocalDate.parse(emptyDate, format).atStartOfDay(ZoneOffset.UTC)
        new Timestamp(date.toInstant.toEpochMilli)
      case t => t
    }

    val date = maxTs.toLocalDateTime.toLocalDate.atStartOfDay(ZoneOffset.UTC).minusWeeks(12).`with`(field, 1)
    val startDay = new Timestamp(date.toInstant.toEpochMilli)

    // get last 13 weeks records from account_call
    aCCount = aCCount.where(col("call_timestamp") >= lit(startDay))

    // get distinct accnt_call_id
    aCCount = aCCount.select("accnt_call_id", "accnt_id", "st_id", "trtry_c").distinct()

    // get counts for each accnt_id, st_id, trtry_c
    aCCount = aCCount
      .groupBy("accnt_id", "st_id", "trtry_c")
      .agg(count("accnt_call_id") as "call_count_13_weeks")

    // calc sum by brand
    var aggDf = allDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "district_name", "territory_name", "territory_nbr", "group_id", "segment", "segment_type",
        "accnt_id", "customer_full_name", "zip", "state", "city", "address")
      .agg(sum("rx_vol") as "nbrx_13_weeks")

    // calc BREO/RESP market sum
    aggDf = aggDf
      .withColumn("resp_nbrx_13_weeks",
        sum(col("nbrx_13_weeks"))
          .over(Window.partitionBy("tenant_id", "st_id", "market_name", "district_name", "territory_name", "territory_nbr", "group_id", "segment", "segment_type",
            "accnt_id", "customer_full_name", "zip", "state", "city", "address")))

    // pivot brand sums
    aggDf = aggDf
      .groupBy("tenant_id", "st_id", "market_name", "district_name", "territory_name", "territory_nbr", "group_id", "segment", "segment_type",
        "accnt_id", "customer_full_name", "zip", "state", "city", "address", "resp_nbrx_13_weeks")
      .pivot("brand_name", Seq("ADVAIR", "BREO", "DULERA", "SYMBICORT"))
      .sum("nbrx_13_weeks")
      .withColumnRenamed("ADVAIR", "advair_nbrx_13_weeks")
      .withColumnRenamed("BREO", "breo_nbrx_13_weeks")
      .withColumnRenamed("DULERA", "dulera_nbrx_13_weeks")
      .withColumnRenamed("SYMBICORT", "symbicort_nbrx_13_weeks")

    // join with f_account_call aggregations
    aggDf = aggDf
      .join(aCLastCallDf, aggDf("accnt_id") === aCLastCallDf("accnt_id") and aggDf("st_id") === aCLastCallDf("st_id") and aggDf("territory_nbr") === aCLastCallDf("trtry_c"), "left_outer")
      .select(aggDf("*"), aCLastCallDf("last_call_date"))

    aggDf = aggDf
      .join(aCCount, aggDf("accnt_id") === aCCount("accnt_id") and aggDf("st_id") === aCCount("st_id") and aggDf("territory_nbr") === aCCount("trtry_c"), "left_outer")
      .select(aggDf("*"), aCCount("call_count_13_weeks"))

    aggDf
      .withColumn("week_code", getWeekCode(col("group_id")))
      .withColumnRenamed("group_id", "week_id")
      .drop("accnt_id")
      .drop("market_name")
      .drop("territory_nbr")
  }
}