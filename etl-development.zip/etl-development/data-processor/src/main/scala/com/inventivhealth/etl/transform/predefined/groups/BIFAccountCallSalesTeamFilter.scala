package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class BIFAccountCallSalesTeamFilter extends GroupOperation {
  override val name: String = "biFAccountCallSalesTeamGeographyFilter"

  private val salesTeamsParam = "salesTeams"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val allSalesTeams = df.sqlContext.read.format("org.apache.spark.sql.cassandra").
      options(Map("table" -> "d_sfa", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]))
      .load().collect()
      .map(r => r.getAs[Int]("st_id") -> r.getAs[String]("st_nm"))

    val salesTeamsOpt = operationParams.get(salesTeamsParam).map(_.split(",").map(_.trim))
      .map { names =>
        allSalesTeams.filter { case (_, stNm) => names.contains(stNm) }.map(_._1)
      }

    if (salesTeamsOpt.isDefined) {
      val salesTeams = salesTeamsOpt.get
      val geography = df.sqlContext.read.format("org.apache.spark.sql.cassandra")
        .options(Map("table" -> "d_geography", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]))
        .load()
      val tenantId = parameters.getOrElse(ETLProcess.tenantIdParam, 1).asInstanceOf[Int]
      df.join(geography, df("trtry_c") === geography("geo_nbr"))
        .select(df("*"), geography("st_id") as "geo_st_id", geography("geo_id"), geography("geo_nm"))
        .where($"geo_st_id".isin(salesTeams:_*) and ($"tenant_id" === lit(tenantId)))
    } else df

  }
}
