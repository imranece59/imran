package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.storage.StorageLevel

class BIExplodeSalesMetrics extends GroupOperation {
  override val name: String = "biExplodeSalesMetrics"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val toArray = udf { (nrx: Double, trx: Double) => Array(nrx -> "NRX", trx -> "TRX") }
    val defaultTarget = udf { (target: String) => if (target == null) "N" else target }
    val result = df
      .withColumn("rx_array", toArray($"nrx_vol", $"trx_vol"))
      .withColumn("rx_", explode($"rx_array")).drop("rx_array")
      .select(df("*"), $"rx_.*")
      .drop("nrx_vol")
      .drop("trx_vol")
      .withColumnRenamed("_1", "rx_vol")
      .withColumnRenamed("_2", "metric_type")
      .withColumn("rx_vol", $"rx_vol".cast(DoubleType))
      .withColumnRenamed("cust_attrib3", "target")
      .withColumn("target", defaultTarget($"target"))
      .repartition($"accnt_id")
    result
  }
}
