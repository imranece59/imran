package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.process.ETLProcess._
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class PlanNationPeriod extends GroupOperation {
  override val name: String = "planNatPer"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val tenantId = parameters(ETLProcess.tenantIdParam)
    val sqlContext = df.sqlContext
    //Look up to d_geography_hierarchy to get Nation_name
    import df.sqlContext.implicits._
    val dataExtr1 = new CassandraDataExtractor("ods", "d_geography_hierarchy")
    val hierarchyDf = dataExtr1.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId) and $"active_inactive" === lit("ACTIVE")).cache()
    val df1 = df.as("t1").join(hierarchyDf.as("t2"),
      df("prnt3_geo_id") === hierarchyDf("geo_id")
      && lit(4) === hierarchyDf("geo_lvl_rnk")
      && df("st_id") === hierarchyDf("st_id"), "leftouter")
      .select($"t1.*", $"t2.geo_nm").withColumnRenamed("geo_nm", "nation_name").cache()
    //Look up to d_account_segment.
    val dataExtr2 = new CassandraDataExtractor("ods", "d_account_segment")
    val dActsgmtDf = dataExtr2.extractData(sqlContext).where($"tenant_id" === lit(tenantId) and $"active_inactive" === lit("ACTIVE") and $"sgmnt_typ" === lit("Advair")).cache()
    val df2 = df1.as("t1").join(dActsgmtDf.as("t2"), df1("accnt_id") === dActsgmtDf("accnt_id"),
      "leftouter").select($"t1.*", $"t2.sgmnt_value", $"t2.accnt_sgmnt_attrb_4").cache()
    hierarchyDf.unpersist()
    df1.unpersist()
    val inputdf = df2
    //Dataframes for Action Group and Brand Indicator
    val actGrpSegtypedf = createActGrpDf(inputdf)
    val brdIndSegtypedf = createBrdindDf(inputdf)
    //ActionGroup Dataframes with Metric_Type nrx and trx transposed.
    val actGrpNrxDf = addMetricTypNrx(actGrpSegtypedf)
    val actGrpTrxDf = addMetricTypTrx(actGrpSegtypedf)
    //BrandIndicator Dataframes with Metric_Type nrx and trx transposed.
    val brdIndNrxDf = addMetricTypNrx(brdIndSegtypedf)
    val brdIndTrxDf = addMetricTypTrx(brdIndSegtypedf)
    //***************Union NRX Dataframes*****************
    val unionNrxDf = actGrpNrxDf.unionAll(brdIndNrxDf)
    //***************Union TRX Dataframes******************
    val unionTrxDf = actGrpTrxDf.unionAll(brdIndTrxDf)
    //*******Calculate BrandRX and MarketRX****************
    val calcBrdrxNrxDf = calcBrandrxNrx(unionNrxDf)
    val calcMktrxNrxDf = calcMarketrxNrx(unionNrxDf)
    val calcBrdrxTrxDf = calcBrandrxTrx(unionTrxDf)
    val calcMktrxTrxDf = calcMarketrxTrx(unionTrxDf)
    //Union to get two Dataframes 1.brandrx, 2.marketrx
    val brandrxDf = calcBrdrxNrxDf.unionAll(calcBrdrxTrxDf).orderBy(asc("mo_id"))
    val marketrxDf = calcMktrxNrxDf.unionAll(calcMktrxTrxDf).orderBy(asc("mo_id"))
    //Calculate Prev brand_rx, TotalBrandRx and then Percentage of Business
    val prevBrdrxNrxDf = calcPrevBrdrx(brandrxDf)
    val totBrdrxDf = calcTotBrdrx(prevBrdrxNrxDf)
    val finBrdrxDf = percBrdrx(prevBrdrxNrxDf, totBrdrxDf)
    //Calculate Prev market_rx.
    val finMktrxDf = calcPrevMktrx(marketrxDf)
    //Join final BrandRx and MarketRx dataframes
    val joinedDF = joinBrdMkt(finBrdrxDf, finMktrxDf)
    //Calculate final BRx,MRx percentage attributes
    val finalcalcDf = finCalc(joinedDF)
    finalcalcDf
  }
  def createActGrpDf(df: DataFrame): DataFrame = {
    val defVal = udf((a: String) => {
      if (a == null) {
        "5_N/A"
      } else a
    })
    df.drop("fin_brnd_id").drop("mkt_pid").drop("prsc_cid").drop("geo_id").drop("row")
      .withColumn("segment_type", lit("Advair Action Group")).withColumn("segment", defVal(df("sgmnt_value")))
      .drop("sgmnt_value").drop("accnt_sgmnt_attrb_4")
  }

  def createBrdindDf(df: DataFrame): DataFrame = {
    val defVal = udf((a: String) => {
      if (a == null) {
        "5_N/A"
      } else a
    })
    df.drop("fin_brnd_id").drop("mkt_pid").drop("prsc_cid").drop("geo_id").drop("row")
      .withColumn("segment_type", lit("Advair Brand Indicator")).withColumn("segment", defVal(df("accnt_sgmnt_attrb_4")))
      .drop("sgmnt_value").drop("accnt_sgmnt_attrb_4")
  }

  def addMetricTypNrx(df: DataFrame): DataFrame = {
    df.drop("trx_vol").withColumn("metric_type", lit("NRX"))
  }

  def addMetricTypTrx(df: DataFrame): DataFrame = {
    df.drop("nrx_vol").withColumn("metric_type", lit("TRX"))
  }

  def calcBrandrxNrx(df: DataFrame): DataFrame = {
    val df1 = df.groupBy("brand_name", "market_name", "mo_id", "payment_type", "plan", "tenant_id", "st_id",
      "target", "nation_name", "segment_type", "segment", "metric_type")
      .agg("nrx_vol" -> "sum").withColumnRenamed("sum(nrx_vol)", "brand_rx")
    df1
  }

  def calcBrandrxTrx(df: DataFrame): DataFrame = {
    val tmpDf = df.groupBy("brand_name", "market_name", "mo_id", "payment_type", "plan", "tenant_id", "st_id",
      "target", "nation_name", "segment_type", "segment", "metric_type")
      .agg("trx_vol" -> "sum").withColumnRenamed("sum(trx_vol)", "brand_rx")
    tmpDf
  }

  def calcMarketrxNrx(df: DataFrame): DataFrame = {
    df.groupBy("market_name", "mo_id", "payment_type", "plan", "tenant_id", "st_id",
      "target", "nation_name", "segment_type", "segment", "metric_type")
      .agg("nrx_vol" -> "sum").withColumnRenamed("sum(nrx_vol)", "market_rx")
  }

  def calcMarketrxTrx(df: DataFrame): DataFrame = {
    df.groupBy("market_name", "mo_id", "payment_type", "plan", "tenant_id", "st_id",
      "target", "nation_name", "segment_type", "segment", "metric_type")
      .agg("trx_vol" -> "sum").withColumnRenamed("sum(trx_vol)", "market_rx")
  }

  def calcPrevBrdrx(df: DataFrame): DataFrame = {
    val w = Window.orderBy("mo_id").partitionBy("brand_name", "market_name", "payment_type", "plan", "tenant_id", "st_id",
      "target", "nation_name", "segment_type", "segment", "metric_type")
    df.withColumn("Prev_brand_rx", lag("brand_rx", 1, 0.0).over(w))
  }

  def calcTotBrdrx(df: DataFrame): DataFrame = {
    df.groupBy("tenant_id", "brand_name", "market_name", "mo_id", "st_id",
      "target", "nation_name", "segment_type", "segment", "metric_type")
      .agg("brand_rx" -> "sum").withColumnRenamed("sum(brand_rx)", "total_brandRx")
  }

  def percBrdrx(df: DataFrame, totDf: DataFrame): DataFrame = {
    val percentBus = udf((a: Double, b: Double) => a / b)
    import df.sqlContext.implicits._
    val df1 = df.as("t1").join(totDf.as("t2"), df("tenant_id") === totDf("tenant_id")
      && df("brand_name") === totDf("brand_name")
      && df("market_name") === totDf("market_name")
      && df("mo_id") === totDf("mo_id")
      && df("st_id") === totDf("st_id")
      && df("target") === totDf("target")
      && df("nation_name") === totDf("nation_name")
      && df("segment_type") === totDf("segment_type")
      && df("segment") === totDf("segment")
      && df("metric_type") === totDf("metric_type"),
      "inner").select($"t1.*", $"t2.total_brandRx")
    df1.withColumn("perc_of_bus", percentBus(df1("brand_rx"), df1("total_brandRx")))
  }

  def calcPrevMktrx(df: DataFrame): DataFrame = {
    val w = Window.orderBy("mo_id").partitionBy("market_name", "payment_type", "plan", "tenant_id", "st_id",
      "target", "nation_name", "segment_type", "segment", "metric_type")
    df.withColumn("Prev_market_rx", lag("market_rx", 1, 0.0).over(w))
  }

  def joinBrdMkt(df1: DataFrame, df2: DataFrame): DataFrame = {
    import df1.sqlContext.implicits._
    df1.as("t1").join(df2.as("t2"), df1("mo_id") === df2("mo_id")
      && df1("payment_type") === df2("payment_type")
      && df1("plan") === df2("plan")
      && df1("tenant_id") === df2("tenant_id")
      && df1("st_id") === df2("st_id")
      && df1("target") === df2("target")
      && df1("nation_name") === df2("nation_name")
      && df1("segment_type") === df2("segment_type")
      && df1("segment") === df2("segment")
      && df1("metric_type") === df2("metric_type")
      && df1("market_name") === df2("market_name"),
      "inner").select($"t1.*", $"t2.market_rx", $"t2.prev_market_rx")
  }

  def finCalc(df: DataFrame): DataFrame = {
    val startDt = df.select(min("mo_id")).head().getString(0)
    val mktShrChgUdf = udf((a: Double, b: Double, c: Double, d: Double) => {
      if (b == 0.0 || d == 0.0) 1
      else ((a / b) - (c / d))
    })
    val cnvBreotoResp = udf((a: String) => {
      if (a == "BREO") "RESP" else ""
    })
    val monthtoName = udf((yyyymm: String) => {
      import java.text.DateFormatSymbols;
      val currYear = yyyymm.substring(0, 4)
      val currMonth = yyyymm.substring(4, 6)
      val sMonthYtd = Integer.parseInt(currYear.concat("01"))
      val shortMonths = new DateFormatSymbols().getShortMonths();
      val monthName = shortMonths.apply(Integer.parseInt(currMonth) - 1) + " " + currYear.toString
      monthName
    })
    val brxChgUdf = udf((a: Double, b: Double) => {
      if (b == 0.0) 1
      else (a - b) / b
    })
    val mrxChgUdf = udf((a: Double, b: Double) => {
      if (b == 0.0) 1
      else (a - b) / b
    })
    val stgtoInt = udf((a: String) => {
      a.toInt
    })
    val mrxShareUdf = udf((a: Double, b: Double) => {
      if (a == 0.0) 0.0
      else a / b
    })

    val preCalcDf = df.withColumn("market_share", mrxShareUdf(df("brand_rx"), df("market_rx")))
      .withColumn("market_share_change", mktShrChgUdf(df("brand_rx"), df("market_rx"), df("prev_brand_rx"), df("prev_market_rx")))
      .withColumn("brand_rx_chng", brxChgUdf(df("brand_rx"), df("prev_brand_rx")))
      .withColumn("market_rx_chng", brxChgUdf(df("market_rx"), df("prev_market_rx")))
      .withColumn("market_name", cnvBreotoResp(df("market_name")))
    val finalcalcDf = preCalcDf
      .drop("prev_market_rx").drop("Prev_brand_rx")
      .withColumn("month_name", monthtoName(preCalcDf("mo_id")))
      .withColumn("month_id", stgtoInt(preCalcDf("mo_id")))
      .withColumn("brand_rx_perc_chng", preCalcDf("brand_rx_chng"))
      .drop("mo_id").drop("total_brandRx").drop("brand_rx_chng")
    finalcalcDf
  }
}