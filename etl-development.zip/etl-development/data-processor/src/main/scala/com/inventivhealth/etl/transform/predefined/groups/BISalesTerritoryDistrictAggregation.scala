package com.inventivhealth.etl.transform.predefined.groups

import java.sql.Timestamp
import java.time.{LocalDate, ZoneOffset}

import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import com.inventivhealth.etl.bi._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class BISalesTerritoryDistrictAggregation extends GroupOperation {
  override val name: String = "biSalesTerritoryDistrictAggregation"

  val cacheParam = "cache"
  val minusMonthsParam = "minusMonths"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._

    if (operationParams.get(cacheParam).exists(_.toBoolean)) {
      df.cache()
      df.count()
    }

    val terrBrandRxWindow = Window.partitionBy("tenant_id", "st_id", "brand_name", "market_name", "district_name", "territory_name", "metric_type", "segment_type", "segment", "target").orderBy("month_start")
    //territory metrics aggregation
    val terrBrandRx  = df.
      groupBy("tenant_id", "st_id", "brand_name", "market_name", "district_name", "territory_name", "metric_type", "month_id", "segment_type", "segment", "target").
      agg(sum($"rx_vol") as "territory_brand_rx", first("month_start") as "month_start", first("month_name") as "month_name").
      withColumn("territory_prev_brand_rx", lag($"territory_brand_rx", 1).over(terrBrandRxWindow)).
      withColumn("prev_month_start", lag($"month_start", 1).over(terrBrandRxWindow)).
      withColumn("territory_prev_brand_rx", when($"territory_prev_brand_rx".isNotNull, $"territory_prev_brand_rx").otherwise(0)).
      withColumn("territory_prev_brand_rx", previousMonthRx($"prev_month_start", $"month_start", $"territory_prev_brand_rx"))

    val terrMarketRxWindow = Window.partitionBy("tenant_id", "st_id", "market_name", "district_name", "territory_name", "metric_type", "segment_type", "segment", "target").orderBy("month_start")
    val terrMarketRx = df.
      groupBy("tenant_id", "st_id", "market_name", "district_name", "territory_name", "metric_type", "month_id", "segment_type", "segment", "target").
      agg(sum($"rx_vol") as "territory_market_rx", first("month_start") as "month_start", first("month_name") as "month_name").
      withColumn("territory_prev_market_rx", lag($"territory_market_rx", 1).over(terrMarketRxWindow)).
      withColumn("prev_month_start", lag($"month_start", 1).over(terrMarketRxWindow)).
      withColumn("territory_prev_market_rx", when($"territory_prev_market_rx".isNotNull, $"territory_prev_market_rx").otherwise(0)).
      withColumn("territory_prev_market_rx", previousMonthRx($"prev_month_start", $"month_start", $"territory_prev_market_rx"))

    val payerDistinct = df.dropDuplicates(
      Seq("tenant_id", "st_id", "accnt_id", "fin_brnd_id", "mkt_pid", "district_name", "metric_type", "month_id", "segment_type", "segment", "target", "rx_vol"))

    val distBrandRxWindow = Window.partitionBy("tenant_id", "st_id", "brand_name", "market_name", "district_name", "metric_type", "segment_type", "segment", "target").orderBy("month_start")
    val distBrandRx = payerDistinct.
      groupBy("tenant_id", "st_id", "brand_name", "market_name", "district_name", "metric_type", "month_id", "segment_type", "segment", "target").
      agg(sum($"rx_vol") as "district_brand_rx", first("month_start") as "month_start", first("month_name") as "month_name").
      withColumn("district_prev_brand_rx", lag($"district_brand_rx", 1).over(distBrandRxWindow)).
      withColumn("prev_month_start", lag($"month_start", 1).over(distBrandRxWindow)).
      withColumn("district_prev_brand_rx", when($"district_prev_brand_rx".isNotNull, $"district_prev_brand_rx").otherwise(0)).
      withColumn("district_prev_brand_rx", previousMonthRx($"prev_month_start", $"month_start", $"district_prev_brand_rx"))

    val distMarketRxWindow = Window.partitionBy("tenant_id", "st_id", "market_name", "district_name", "metric_type", "segment_type", "segment", "target").orderBy("month_start")
    val distMarketRx = payerDistinct.
      groupBy("tenant_id", "st_id", "market_name", "district_name", "metric_type", "month_id", "segment_type", "segment", "target").
      agg(sum($"rx_vol") as "district_market_rx", first("month_start") as "month_start", first("month_name") as "month_name").
      withColumn("district_prev_market_rx", lag($"district_market_rx", 1).over(distMarketRxWindow)).
      withColumn("prev_month_start", lag($"month_start", 1).over(distMarketRxWindow)).
      withColumn("district_prev_market_rx", when($"district_prev_market_rx".isNotNull, $"district_prev_market_rx").otherwise(0)).
      withColumn("district_prev_market_rx", previousMonthRx($"prev_month_start", $"month_start", $"district_prev_market_rx"))

    val months = operationParams.get(minusMonthsParam).map(_.toInt).getOrElse(6)
    val date =
      if (GroupObject.broadcasts == null || GroupObject.broadcasts.value.get("max_date").isEmpty) {
        LocalDate.now()
      } else {
        val millis = GroupObject.broadcasts.value("max_date").toLong
        new Timestamp(millis).toLocalDateTime.toLocalDate
      }
    val filterDate = new Timestamp(date.atStartOfDay().minusMonths(months).toInstant(ZoneOffset.UTC).toEpochMilli)

    terrBrandRx.where($"month_start" >= lit(filterDate)).
      join(terrMarketRx, Seq("tenant_id", "st_id", "market_name", "district_name", "territory_name", "metric_type", "month_id", "segment_type", "segment", "target")).
      join(distBrandRx, Seq("tenant_id", "st_id", "brand_name", "market_name", "district_name", "metric_type", "month_id", "segment_type", "segment", "target")).
      join(distMarketRx, Seq("tenant_id", "st_id", "market_name", "district_name", "metric_type", "month_id", "segment_type", "segment", "target")).
      select(terrBrandRx("*"),
        terrMarketRx("territory_market_rx"), terrMarketRx("territory_prev_market_rx"),
        distBrandRx("district_brand_rx"), distBrandRx("district_prev_brand_rx"),
        distMarketRx("district_market_rx"), distMarketRx("district_prev_market_rx")).
      drop("accnt_id").
      drop("month_start").
      drop("prev_month_start").
      withColumn("territory_brand_rx_perc_change", brandRxPercentChange($"territory_brand_rx", $"territory_prev_brand_rx")).
      withColumn("district_brand_rx_perc_change", brandRxPercentChange($"district_brand_rx", $"district_prev_brand_rx")).
      withColumn("territory_market_rx_change", marketRxChange($"territory_market_rx", $"territory_prev_market_rx")).
      withColumn("district_market_rx_change", marketRxChange($"district_market_rx", $"district_prev_market_rx")).
      withColumn("territory_market_share", marketShare($"territory_brand_rx", $"territory_market_rx")).
      withColumn("district_market_share", marketShare($"district_brand_rx", $"district_market_rx")).
      withColumn("territory_market_share_change", marketShareChange($"territory_brand_rx", $"territory_market_rx", $"territory_prev_brand_rx", $"territory_prev_market_rx")).
      withColumn("district_market_share_change", marketShareChange($"district_brand_rx", $"district_market_rx", $"district_prev_brand_rx", $"district_prev_market_rx"))
  }
}
