package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{lit, udf}

class BIJoinGeoUpToDistrict extends GroupOperation {
  override val name: String = "biJoinGeoUpToDistrict"

  val cacheParam = "cache"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._

    if (operationParams.get(cacheParam).exists(_.toBoolean)) {
      df.cache()
      df.count()
    }

    val hierarchy = df.sqlContext.read.format("org.apache.spark.sql.cassandra").
      options(Map("table" -> "d_geography_hierarchy", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String])).load()

    //get geography names for territory and district
    val geography = df.sqlContext.read.format("org.apache.spark.sql.cassandra").
      options(Map("table" -> "d_geography", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String])).load()

    var result = df.join(hierarchy, df("geo_id") === hierarchy("geo_id") and df("st_id") === hierarchy("st_id") and hierarchy("geo_lvl_rnk").cast("int") === lit(1))
      .select(df("*"), hierarchy("prnt1_geo_id") as "prnt_geo_id")

    result = result.join(geography, result("geo_id") === geography("geo_id"), "left_outer").select(result("*"), geography("geo_nm") as "territory_name")
    result = result.join(geography, result("prnt_geo_id") === geography("geo_id"), "left_outer").select(result("*"), geography("geo_nm") as "district_name")
    result.drop("geo_id")
      .drop("prnt_geo_id")
  }
}
