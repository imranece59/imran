package com.inventivhealth.etl.process

import com.inventivhealth.etl.config.ConfigComponent
import com.inventivhealth.etl.config.model.ETLLog
import com.inventivhealth.etl.dao.{CassandraDaoComponent, ETLConfigComponent}
import com.inventivhealth.etl.exceptions.ETLProcessException
import com.inventivhealth.etl.extract.DataExtractorFactory
import com.inventivhealth.etl.persist.DataSaverFactory
import com.inventivhealth.etl.process.steps._
import com.inventivhealth.etl.spark.SparkComponent
import com.inventivhealth.etl.transform.ETLFunctionsComponent
import org.apache.spark.sql.DataFrame
import org.apache.spark.storage.StorageLevel

/**
  * Basic trait which describes a contract for Spark SQL based ETL process
  */
trait ETLProcess extends Extraction with Delta with Validation with Enrichment with Transformation with GroupOperations
  with Summary with Errors with Loader with ErrorsReprocess {

  this: ConfigComponent with ETLConfigComponent with CassandraDaoComponent with DataExtractorFactory with SparkComponent
    with ETLFunctionsComponent with DataSaverFactory =>

  /**
    * Performs following ETL process steps:
    * 1) extracts data from source (S3) and applies scheme to it;
    * 2) finds delta by splitting data into parts for incremental upload (get inserts, updates, deletes);
    * 3) for each delta part run following steps:
    *       - perform row validation and get valid and invalid data frames;
    *       - transform valid data according to mappings;
    *       - collect ETL summary;
    *       - save summary to log_table (C*);
    *       - save invalid data to err_table (C*);
    *       - save transformed data to target table (C*).
    */
  def perform(): Unit = {
    val sourceData = extract()

    val deltaObj = findDelta(sourceData)
    val processed = deltaObj.map { part =>
      val sourceGrouped = applySourceGroupOperations(part.data)
      val (valid, validationViolations) = validate(sourceGrouped)
      val transformed = transform(valid, part.mappings)
      val (enriched, riViolations) = part.label match {
        case Some("delete") => (transformed, None)
        case _ =>
          val (e, v) = enrich(transformed)
          val targetGrouped = applyTargetGroupOperations(e)
          (targetGrouped, Some(v))
      }
      cacheData(enriched)

      (enriched, validationViolations, riViolations)
    }

    var errorsCount = 0L
    if(appConfig.collectErrors) {
      val allErrors = processed.map { case (target, validationViolations, riViolations) =>
        val validationErrors = convertToErrorRecords(validationViolations, "ROW_VALIDATION")
        val allErrors = riViolations
          .map(rv => convertToErrorRecords(rv, "RI_VALIDATION"))
          .map(_.unionAll(validationErrors))
          .getOrElse(validationErrors)
        allErrors
      }.reduce(_.unionAll(_))
      errorsCount = saveErrors(allErrors)
    }

    val validRecords = processed.map { case (target, _, _) => target }

    var summary: Option[ETLLog] = None
    if (appConfig.collectSummary && appConfig.collectErrors) {
      val stats = collectSummary(validRecords, errorsCount)
      logSummary(stats)
      summary = Option(stats)
    }

    if (summary.isEmpty || (summary.isDefined && summary.get.status == "SUCCESS")) {
      validRecords.foreach(target => load(target.drop("row")))
    } else if (summary.isDefined && summary.get.status == "ERROR") {
      throw new ETLProcessException("ETL process failed due to error threshold violation")
    }

    if (appConfig.doErrorReprocessing) {
      val pendingErrors = getPendingErrors
      reprocessErrors(pendingErrors)
    }
  }

  private def cacheData(df: DataFrame): Unit = {
    if (appConfig.cacheTarget) {
      df.persist(StorageLevel.MEMORY_AND_DISK_SER)
    }
  }

}

object ETLProcess {
  final val tenantIdParam = "tenantId"
  final val processIdParam = "processId"
  final val odsKeyspace = "odsKeyspace"

  private[etl] final val validationsColumn = "validations"
}
