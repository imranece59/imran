package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.actdb._

class ActdbPartition extends GroupOperation {

  override val name: String = "actdbPartition"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    operationParams("actions").trim.split(",").foldLeft(df) { (frame, c) =>

      c match {
        case "sort" =>
          frame.sort(operationParams("sortBy").trim.split(",").map(_.trim).map(frame(_)): _*)

        case "persist" =>
          ActdbHelper.persistDf(operationParams.getOrElse("persistKey", "default"), frame)
          frame

        case "unpersist" =>
          ActdbHelper.unpersistDf(operationParams.getOrElse("persistKey", "default"))
          frame

        case "repartition" =>
          println(" ")
          println("##############repartition on " + operationParams("partitionExprs"))
          println(" ")
          frame.repartition(operationParams("partitionExprs").trim.split(",").map(_.trim).map(frame(_)): _*)

        case "sortWithinPartitions" =>
          frame.sortWithinPartitions(operationParams("sortByP").trim.split(",").map(_.trim).map(frame(_)): _*)

      }

    }
  }
}

class ActdbPartitionAs1 extends ActdbPartition {
  override val name: String = "actdbPartitionAs1"
}

class ActdbPartitionAs2 extends ActdbPartition {
  override val name: String = "actdbPartitionAs2"
}