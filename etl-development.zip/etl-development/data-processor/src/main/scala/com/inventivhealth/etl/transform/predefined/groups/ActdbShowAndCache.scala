package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.actdb._

class ActdbShowAndCache extends GroupOperation {

  override val name: String = "actdbShowAndCache"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + name)

    ActdbHelper.persistDf(operationParams.getOrElse("persistKey", "primary"), df)

    operationParams.getOrElse("actions", "count").trim.split(",").foreach(c =>
      c match {
        case "count" =>
          println("Row Count: " + df.count)

        case "show" =>
          if (operationParams.contains("where"))
            df.where(operationParams("where")).
              show(operationParams.getOrElse("limit", "1000").toInt)
          else
            df.show(operationParams.getOrElse("limit", "1000").toInt)

      })
    println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
    df
  }
}

class ActdbShowAndCacheAs1 extends ActdbShowAndCache {
  override val name: String = "actdbShowAndCacheAs1"
}

class ActdbShowAndCacheAs2 extends ActdbShowAndCache {
  override val name: String = "actdbShowAndCacheAs2"
}