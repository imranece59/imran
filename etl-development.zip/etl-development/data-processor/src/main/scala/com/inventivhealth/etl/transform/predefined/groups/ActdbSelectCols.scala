package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.actdb._
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class ActdbSelectCols extends GroupOperation {

  override val name: String = "actdbSelectCols"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    if (operationParams.contains("where"))
      df.where(operationParams("where")).
        selectExpr(operationParams("select").split(","): _*)

    else
      df.selectExpr(operationParams("select").split(","): _*)

  }
}

class ActdbSelectColsAs1 extends ActdbSelectCols {
  override val name: String = "actdbSelectColsAs1"
}

class ActdbSelectColsAs2 extends ActdbSelectCols {
  override val name: String = "actdbSelectColsAs2"
}

class ActdbSelectColsAs3 extends ActdbSelectCols {
  override val name: String = "actdbSelectColsAs3"
}

class ActdbSelectColsAs4 extends ActdbSelectCols {
  override val name: String = "actdbSelectColsAs4"
}
