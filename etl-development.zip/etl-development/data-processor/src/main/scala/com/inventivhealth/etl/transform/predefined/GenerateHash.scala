package com.inventivhealth.etl.transform.predefined

import java.nio.charset.StandardCharsets

import com.google.common.hash.Hashing
import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class GenerateHash extends EtlFunction1[String,String] {
  override val name: String = "generateHash"

  override def execute(pln_desc:String): String = {

    val s1 = pln_desc.trim

    Hashing.sha256()
      .hashString(s1, StandardCharsets.UTF_8)
      .toString
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
