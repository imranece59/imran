package com.inventivhealth.etl.transform.predefined.validation

import java.text.SimpleDateFormat
import com.inventivhealth.etl.transform.api.CellValidation
import com.typesafe.scalalogging.slf4j.LazyLogging
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions._
import scala.util.{Failure, Success, Try}

class DateMMDDYYYYValidation extends CellValidation[String] with LazyLogging {
  override val name: String = "dateMMDDYYYYValidation"

  override def execute(value: String, fieldName: String, arg: String): Option[String] = {
    val format = new SimpleDateFormat("MM/dd/yyyy")
    if (value == ""|| "null" == value) {
      return None
    }
    Try(format.parse(value)) match {
      case Success(_) => None
      case Failure(_) => Some("WRONG_DATE_FORMAT")
    }
  }

  override def createUdf: UserDefinedFunction = udf { super[CellValidation].execute _ }

}
