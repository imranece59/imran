package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class LookupAccountIdAndCIDForVeevaAddress extends GroupOperation {

  override val name: String = "accountIdAndCIDLookup"

  private final val keyspace = "keyspace"
  private final val table = "table"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val keyspaceName = operationParams(keyspace)
    val tableName = operationParams(table)

    val account = new CassandraDataExtractor(keyspaceName, tableName).extractData(df.sqlContext)
      .where(col("tenant_id") === lit(parameters(ETLProcess.tenantIdParam)) and col("active_inactive") === lit("ACTIVE"))

    val tenantId = parameters(ETLProcess.tenantIdParam)
    val getCid = udf { (accId: String) => accId.replace(s"$tenantId:", "") }

    df.join(account, df("Account_vod__c") === account("veeva_id"))
      .select(df("*"), account("accnt_id") as "accnt_id")
      .withColumn("CID", getCid(col("accnt_id")))

  }

}
