package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils
import com.inventivhealth.etl.actdb._
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess

class AvtRepActivityMonthly1 extends GroupOperation {

  override val name: String = "avtRepActivityMonthly1"

  var geoLevels = Array("")

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    geoLevels = operationParams("geoLevels").trim.split(",").map(_.trim)

    ActdbHelper.persistDf("primary", df)

    var dfBase = workdayCount(df, totalCalls(df))

    dfBase = computeTotalTarget(df, dfBase)

    dfBase = accountsCalled(df, dfBase)

    ActdbHelper.persistDf("primary", dfBase)

    dfBase

  }

  def accountsCalled(df: DataFrame, dfBase: DataFrame): DataFrame = {

    geoLevels.foldLeft(dfBase) { (frame, geoLevel) =>
      {

        val geoLevelCol = geoLevel + "_name"

        val dfTNT = df.
          groupBy(geoLevelCol, "month_id", "segment", "segment_type", "customer_full_name", "activity_type").
          agg(countDistinct("accnt_id").alias(geoLevel + "_total_accounts_called"))

        val dfT = df.where("trgt_flg_c = 'Y'").
          groupBy(geoLevelCol, "month_id", "segment", "segment_type", "customer_full_name", "activity_type").
          agg(countDistinct("accnt_id").alias(geoLevel + "_total_targets_called"))

        var dfJoin1 = ActdbHelper.leftOuterJoin(frame, dfTNT,
          Array(geoLevelCol, "month_id", "segment", "segment_type", "customer_full_name", "activity_type"),
          geoLevel + "_total_accounts_called")

        ActdbHelper.leftOuterJoin(dfJoin1, dfT,
          Array(geoLevelCol, "month_id", "segment", "segment_type", "customer_full_name", "activity_type"),
          geoLevel + "_total_targets_called")

      }
    }

  }

  def workdayCount(df: DataFrame, baseDf: DataFrame): DataFrame = {

    val dfTerr = df.
      groupBy("month_id", (geoLevels.map(_ + "_name") :+ "territory_id"): _*).
      agg(countDistinct("call_dt_c") as "territory_no_of_workdays_territories_by_period").
      withColumn("territory_territory_count", lit(1))

    dfTerr.persist
    val res = geoLevels.foldLeft(baseDf) { (frame, geoLevel) =>
      {
        val geoIdCol = geoLevel + "_name"
        val outputCol = geoLevel + "_no_of_workdays_territories_by_period"
        val outputCol1 = geoLevel + "_territory_count"

        ActdbHelper.leftOuterJoin(frame,
          dfTerr.groupBy(geoIdCol, "month_id").
            agg(sum("territory_no_of_workdays_territories_by_period").alias(outputCol),
              sum("territory_territory_count").alias(outputCol1)),
          Array(geoIdCol, "month_id"), Array(outputCol, outputCol1))

      }
    }
    dfTerr.unpersist
    res

  }

  def totalCalls(df: DataFrame): DataFrame = {

    val baseColumns = Array("tenant_id", "st_id", "month_id", "month_name", "activity_type",
      "segment", "segment_type", "customer_full_name", "row")

    val baseColumns1 = Array("month_id", "activity_type", "segment", "segment_type", "customer_full_name")

    // L0 Total Calls
    val dfBaseTNT = df.groupBy(geoLevels(0) + "_name", (baseColumns ++ geoLevels.drop(1).map(_ + "_name")): _*).
      agg(countDistinct("accnt_call_id").alias(geoLevels(0) + "_total_calls"))

    // L0 Calls to Tartets    
    val dfBaseT = df.where("trgt_flg_c = 'Y'").groupBy(geoLevels(0) + "_name", baseColumns1: _*).
      agg(countDistinct("accnt_call_id").alias(geoLevels(0) + "_total_calls_target"))

    // L0 both    
    val dfDist = ActdbHelper.leftOuterJoin(dfBaseTNT, dfBaseT,
      baseColumns1 :+ geoLevels(0) + "_name",
      geoLevels(0) + "_total_calls_target")

    // L1 Total Calls
    val dfBaseTNT1 = df.groupBy(geoLevels(1) + "_name", baseColumns1: _*).
      agg(countDistinct("accnt_call_id").alias(geoLevels(1) + "_total_calls"))

    // L1 Calls to Tartets    
    val dfBaseT1 = df.where("trgt_flg_c = 'Y'").groupBy(geoLevels(1) + "_name", baseColumns1: _*).
      agg(countDistinct("accnt_call_id").alias(geoLevels(1) + "_total_calls_target"))

    var res = ActdbHelper.leftOuterJoin(dfDist, dfBaseTNT1,
      baseColumns1 :+ geoLevels(1) + "_name",
      geoLevels(1) + "_total_calls")

    res = ActdbHelper.leftOuterJoin(res, dfBaseT1,
      baseColumns1 :+ geoLevels(1) + "_name",
      geoLevels(1) + "_total_calls_target")

    // L2 Total Calls
    val dfBaseTNT2 = df.groupBy(geoLevels(2) + "_name", baseColumns1: _*).
      agg(countDistinct("accnt_call_id").alias(geoLevels(2) + "_total_calls"))

    // L2 Calls to Tartets    
    val dfBaseT2 = df.where("trgt_flg_c = 'Y'").groupBy(geoLevels(2) + "_name", baseColumns1: _*).
      agg(countDistinct("accnt_call_id").alias(geoLevels(2) + "_total_calls_target"))

    res = ActdbHelper.leftOuterJoin(res, dfBaseTNT2,
      baseColumns1 :+ geoLevels(2) + "_name",
      geoLevels(2) + "_total_calls")

    ActdbHelper.leftOuterJoin(res, dfBaseT2,
      baseColumns1 :+ geoLevels(2) + "_name",
      geoLevels(2) + "_total_calls_target")

  }

  def computeTotalTarget(df: DataFrame, baseDf: DataFrame) = {

    val aa = new CassandraDataExtractor("ods", "d_account_alignment").
      extractData(df.sqlContext).
      where(col("tenant_id") === lit(parameters(ETLProcess.tenantIdParam)) && col("cust_attrib3") === lit("Y")).
      select(col("accnt_id").alias("accnt_id1"), col("geo_id").alias("territory_id"), col("st_id"))

    val aah = ActdbHelper.leftOuterJoin(df, aa,
      Array("territory_id", "st_id"), "accnt_id1")

    //   if (operationParams.getOrElse("cacheAccountAlignment", "false").toBoolean)
    aah.persist()

    val res = geoLevels.foldLeft(baseDf) { (frame, geoLevel) =>
      {
        val geoIdCol = geoLevel + "_name"
        val outputCol = geoLevel + "_total_targets"

        ActdbHelper.leftOuterJoin(frame,
          aah.groupBy(geoIdCol).
            agg(countDistinct("accnt_id1").alias(outputCol)),
          Array(geoIdCol), outputCol)

      }
    }

    // if (operationParams.getOrElse("cacheAccountAlignment", "false").toBoolean)
    aah.unpersist()

    res

  }

}