package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.config.model.ETLConfig
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit

class BISalesTeamFilter extends GroupOperation {
  override val name: String = "biSalesTeamFilter"

  private val salesTeamsParam = "salesTeams"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val allSalesTeams = df.sqlContext.read.format("org.apache.spark.sql.cassandra").
      options(Map("table" -> "d_sfa", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]))
      .load().collect()
      .map(r => r.getAs[Int]("st_id") -> r.getAs[String]("st_nm"))
    val salesTeams = operationParams.get(salesTeamsParam).map { salesTeamsStr =>
      val st = salesTeamsStr.split(",").map(_.trim).toSet
      allSalesTeams.filter { case (_, stNm) => st.contains(stNm) }
    }.getOrElse(allSalesTeams)
    val salesTeam = salesTeams.head._1
    df
      .where($"tenant_id" === lit(parameters(ETLProcess.tenantIdParam).asInstanceOf[Int]) and $"active_inactive" === lit("ACTIVE"))
      .withColumn("st_id", lit(salesTeam))
  }
}
