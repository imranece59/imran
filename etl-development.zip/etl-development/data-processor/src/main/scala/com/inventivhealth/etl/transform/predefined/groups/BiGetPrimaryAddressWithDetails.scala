package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class BiGetPrimaryAddressWithDetails extends GroupOperation {
  override val name: String = "biGetPrimaryAddressWithDetails"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val accountLocation = df.sqlContext.read.format("org.apache.spark.sql.cassandra").
      options(Map("table" -> "d_account_location", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String])).load()

    val getAddress = udf { (adrs1: String, adrs2: String, adrs3: String) =>
      val addr1 = if (adrs1 == null) "" else adrs1
      val addr2 = if (adrs2 == null) "" else if (!adrs2.isEmpty) ", " + adrs2 else adrs2
      val addr3 = if (adrs3 == null) "" else if (!adrs3.isEmpty) ", " + adrs3 else adrs3
      (addr1 + addr2 + addr3).trim
    }

    val accountFilteredAddressDf = accountLocation
      .withColumn("row_number", row_number().over(Window.partitionBy("accnt_id").orderBy($"prmry_adrs".desc, $"veeva_id")))
      .filter($"row_number" === lit(1))
      .withColumn("address", getAddress($"accnt_lctn_adrs1", $"accnt_lctn_adrs2", $"accnt_lctn_adrs3"))

    df.join(accountFilteredAddressDf, df("accnt_id") === accountFilteredAddressDf("accnt_id"), "left_outer")
      .select(df("*"), accountFilteredAddressDf("address"),
        accountFilteredAddressDf("accnt_lctn_city") as "city",
        accountFilteredAddressDf("accnt_lctn_state") as "state",
        accountFilteredAddressDf("accnt_lctn_zip") as "zip")
  }
}
