package com.inventivhealth.etl.transform.predefined.groups


import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class ConcurCorrectionsGSK extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "concurCorrectionsGSK"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val tenantId = parameters(ETLProcess.tenantIdParam)
    val sqlContext = df.sqlContext
   
    val keyCols = Array("tenant_id","batch_id","seq_number")
    
    val concurDataExtractor = getDataExtractor(sourceName, "f_concur", false)
    val concurDf = concurDataExtractor.extractData(sqlContext)
    val sourceDfRetCols = df.columns diff keyCols
    val adjustLevel = udf((lvl:Int)=> lvl-1)
    val df1 = concurDf.join(df, keyCols ,"inner")
              .select(concurDf("*"),df("row"))
              .withColumn("newLevel", adjustLevel(col("level")))
              .drop("level")
              .withColumnRenamed("newLevel", "level")    
    val dropColumns = new DropColumns
    val filteredDf1 = dropColumns.execute(df1, Map("columns"->sourceDfRetCols.mkString(",")))
    val df2 = filteredDf1.join(df, keyCols ,"left_outer")
              .select((filteredDf1.columns++sourceDfRetCols).map(name=>col(name)):_*)
              
    unionAllByName(df1,df2)
  }
  def unionAllByName(a: DataFrame, b: DataFrame): DataFrame = {
    val columns = a.columns.toSet.intersect(b.columns.toSet).map(col).toSeq
    a.select(columns: _*).unionAll(b.select(columns: _*))
  }
}