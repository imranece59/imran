package com.inventivhealth.etl.process.steps

import com.datastax.driver.core.utils.UUIDs
import com.inventivhealth.etl.config.ConfigComponent
import com.inventivhealth.etl.config.model.ETLLog
import com.inventivhealth.etl.dao.{CassandraDaoComponent, ETLConfigComponent}
import com.inventivhealth.etl.util.FormattingUtil._
import com.typesafe.scalalogging.slf4j.LazyLogging
import org.apache.spark.sql.DataFrame
import org.joda.time.DateTime

trait Summary extends LazyLogging {
  this: ConfigComponent with CassandraDaoComponent with ETLConfigComponent =>

  /**
    * Calculates ETL process summary:
    *   - transformed records
    *   - number of invalid records
    */
  def collectSummary(validRecords: List[DataFrame], errorsCount: Long): ETLLog = {
    val validCount = validRecords.reduce((left, right) => left.select("tenant_id").unionAll(right.select("tenant_id"))).count()
    logger.info(s"${etlConfig.tenantId}:${etlConfig.sourceEntityName}:${etlConfig.targetEntityName} -> valid = $validCount, invalid = $errorsCount")
    val totalCount = validCount + errorsCount
    val errorPercentage = errorsCount.toDouble / totalCount.toDouble * 100
    val status = if (totalCount == 0) "EMPTY"
      else if (errorPercentage < etlConfig.errorThreshold) "SUCCESS"
      else "ERROR"

    val time = DateTime.now()
    val (min, hour, day, month, year) = splitDateIntoMonthYear(time)
    val subcategory = s"${etlConfig.sourceName}:${etlConfig.sourceEntityName} -> ${etlConfig.targetName}:${etlConfig.targetEntityName}"
    val step = appConfig.dataProcessorStepName
    val groupId = args.groupId.getOrElse(-1)

    ETLLog(etlConfig.tenantId, groupId, etlConfig.processId, min, hour, day,
      month, year, subcategory, UUIDs.timeBased(), totalCount, validCount,
      etlConfig.sourceName, etlConfig.sourceEntityName, status,
      step, etlConfig.targetName, etlConfig.targetEntityName)
  }

  /**
    * Saves ETL process summary
    */
  def logSummary(stats: ETLLog): Unit = {
    cassandraDao.saveEtlLog(stats)
  }

}
