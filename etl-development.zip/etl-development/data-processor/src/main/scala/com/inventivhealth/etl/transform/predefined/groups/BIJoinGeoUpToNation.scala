package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit

class BIJoinGeoUpToNation extends GroupOperation {
  override val name: String = "biJoinGeoUpToNation"

  val cacheParam = "cache"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._

    if (operationParams.get(cacheParam).exists(_.toBoolean)) {
      df.cache()
      df.count()
    }

    val hierarchy = df.sqlContext.read.format("org.apache.spark.sql.cassandra").
      options(Map("table" -> "d_geography_hierarchy", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String])).load()

    val geography = df.sqlContext.read.format("org.apache.spark.sql.cassandra").
      options(Map("table" -> "d_geography", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String])).load()

    var result = df.join(hierarchy, df("geo_id") === hierarchy("geo_id") and df("st_id") === hierarchy("st_id") and hierarchy("geo_lvl_rnk").cast("int") === lit(1))
      .select(df("*"), hierarchy("prnt1_geo_id") as "district_geo_id")
      .withColumnRenamed("geo_id", "territory_geo_id")

    result = result.join(hierarchy, result("district_geo_id") === hierarchy("geo_id") and hierarchy("geo_lvl_rnk").cast("int") === lit(2))
      .select(result("*"), hierarchy("prnt1_geo_id") as "region_geo_id")
    result = result.join(hierarchy, result("region_geo_id") === hierarchy("geo_id") and hierarchy("geo_lvl_rnk").cast("int") === lit(3))
      .select(result("*"), hierarchy("prnt1_geo_id") as "nation_geo_id")

    result = result.join(geography, result("territory_geo_id") === geography("geo_id")).select(result("*"), geography("geo_nm") as "territory_name")
    result = result.join(geography, result("district_geo_id") === geography("geo_id")).select(result("*"), geography("geo_nm") as "district_name")
    result = result.join(geography, result("region_geo_id") === geography("geo_id")).select(result("*"), geography("geo_nm") as "region_name")
    result = result.join(geography, result("nation_geo_id") === geography("geo_id")).select(result("*"), geography("geo_nm") as "nation_name")

    result
      .drop("territory_geo_id")
      .drop("district_geo_id")
      .drop("region_geo_id")
      .drop("nation_geo_id")
  }
}
