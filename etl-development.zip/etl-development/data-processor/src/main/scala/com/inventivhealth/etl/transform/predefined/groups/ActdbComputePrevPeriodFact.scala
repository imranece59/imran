package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.actdb._
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions._

class ActdbComputePrevPeriodFact extends GroupOperation {

  override val name: String = "actdbComputePrevPeriodFact"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val orderBy = operationParams("orderBy")
    val partitionBy = operationParams("partitionBy").split(",")
    val output = operationParams("output")
    val lagCount = if (operationParams.contains("lag"))
      operationParams("lag").toInt
    else
      1

    val factCOl = operationParams("factCol")

    val w = Window.partitionBy(partitionBy(0), partitionBy.drop(1): _*).orderBy(orderBy)
    df.withColumn(output, lag(factCOl, lagCount).over(w))

  }

}

class ActdbComputePrevPeriodFactAs1 extends ActdbComputePrevPeriodFact {
  override val name: String = "actdbComputePrevPeriodFactAs1"
}

class ActdbComputePrevPeriodFactAs2 extends ActdbComputePrevPeriodFact {
  override val name: String = "actdbComputePrevPeriodFactAs2"
}

class ActdbComputePrevPeriodFactAs3 extends ActdbComputePrevPeriodFact {
  override val name: String = "actdbComputePrevPeriodFactAs3"
}

class ActdbComputePrevPeriodFactAs4 extends ActdbComputePrevPeriodFact {
  override val name: String = "actdbComputePrevPeriodFactAs4"
}

class ActdbComputePrevPeriodFactAs5 extends ActdbComputePrevPeriodFact {
  override val name: String = "actdbComputePrevPeriodFactAs5"
}
