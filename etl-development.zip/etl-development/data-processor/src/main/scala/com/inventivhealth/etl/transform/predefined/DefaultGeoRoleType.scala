package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class DefaultGeoRoleType extends EtlFunction0[String] {
  override val name: String = "defaultGeoRoleType"

  override def execute(): String = "Sales And Marketing"

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
