package com.inventivhealth.etl.transform.predefined.validation

import com.inventivhealth.etl.transform.api.CellValidation
import com.typesafe.scalalogging.slf4j.LazyLogging
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.UserDefinedFunction

object DataTypes extends Enumeration {
  type DataTypes = Value
  val String, Int, Long, Float, Boolean = Value
}

class DataTypeValidation extends CellValidation[String] with LazyLogging {
  override val name: String = "validateDataType"

  override def execute(value: String, fieldName: String, dataType: String): Option[String] = {
    if (StringUtils.isBlank(value) || "null" == value || StringUtils.isBlank(dataType)) {
      return None
    }
    try {
      val dt = DataTypes.withName(dataType)
      dt match {
        case DataTypes.`String` => None
        case DataTypes.`Int` => value.toInt
        case DataTypes.`Long` => value.toLong
        case DataTypes.`Float` => value.toFloat
        case DataTypes.`Boolean` => value.toBoolean
      }
      None
    } catch {
      case e: NoSuchElementException =>
        logger.warn(s"!UNKNOWN DataType found - $dataType, Skipping validation for field $fieldName")
        None
      case e: NumberFormatException => Some("WRONG_DATA_TYPE")
      case e: IllegalArgumentException => Some("WRONG_DATA_TYPE")
    }
  }

  override def createUdf: UserDefinedFunction = udf { super[CellValidation].execute _ }

}
