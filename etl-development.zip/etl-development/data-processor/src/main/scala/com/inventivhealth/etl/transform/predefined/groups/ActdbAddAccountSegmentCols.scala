package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.actdb._
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess

class ActdbAddAccountSegmentCols extends GroupOperation {

  override val name: String = "actdbAddAccountSegmentCols"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val row1ColExprs = Array("sgmnt_value as segment", "'Advair Action Group' as segment_type")
    val row2ColExprs = Array("accnt_sgmnt_attrb_4 as segment", "'Advair Brand Indicator' as segment_type")

    val df1 = if (operationParams.contains("brand_name")) {
      val accSeg = new CassandraDataExtractor("ods", "d_account_segment").
        extractData(df.sqlContext).
        where(col("tenant_id") === lit(parameters(ETLProcess.tenantIdParam))
          and upper(col("sgmnt_typ")) === upper(lit(operationParams("brand_name")))).
        selectExpr("accnt_id", "COALESCE(sgmnt_value, '5_N/A') as sgmnt_value",
          "COALESCE(accnt_sgmnt_attrb_4, '5_N/A') as accnt_sgmnt_attrb_4")

      ActdbHelper.leftOuterJoin(df, accSeg, Array("accnt_id"), Array("sgmnt_value", "accnt_sgmnt_attrb_4"))

    } else {
      val accSeg = new CassandraDataExtractor("ods", "d_account_segment").
        extractData(df.sqlContext).
        where(col("tenant_id") === lit(parameters(ETLProcess.tenantIdParam))).
        selectExpr("accnt_id", "upper(sgmnt_typ) as brand_name", "COALESCE(sgmnt_value, '5_N/A') as sgmnt_value",
          "COALESCE(accnt_sgmnt_attrb_4, '5_N/A') as accnt_sgmnt_attrb_4")

      ActdbHelper.leftOuterJoin(df, accSeg, Array("accnt_id", "brand_name"), Array("sgmnt_value", "accnt_sgmnt_attrb_4"))
    }

    ActdbHelper.persistDf("primary", df1)
    val df2 = df1.selectExpr(df.columns ++ row1ColExprs: _*).unionAll(df1.selectExpr(df.columns ++ row2ColExprs: _*))
    ActdbHelper.persistDf("primary", df2)

    df2

  }
}
