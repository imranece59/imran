package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame

class BiWebReportsCustomer13WeeksColumns extends GroupOperation {
  override val name: String = "biWebRepCust13WeekCols"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    df
      .drop("district_name")
      .drop("week_id")
  }
}