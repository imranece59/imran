package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess._
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class GeoRecLkp extends GroupOperation {
  override val name: String = "geoRecLkp"
  override def execute(inputdf: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import inputdf.sqlContext.implicits._
    val cntStr = udf((a: String) => {
      if (a!=null){val tenantId = parameters(tenantIdParam).asInstanceOf[Int]
      s"$tenantId:${a.trim}"} else ""
      })

    val dataExtr = new CassandraDataExtractor("ods", "d_geography")
    val geoDf = dataExtr.extractData(inputdf.sqlContext).cache()

    val tempDf1 = inputdf.as("t1").join(geoDf.as("t2"),
      inputdf("prnt1_geo_id") === geoDf("geo_id"), "leftouter").select($"t1.*",$"t2.job_rprts_to")
    val returnDf1 = tempDf1.withColumn("prnt2_geo_id", cntStr(tempDf1("job_rprts_to"))).drop("job_rprts_to")

    val tempDf2 = returnDf1.as("t1").join(geoDf.as("t2"),
      returnDf1("prnt2_geo_id") === geoDf("geo_id"), "leftouter").select($"t1.*",$"t2.job_rprts_to")
    val finDf = tempDf2.withColumn("prnt3_geo_id", cntStr(tempDf2("job_rprts_to"))).drop("job_rprts_to")
    finDf

  }
}