package com.inventivhealth.etl.transform.predefined.groups

import java.time.YearMonth
import java.time.format.DateTimeFormatter
import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class BiFilterByDateYTD extends GroupOperation {
  override val name: String = "biFilterByDateYTD"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val toInt = udf[Int, String]( _.toInt)
    val startDate = (moId: String) => {
      val formatter = DateTimeFormatter.ofPattern("yyyyMM")
      val date = YearMonth.parse(moId, formatter).withMonth(1)
      date.format(formatter).toInt
    }
    val maxMonthId = GroupObject.broadcasts.value("maxMonthId")

    df.where(toInt($"mo_id") >= lit(startDate(maxMonthId)) && toInt($"mo_id") <= lit(maxMonthId.toInt))
      .drop("$mo_id")
  }
}
