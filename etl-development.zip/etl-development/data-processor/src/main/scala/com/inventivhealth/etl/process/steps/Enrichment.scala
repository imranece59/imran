package com.inventivhealth.etl.process.steps

import com.inventivhealth.etl.config.ConfigComponent
import com.inventivhealth.etl.config.model.RefMapping
import com.inventivhealth.etl.dao.{CassandraDaoComponent, ETLConfigComponent}
import com.inventivhealth.etl.extract.DataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess.validationsColumn
import com.inventivhealth.etl.spark.SparkComponent
import com.inventivhealth.etl.transform.ETLFunctionsComponent
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{Column, DataFrame}
import org.apache.spark.storage.StorageLevel

trait Enrichment {
  this: ConfigComponent with ETLConfigComponent with CassandraDaoComponent with ETLFunctionsComponent
    with DataExtractorFactory with SparkComponent with Transformation =>

  /**
    * Loads ref_mapping information from C* and joins source data with respective dimensions.
    *
    * @return
    */
  def enrich(source: DataFrame): (DataFrame, DataFrame) = {
    val preparedSource = source.withColumn(validationsColumn, lit(null))
    val refMappings = cassandraDao.getJoinRefMapping(etlConfig.processId, etlConfig.sourceEntityName).sortBy(_.order)
    val lookups = refMappings.map { ref =>
      val extractor = getDataExtractor(ref.lookupLocation, ref.lookup, false)
      var df = extractor.extractData(sqlContext)
        .where(col("tenant_id").equalTo(lit(etlConfig.tenantId)))
      if(ref.activeRecordsOnly) {
        if (df.schema.fieldNames.contains("active_inactive"))  {
          df = df.where(col("active_inactive").equalTo(lit("ACTIVE")))
        }
      }
      if (ref.condition.isDefined) {
        df = df.where(ref.condition.get)
      }
      (ref, df)
    }

    val enriched =
      if (lookups.nonEmpty) {
        joinWithLookups(preparedSource, lookups)
      } else preparedSource

    val returnColumns = lookups.foldLeft(Seq.empty[Column]) { case (all, (ref, lookupDf)) =>
      val retCols = Option(ref.returnFields).map(_.split(",").map(f => lookupDf(f)).toSeq).getOrElse(Seq.empty)
      all ++ retCols
    }
    val valid = enriched.where(col(validationsColumn).isNull)
      .select(source("*") +: returnColumns: _*)
    val transformedValid = partialTransform(valid, mappingLookups)
    val invalid = enriched.where(col(validationsColumn).isNotNull).select(source("*"), col(validationsColumn))

    transformedValid -> invalid
  }

  private def joinWithLookups(source: DataFrame,lookups: List[(RefMapping, DataFrame)]): DataFrame = {
    val enriched = lookups.foldLeft(source) { case (sourceDf, (ref, lookupDf)) =>
      val lookupColNames = ref.lookupField.split(",")
      val updatedLookupColNames = lookupColNames.map(c=> s"l_$c")
      var lookup = lookupDf
      lookupColNames.zip(updatedLookupColNames).foreach {
        case (e, n) =>
          lookup = lookup.withColumnRenamed(e, n)
      }
      val sourceCols = ref.sourceField.split(",").map(f => sourceDf(f))
      val lookupCols = updatedLookupColNames.map(f => lookup(f))
      val retCols = Option(ref.returnFields).map(_.split(",").map(f => lookup(f)).toSeq).getOrElse(Seq.empty)
      val returnColumns = (sourceDf("*") +: retCols) ++ lookupCols
      val joinCond = sourceCols.zip(lookupCols).map{ case(s, l) => lower(s) === lower(l) }.reduceLeft(_ && _)

      var resDf = sourceDf
        .join(lookup, joinCond, "left_outer")
        .select(returnColumns: _*)
      if (!ref.skipRi) {
        updatedLookupColNames.foreach { lookupField =>
          resDf = resDf.withColumn(validationsColumn,
            validations("referentialIntegrity")(lookup(lookupField).cast(StringType), lit(ref.lookupField), lit(null), col(validationsColumn)))
            .drop(lookupField)
        }
      }
      resDf
    }
    if (appConfig.cacheLookups) {
      enriched.persist(StorageLevel.MEMORY_AND_DISK_SER)
    }
    enriched
  }
}