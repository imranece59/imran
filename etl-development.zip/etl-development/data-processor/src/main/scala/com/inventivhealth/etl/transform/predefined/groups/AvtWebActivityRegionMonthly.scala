package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils
import com.inventivhealth.etl.actdb._
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess

class AvtWebActivityRegionMonthly extends GroupOperation {

  override val name: String = "avtWebActivityRegionMonthly"

  var geoLevels = Array("")

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    geoLevels = operationParams("geoLevels").trim.split(",").map(_.trim)

    ActdbHelper.persistDf("primary", df)

    var dfBase = workdayCount(df, totalCalls(df))

    dfBase = geoLevels(0) match {
      case "territory" => computeTotalTarget(df, dfBase)
      case "district"  => computeTotalTargetD(df, dfBase)
      case "region"    => computeTotalTargetD(df, dfBase)
    }

    dfBase = accountsCalled(df, dfBase)

    ActdbHelper.persistDf("primary", dfBase)

    dfBase

  }

  def accountsCalled(df: DataFrame, dfBase: DataFrame): DataFrame = {

    geoLevels.foldLeft(dfBase) { (frame, geoLevel) =>
      {

        val geoLevelCol = geoLevel + "_name"

        val dfTNT = df.groupBy(geoLevelCol, "month_id", "segment", "segment_type", "activity_type").
          agg(countDistinct("accnt_id").alias(geoLevel + "_total_accounts_called"))

        val dfT = df.where("trgt_flg_c = 'Y'").
          groupBy(geoLevelCol, "month_id", "segment", "segment_type", "activity_type").
          agg(countDistinct("accnt_id").alias(geoLevel + "_total_targets_called"))

        var dfJoin1 = ActdbHelper.leftOuterJoin(frame, dfTNT,
          Array(geoLevelCol, "month_id", "segment", "segment_type", "activity_type"),
          geoLevel + "_total_accounts_called")

        ActdbHelper.leftOuterJoin(dfJoin1, dfT,
          Array(geoLevelCol, "month_id", "segment", "segment_type", "activity_type"),
          geoLevel + "_total_targets_called")

      }
    }

  }

  def workdayCount(df: DataFrame, baseDf: DataFrame): DataFrame = {

    val dfTerr = df.
      groupBy("month_id", (geoLevels.map(_ + "_name") :+ "territory_id"): _*).
      agg(countDistinct("call_dt_c") as "territory_no_of_workdays_territories_by_period").
      withColumn("territory_territory_count", lit(1))

    dfTerr.persist
    val res = geoLevels.foldLeft(baseDf) { (frame, geoLevel) =>
      {
        val geoIdCol = geoLevel + "_name"
        val outputCol = geoLevel + "_no_of_workdays_territories_by_period"
        val outputCol1 = geoLevel + "_territory_count"

        ActdbHelper.leftOuterJoin(frame,
          dfTerr.groupBy(geoIdCol, "month_id").
            agg(sum("territory_no_of_workdays_territories_by_period").alias(outputCol),
              sum("territory_territory_count").alias(outputCol1)),
          Array(geoIdCol, "month_id"), Array(outputCol, outputCol1))

      }
    }
    dfTerr.unpersist
    res

  }

  def totalCalls(df: DataFrame): DataFrame = {

    val baseColumns = Array("tenant_id", "st_id", "month_id", "month_name", "activity_type",
      "segment", "segment_type", "row")

    val baseColumns1 = Array("month_id", "activity_type", "segment", "segment_type")

    // L0 Total Calls
    val dfBaseTNT = df.groupBy(geoLevels(0) + "_name", (baseColumns :+ (geoLevels(1) + "_name")): _*).
      agg(countDistinct("accnt_call_id").alias(geoLevels(0) + "_total_calls"))

    // L0 Calls to Tartets    
    val dfBaseT = df.where("trgt_flg_c = 'Y'").groupBy(geoLevels(0) + "_name", baseColumns1: _*).
      agg(countDistinct("accnt_call_id").alias(geoLevels(0) + "_total_calls_target"))

    // L0 both    
    val dfDist = ActdbHelper.leftOuterJoin(dfBaseTNT, dfBaseT,
      baseColumns1 :+ geoLevels(0) + "_name",
      geoLevels(0) + "_total_calls_target")

    // L1 Total Calls
    val dfBaseTNT1 = df.groupBy(geoLevels(1) + "_name", baseColumns1: _*).
      agg(countDistinct("accnt_call_id").alias(geoLevels(1) + "_total_calls"))

    // L1 Calls to Tartets    
    val dfBaseT1 = df.where("trgt_flg_c = 'Y'").groupBy(geoLevels(1) + "_name", baseColumns1: _*).
      agg(countDistinct("accnt_call_id").alias(geoLevels(1) + "_total_calls_target"))

    val res = ActdbHelper.leftOuterJoin(dfDist, dfBaseTNT1,
      baseColumns1 :+ geoLevels(1) + "_name",
      geoLevels(1) + "_total_calls")

    ActdbHelper.leftOuterJoin(res, dfBaseT1,
      baseColumns1 :+ geoLevels(1) + "_name",
      geoLevels(1) + "_total_calls_target")

  }

  def computeTotalTarget(df: DataFrame, baseDf: DataFrame) = {

    val aa = new CassandraDataExtractor("ods", "d_account_alignment").
      extractData(df.sqlContext).
      where(col("tenant_id") === lit(parameters(ETLProcess.tenantIdParam)) && col("cust_attrib3") === lit("Y")).
      select(col("accnt_id").alias("accnt_id1"), col("geo_id").alias("territory_id"), col("st_id"))

    val aah = ActdbHelper.leftOuterJoin(df, aa,
      Array("territory_id", "st_id"), "accnt_id1")

    //   if (operationParams.getOrElse("cacheAccountAlignment", "false").toBoolean)
    aah.persist()

    val res = geoLevels.foldLeft(baseDf) { (frame, geoLevel) =>
      {
        val geoIdCol = geoLevel + "_name"
        val outputCol = geoLevel + "_total_targets"

        ActdbHelper.leftOuterJoin(frame,
          aah.groupBy(geoIdCol).
            agg(countDistinct("accnt_id1").alias(outputCol)),
          Array(geoIdCol), outputCol)

      }
    }

    // if (operationParams.getOrElse("cacheAccountAlignment", "false").toBoolean)
    aah.unpersist()

    res

  }

  def computeTotalTargetD(df: DataFrame, baseDf: DataFrame) = {

    val aa = new CassandraDataExtractor("ods", "d_account_alignment").
      extractData(df.sqlContext).
      where(col("tenant_id") === lit(parameters(ETLProcess.tenantIdParam)) && col("cust_attrib3") === lit("Y")).
      select(col("accnt_id").alias("accnt_id1"), col("geo_id"), col("st_id"))

    val h = new CassandraDataExtractor("ods", "d_geography").
      extractData(df.sqlContext).
      where(col("tenant_id") === lit(parameters(ETLProcess.tenantIdParam)))
      .select("geo_id", "geo_nm", "st_id")

    val gh = new CassandraDataExtractor("ods", "d_geography_hierarchy").
      extractData(df.sqlContext).
      where(col("tenant_id") === lit(parameters(ETLProcess.tenantIdParam)))

    val aah = ActdbHelper.leftOuterJoin(aa, gh,
      Array("geo_id", "st_id"), Array("prnt1_geo_id", "prnt2_geo_id", "prnt3_geo_id")).
      withColumnRenamed("prnt1_geo_id", "district_id").
      withColumnRenamed("prnt2_geo_id", "region_id").
      withColumnRenamed("prnt3_geo_id", "nation_id").
      withColumnRenamed("geo_id", "territory_id")

    val baseCalc = ActdbHelper.leftOuterJoin(df.drop("district_name").drop("region_name").drop("nation_name"), aah,
      Array("territory_id", "st_id"), Array("district_id", "region_id", "nation_id", "accnt_id1"))

    baseCalc.persist()

    val res = geoLevels.foldLeft(baseDf) { (frame, geoLevel) =>
      {
        val geoIdCol = geoLevel + "_id"
        val geoNameCol = geoLevel + "_name"
        val outputCol = geoLevel + "_total_targets"

        val d1 = ActdbHelper.leftOuterJoin(baseCalc,
          h.withColumnRenamed("geo_id", geoIdCol).withColumnRenamed("geo_nm", geoNameCol),
          Array(geoIdCol, "st_id"), geoNameCol)

        ActdbHelper.leftOuterJoin(frame,
          d1.groupBy(geoNameCol).
            agg(countDistinct("accnt_id1").alias(outputCol)),
          Array(geoNameCol), outputCol)

      }
    }

    // if (operationParams.getOrElse("cacheAccountAlignment", "false").toBoolean)
    baseCalc.unpersist()

    res

  }

}