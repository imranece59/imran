package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.udf

class BIMarketsBrandsFilter extends GroupOperation {
  override val name: String = "biMarketsBrandsFilter"

  private val marketsParam = "markets"
  private val brandsParam = "brands"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val allMarkets = df.sqlContext.read.format("org.apache.spark.sql.cassandra")
      .options(Map("table" -> "d_market_def", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String])).load()
      .collect()
      .map(r => r.getAs[String]("market_id") -> r.getAs[String]("market_name"))
    val markets = operationParams.get(marketsParam)
      .map { marketsStr =>
        val m = marketsStr.split(",").map(_.trim).toSet
        allMarkets.filter { case (_, marketName) =>  m.contains(marketName)}.toMap
      }.getOrElse(allMarkets.toMap)
    val marketsBc = df.sqlContext.sparkContext.broadcast(markets)
    val isInMarkets = udf { (marketId: String) => marketsBc.value.contains(marketId) }
    val getMarketName = udf { (marketId: String) => marketsBc.value(marketId) }

    val allBrands = df.sqlContext.read.format("org.apache.spark.sql.cassandra").
      options(Map("table" -> "d_product_sales_calls", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String])).load()
      .collect()
      .map(r => r.getAs[String]("product_id") -> r.getAs[String]("brand_name"))
    val brands = operationParams.get(brandsParam).map { brandsStr =>
      val b = brandsStr.split(",").map(_.trim).toSet
      allBrands.filter { case (_, brandName) => b.contains(brandName) }.toMap
    }.getOrElse(allBrands.toMap)
    val brandsBc = df.sqlContext.sparkContext.broadcast(brands)
    val isInBrands = udf { (brandId: String) => brandsBc.value.contains(brandId) }
    val getBrandName = udf { (brandId: String) => brandsBc.value(brandId) }

    df.where(isInMarkets($"mkt_pid") and isInBrands($"fin_brnd_id")).
      withColumn("market_name", getMarketName($"mkt_pid")).
      withColumn("brand_name", getBrandName($"fin_brnd_id"))
  }
}
