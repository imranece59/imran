package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils

class HardcodeMinusOneIfNull extends GroupOperation {

  override val name: String = "minusOneIfNull"

  private final val columns = "columns"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    def checkNull(c1: String) = if (StringUtils.isBlank(c1)) "-1" else c1
    val nullUDF = udf(checkNull(_: String))

    operationParams.get(columns).map { str =>
      val cols = str.split(",").map(_.trim)
      cols.foldLeft(df) { (frame, c) =>
        frame.withColumn(s"optimus_$c", nullUDF(frame(c))).
          drop(c).withColumnRenamed(s"optimus_$c", c)
      }
    }.getOrElse(df)
  }

}
