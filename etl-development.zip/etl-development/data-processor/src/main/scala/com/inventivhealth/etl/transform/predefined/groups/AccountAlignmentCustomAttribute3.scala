package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class AccountAlignmentCustomAttribute3 extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "accountAlignmentCustAttr3"

  private val keyspace = "keypsace"
  private val table = "table"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val extractor = getDataExtractor(operationParams.getOrElse(keyspace, "ods"), operationParams.getOrElse(table, "d_account_segment"), false)
    val tenantId = parameters(ETLProcess.tenantIdParam).asInstanceOf[Int]
    val segments = extractor.extractData(df.sqlContext)
      .where(col("tenant_id") === lit(tenantId) and col("active_inactive") === lit("ACTIVE"))
      .where(col("sgmnt_id").isin(1, 2, 3) and col("accnt_sgmnt_attrb_4").notEqual(lit("GSK")) and col("sgmnt_typ").isin("Advair", "Tanzeum"))
      .select("accnt_id")
      .collect().map(r => r.getAs[String]("accnt_id")).toSet
    val segBr = df.sqlContext.sparkContext.broadcast(segments)
    val custAttr = udf { (stId: Int, accntId: String) =>
      if (Set(179, 180).contains(stId) && segBr.value.contains(accntId)) "Y"
      else "N"
    }

    df.withColumn("cust_attrib3", custAttr(col("st_id"), col("accnt_id")))
  }
}
