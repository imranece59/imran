package com.inventivhealth.etl.transform.predefined.groups
import org.apache.spark.sql.functions._

import java.text.SimpleDateFormat
import java.util.Date

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class ActdbWeekCodetoWeekId extends GroupOperation {
  override val name: String = "actdbWeekCodetoWeekId"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val inputCol = operationParams("srcCol")
    val srcFormat = operationParams("srcFormat")
    val outputCol = operationParams("output")

    def getDate(source: String, srcDateFormat: String): String = {

      val inputFormat = new SimpleDateFormat(srcDateFormat)
      val outFormat = new SimpleDateFormat("yyyyMMdd")

      if (StringUtils.isBlank(source)) ""
      else {
        val d1 = inputFormat.parse(source)
        outFormat.format(d1)
      }

    }

    val getDateUdf = udf(getDate(_: String, _: String))

    df.withColumn(outputCol, getDateUdf(df(inputCol), lit(srcFormat)))

  }
}

