package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import java.util.Date
import java.text.SimpleDateFormat
import org.apache.commons.lang.time.DateUtils
import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import org.apache.spark.sql.functions._

class BICurrWeekNbrx extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biCurrWeekNbrx"
    
  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = { 
    import df.sqlContext.implicits._
    
    val maxWeek = df.agg({"week_id"->"max"}).head().getInt(0)
    
     /*current week records  */
    val currWeekDf = df.filter(col("week_id")===maxWeek)
    
    val groupByCols = Array("tenant_id","accnt_id","st_id","brand_name","segment","segment_type","territory_name",
        "district_name","region_name","nation_name","address","city","customer_full_name","state","zip")
        
    val colNames = groupByCols.map(name=>col(name))   
    
     /*aggregating current week records  */ 
    val aggCurrWeekDf = currWeekDf.groupBy(colNames:_*)
        .agg("rx_current_week" -> "sum")          
        .withColumnRenamed("sum(rx_current_week)", "total_nbrx_current_week")
        .withColumn("total_rx_past_week",lit(0))
        
     /*calculating past week_id from the max week_id   */
    val fmt = new SimpleDateFormat("yyyyMMdd")
    val sDate = fmt.parse(maxWeek.toString())
    val eDate = DateUtils.addWeeks(sDate, -1)
    val eDateInt = fmt.format(eDate)
    
     /*past week records   */
    val pastWeekDf = df.filter(df("week_id").between(eDateInt, maxWeek-1))
    
     /*aggregating past week records */  
    val aggPastWeekDf = pastWeekDf.groupBy(colNames:_*)
        .agg("rx_current_week" -> "sum").withColumnRenamed("sum(rx_current_week)", "total_rx_past_week")
        .withColumn("total_nbrx_current_week",lit(0))
  
    val t1 = unionAllByName(aggCurrWeekDf,aggPastWeekDf)
    val t2 = t1.groupBy(colNames:_*)
              .agg("total_nbrx_current_week"->"sum","total_rx_past_week"->"sum")
              .withColumnRenamed("sum(total_nbrx_current_week)","total_nbrx_current_week")
              .withColumnRenamed("sum(total_rx_past_week)","total_rx_past_week")
    
    val fullDf = t2.where("total_nbrx_current_week!=0 or total_rx_past_week!=0")     
    val weekCode = new SimpleDateFormat("yyyy-MM-dd").format(sDate) 
    
     /*calculating nbrx volume percentage change for current week */      
    val calculateChange = udf((a:Double,b:Double) => a-b)
    val currWeekNbrxChange = fullDf.withColumn("nbrx_change", calculateChange(col("total_nbrx_current_week"),col("total_rx_past_week")))
                             .withColumn("week_id",lit(maxWeek))
                             .withColumn("week_code", lit(weekCode)) 
                             .withColumn("market_name", lit("RESP"))
                             .drop("total_rx_past_week")
                      
    currWeekNbrxChange
  }
  
  def unionAllByName(a: DataFrame, b: DataFrame): DataFrame = {
    val columns = a.columns.toSet.intersect(b.columns.toSet).map(col).toSeq
    a.select(columns: _*).unionAll(b.select(columns: _*))
  }
}