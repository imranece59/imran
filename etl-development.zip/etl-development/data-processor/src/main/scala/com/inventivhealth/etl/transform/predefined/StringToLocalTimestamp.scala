package com.inventivhealth.etl.transform.predefined

import java.sql.Timestamp
import java.time.format.DateTimeFormatter
import java.time.{LocalDateTime, ZoneOffset}

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

import scala.util.{Failure, Success, Try}

class StringToLocalTimestamp extends EtlFunction1[String, Option[Timestamp]] {
  override val name: String = "convertToLocalTimestamp"

  override def execute(s: String): Option[Timestamp] = {
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
    Try(LocalDateTime.parse(s, formatter)) match {
      case Success(v) =>
        val milli = v.atZone(ZoneOffset.UTC).toInstant.toEpochMilli
        Some(new Timestamp(milli))
      case Failure(ex) => None
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
