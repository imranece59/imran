package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import java.sql.{Date}
import java.text.SimpleDateFormat
import org.apache.commons.lang.time.DateUtils
import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import java.text.DateFormatSymbols;

case class Week(week_id:Int, week_code:Date,week_nbr:String,week_name:String)

class BIDictWeeks extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biDictWeeks"
    
  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = { 
     
    val currWeek = df.agg({"wk_id"->"max"}).head().getInt(0)
          
    var weeks = Seq(getWeekRecord(currWeek,0))
    for (a<-1 to 12) {
      weeks = weeks.:+(getWeekRecord(currWeek,a))
    }
    val weeksRdd = df.sqlContext.sparkContext.parallelize(weeks)
    val weeksDf = df.sqlContext.createDataFrame(weeksRdd)
    weeksDf
  }
  
  def getWeekRecord(maxWeekId:Int,backDateMultiplier:Int): Week = {    
    val sourceFormat = new SimpleDateFormat("yyyyMMdd");    
    val maxWeekDate = new Date(sourceFormat.parse(maxWeekId.toString()).getTime)
    val backWeekJavaDate = DateUtils.addWeeks(maxWeekDate, -1*backDateMultiplier)
    val backWeekSqlDate = new Date(backWeekJavaDate.getTime)    
    val week_nbr = sourceFormat.format(backWeekSqlDate)
    val week_id = Integer.parseInt(week_nbr)
    val week_name = "Week of "+week_nbr
    Week(week_id,backWeekSqlDate,week_nbr,week_name)
  }
  
}