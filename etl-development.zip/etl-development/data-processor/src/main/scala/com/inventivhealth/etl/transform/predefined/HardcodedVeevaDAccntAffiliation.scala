package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class HardcodedVeevaDAccntAffiliation extends EtlFunction0[String] {
  override val name: String = "hardcodeVeevaDActAffln"

  override def execute(): String = "SPHERE OF INFLUENCE"

  override def createUdf: UserDefinedFunction = udf { execute _ }
}