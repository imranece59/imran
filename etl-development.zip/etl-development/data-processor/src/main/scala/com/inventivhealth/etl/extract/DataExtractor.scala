package com.inventivhealth.etl.extract

import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, SQLContext}

/**
  * Basic interface for data extraction operations
  */
trait DataExtractor {

  /**
    * Extracts data and produces a data frame. Used in ETL process on extraction step
    * @param sqlContext - spark sql context
    * @return - data
    */
  def extractData(sqlContext: SQLContext): DataFrame

}

/**
  * Class for extraction of CSV-like data (supports any separator).
  * Schema may be provided or inferred on the fly.
  */
class CSVDataExtractor(path: String, schema: Option[StructType], delimiter: String, header:Boolean, parserLib: String) extends DataExtractor {

  override def extractData(sqlContext: SQLContext): DataFrame = {
    var dfReader = sqlContext.read
      .format("com.databricks.spark.csv")
      .option("header", header.toString)
      .option("inferSchema", schema.isEmpty.toString)
      .option("parserLib", parserLib)
      .option("delimiter", delimiter)
    if (schema.isDefined) {
      dfReader = dfReader.schema(schema.get)
    }
    dfReader.load(path)
  }

}

/**
  * Implementation of CSV data extractor. Prepends s3a:// prefix to path.
  *
  * @param source - path to file
  * @param schema - schema
  * @param delimiter - delimiter
  * @param header - whether file has header at the top
  */
class S3DataExtractor(source: String,
                      schema: Option[StructType],
                      delimiter: String,
                      header: Boolean,
                      parserLib: String) extends CSVDataExtractor(s"s3a://$source", schema, delimiter, header, parserLib) {

  override def extractData(sqlContext: SQLContext): DataFrame = {
    super.extractData(sqlContext)
  }

}

/**
  * Extracts data from Cassandra table.
  *
  * @param keyspace - keyspace
  * @param table - table
  */
class CassandraDataExtractor(keyspace: String, table: String) extends DataExtractor {

  override def extractData(sqlContext: SQLContext): DataFrame = {
    sqlContext.read
      .format("org.apache.spark.sql.cassandra")
      .options(Map("table" -> table, "keyspace" -> keyspace))
      .load()
  }

}