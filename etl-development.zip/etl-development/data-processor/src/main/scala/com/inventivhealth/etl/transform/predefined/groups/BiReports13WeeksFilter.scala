package com.inventivhealth.etl.transform.predefined.groups

import java.sql.Timestamp
import java.time.format.DateTimeFormatter
import java.time.temporal.WeekFields
import java.time.{LocalDate, ZoneOffset}

import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

import scala.util.{Failure, Success, Try}

class BiReports13WeeksFilter extends GroupOperation {
  override val name: String = "biRep13WeekFilter"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]
  val emptyDate = "30000101"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val sparkContext = df.sqlContext.sparkContext

    // resolve week timestamp and friday
    val getWeekInfo = udf { (wkId: String) =>
      val format = DateTimeFormatter.ofPattern("yyyyMMdd")
      val date = LocalDate.parse(wkId, format).atStartOfDay(ZoneOffset.UTC)

      // timestamp for week friday
      val field = WeekFields.ISO.dayOfWeek()
      val fridayForThisDate = date.`with`(field, 5)
      val timestamp = new Timestamp(fridayForThisDate.toInstant.toEpochMilli)

      // week friday
      val weekFriday = fridayForThisDate.toLocalDate.format(format).toInt

      (timestamp, weekFriday)
    }

    // add week timestamp and friday
    var tsDf = df
      .withColumn("week_info", getWeekInfo(col("wk_id")))
      .withColumn("week_timestamp" , col("week_info._1"))
      .withColumn("week_friday", col("week_info._2"))
      .drop("week_info")

    // max week friday from source
    val maxRow = tsDf.select(max("week_friday") as "max_friday").take(1)
    val maxWeek = Try(maxRow(0).getInt(0).toString) match {
      case Success(t) => t
      case Failure(_) => emptyDate
    }

    // first week friday
    val format = DateTimeFormatter.ofPattern("yyyyMMdd")
    val field = WeekFields.ISO.dayOfWeek()
    val date = LocalDate.parse(maxWeek, format).atStartOfDay(ZoneOffset.UTC).minusWeeks(12).`with`(field, 5)
    val startDay = new Timestamp(date.toInstant.toEpochMilli)
    val firstFriday = date.format(format)

    GroupObject.broadcasts = sparkContext.broadcast(Map("first_friday" -> firstFriday))

    // take only last 13 weeks
    tsDf = tsDf.where(col("week_timestamp") >= lit(startDay)).drop("week_timestamp")

    tsDf
      .withColumn("group_id", lit(maxWeek.toInt))
      .drop("week_friday")
  }
}