package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

import scala.util.{Failure, Success, Try}

class StringToDouble extends EtlFunction1[String, Double] {
  override val name: String = "convertStringToDouble"

  override def execute(s: String): Double = Try(s.toDouble) match {
    case Success(v) => v
    case Failure(ex) => 0
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
