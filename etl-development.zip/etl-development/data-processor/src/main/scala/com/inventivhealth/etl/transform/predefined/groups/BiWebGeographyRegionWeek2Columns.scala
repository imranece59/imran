package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame

class BiWebGeographyRegionWeek2Columns extends GroupOperation {
  override val name: String = "biWebGeoRegWeek2Cols"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    df
      .withColumnRenamed("district_four_week_rx", "district_four_week_nbrx")
      .withColumnRenamed("district_four_week_rx_change_perc", "district_four_week_nbrx_change_perc")
      .withColumnRenamed("territory_four_week_rx", "territory_four_week_nbrx")
      .withColumnRenamed("territory_four_week_rx_change_perc", "territory_four_week_nbrx_change_perc")
  }
}