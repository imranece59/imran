package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class ActdbWithColumns extends GroupOperation {
  override val name: String = "actdbWithColumns"

  private final val columns = "withColumns"

  // This is obsolete. Please don't use.
  // Please use actdbSelectExpr instead.
  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val withColumns = operationParams(columns).trim

    if (withColumns.startsWith("*")) {
      val exprArray = withColumns.replace(">", " as ").split(";").drop(1)
      df.selectExpr(df.columns ++ exprArray: _*)
    } else {
      val cols = withColumns.split(";").map(_.trim)
      cols.foldLeft(df) { (frame, c) => frame.withColumn(c.split(">")(1), lit(c.split(">")(0))) }
    }
  }
}
