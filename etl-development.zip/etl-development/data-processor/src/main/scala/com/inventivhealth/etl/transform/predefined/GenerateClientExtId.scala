package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction4
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class GenerateClientExtId extends EtlFunction4[Int, String, String, Int, String] {
  override val name: String = "generateClientExtId"

  override def execute(tenantId: Int, rptEntryId: String, cid: String, seqNumber: Int): String = {
     tenantId match {
        case 1 => s"${rptEntryId.trim}:${cid.trim}"   // for GSK
        case 95 => s"${rptEntryId.trim}:$seqNumber"  // for J&J
        case _ => null
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}