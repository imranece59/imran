package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.UserDefinedFunction

import scala.util.{Failure, Success, Try}

class BooleanToInt extends EtlFunction1[String, Int] {
  override val name: String = "boolToInt"

  override def execute(s: String): Int = {
    val value = Try(s.toBoolean) match {
      case Success(v) => v
      case Failure(ex) => false
    }
    if (value) 1
    else 0
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}