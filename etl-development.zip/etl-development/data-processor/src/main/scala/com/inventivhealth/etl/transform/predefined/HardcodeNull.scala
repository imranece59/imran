package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class HardcodeNull extends EtlFunction0[String] {
  override val name: String = "hardcodeNull"

  override def execute(): String = "null"

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
