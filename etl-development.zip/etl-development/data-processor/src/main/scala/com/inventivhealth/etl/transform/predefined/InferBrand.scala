package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.process.ETLProcess.tenantIdParam
import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class InferBrand extends EtlFunction1[String, String] {
  override val name: String = "inferBrand"

  override def execute(productName: String): String = {       
    if(productName!=null){
      if(productName.toUpperCase().contains("ADVAIR"))
          "ADVAIR"
      else if(productName.toUpperCase().contains("BREO"))
          "BREO"
      else
        "OTHER"   
    }else{
      "OTHER"
    }     
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
