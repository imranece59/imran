package com.inventivhealth.etl

import java.sql.Timestamp
import java.time.{LocalDate, LocalDateTime, ZoneOffset}
import java.time.format.{DateTimeFormatter, TextStyle}
import java.time.temporal.WeekFields
import java.util.Locale

import org.apache.spark.sql.functions.udf

package object bi {

  val previousMonthRx = udf { (previousMonth: Timestamp, currentMonth: Timestamp, prevRx: Double) =>
    if (previousMonth == null || currentMonth == null) 0
    else {
      val prev = previousMonth.toLocalDateTime
      val curr = currentMonth.toLocalDateTime
      if (curr.minusMonths(1).getMonthValue == prev.getMonthValue) prevRx
      else 0
    }
  }

  val brandRxPercentChange = udf { (brandRx: Double, prevBrandRx: Double) =>
    if (prevBrandRx == 0) { if (brandRx != 0) 1 else 0 }
    else (brandRx - prevBrandRx) / prevBrandRx
  }
  // consider current and previous month difference
  val brandRxPercentChangeMonth = udf { (brandRx: Double, prevBrandRx: Double, curMonth: Int, prevMonth: Int) =>
    // get previous calendar month
    val format = DateTimeFormatter.ofPattern("yyyyMMdd")
    val date = LocalDate.parse(curMonth.toString, format).atStartOfDay(ZoneOffset.UTC).minusMonths(1)
    val prevCalMonth = date.format(format).toInt

    // compare calendar and actual previous month
    val prevCalBrandRx = if (prevCalMonth == prevMonth) prevBrandRx else 0

    if (prevCalBrandRx == 0) { if (brandRx != 0) 1 else 0 }
    else (brandRx - prevCalBrandRx) / prevCalBrandRx
  }
  // consider current and previous week difference
  val brandRxPercentChangeWeek = udf { (brandRx: Double, prevBrandRx: Double, curWeek: Int, prevWeek: Int) =>
    // get previous calendar week
    val format = DateTimeFormatter.ofPattern("yyyyMMdd")
    val field = WeekFields.ISO.dayOfWeek()
    val date = LocalDate.parse(curWeek.toString, format).atStartOfDay(ZoneOffset.UTC).minusWeeks(1).`with`(field, 5)
    val prevCalWeek = date.format(format).toInt

    // compare calendar and actual previous week
    val prevCalBrandRx = if (prevCalWeek == prevWeek) prevBrandRx else 0

    if (prevCalBrandRx == 0) { if (brandRx != 0) 1 else 0 }
    else (brandRx - prevCalBrandRx) / prevCalBrandRx
  }
  val marketRxChange = udf { (marketRx: Double, prevMarketRx: Double) =>
    marketRx - prevMarketRx
  }

  val marketShare = udf { (brandRx: Double, marketRx: Double) =>
    if (marketRx == 0) 0
    else brandRx / marketRx
  }
  //prev rx???
  val marketShareChange = udf { (brandRx: Double, marketRx: Double, prevBrandRx: Double, prevMarketRx: Double) =>
    val c = if (marketRx == 0) 0 else brandRx / marketRx
    val p = if (prevMarketRx == 0) 0 else prevBrandRx / prevMarketRx
    c - p
  }
  // consider current and previous month difference
  val marketShareChangeMonth = udf { (brandRx: Double, marketRx: Double, prevBrandRx: Double, prevMarketRx: Double,
                                      curMonth: Int, prevMonth: Int) =>
    // get previous calendar month
    val format = DateTimeFormatter.ofPattern("yyyyMMdd")
    val date = LocalDate.parse(curMonth.toString, format).atStartOfDay(ZoneOffset.UTC).minusMonths(1)
    val prevCalMonth = date.format(format).toInt

    // compare calendar and actual previous month
    val prevCalBrandRx = if (prevCalMonth == prevMonth) prevBrandRx else 0
    val prevCalMarketRx = if (prevCalMonth == prevMonth) prevMarketRx else 0

    val c = if (marketRx == 0) 0 else brandRx / marketRx
    val p = if (prevCalMarketRx == 0) 0 else prevCalBrandRx / prevCalMarketRx
    c - p
  }
  // consider current and previous week difference
  val marketShareChangeWeek = udf { (brandRx: Double, marketRx: Double, prevBrandRx: Double, prevMarketRx: Double,
                                     curWeek: Int, prevWeek: Int) =>
    // get previous calendar week
    val format = DateTimeFormatter.ofPattern("yyyyMMdd")
    val field = WeekFields.ISO.dayOfWeek()
    val date = LocalDate.parse(curWeek.toString, format).atStartOfDay(ZoneOffset.UTC).minusWeeks(1).`with`(field, 5)
    val prevCalWeek = date.format(format).toInt

    // compare calendar and actual previous week
    val prevCalBrandRx = if (prevCalWeek == prevWeek) prevBrandRx else 0
    val prevCalMarketRx = if (prevCalWeek == prevWeek) prevMarketRx else 0

    val c = if (marketRx == 0) 0 else brandRx / marketRx
    val p = if (prevCalMarketRx == 0) 0 else prevCalBrandRx / prevCalMarketRx
    c - p
  }
  // resolve week code
  val getWeekCode = udf { (groupId: Int) =>
    val format = DateTimeFormatter.ofPattern("yyyyMMdd")
    val date = LocalDate.parse(groupId.toString, format).atStartOfDay(ZoneOffset.UTC)
    new Timestamp(date.toInstant.toEpochMilli)
  }

  // resolve month id and month name, month_date is the first month day
  val getMonthInfo = udf { (month_date: Int) =>
    val format = DateTimeFormatter.ofPattern("yyyyMMdd")
    val date = LocalDate.parse(month_date.toString, format).atStartOfDay(ZoneOffset.UTC)
    val monthShort = date.getMonth.getDisplayName(TextStyle.SHORT, Locale.getDefault)
    val year = date.getYear.toString
    val monthName = monthShort + " " + year

    val monthIdFormat = DateTimeFormatter.ofPattern("yyyyMM")
    val monthId = date.format(monthIdFormat).toInt

    (monthId, monthName)
  }

  // create customer_full_name
  val getCustomerFullName = udf { (lstNm: String, frstNm: String, mddlNm: String) =>
    val last = if (lstNm == null) "" else lstNm
    val first = if (frstNm == null) "" else frstNm
    val middle = if (mddlNm == null) "" else mddlNm
    (last + ", " + first + " " + middle).trim
  }

  // create address
  val getAddress = udf { (adrs1: String, adrs2: String, adrs3: String) =>
    val addr1 = if (adrs1 == null) "" else adrs1
    val addr2 = if (adrs2 == null) "" else if (!adrs2.isEmpty) ", " + adrs2 else adrs2
    val addr3 = if (adrs3 == null) "" else if (!adrs3.isEmpty) ", " + adrs3 else adrs3
    (addr1 + addr2 + addr3).trim
  }

  val avgTargetFrequency = udf { (targetCalls: Long, targetsCalled: Long) =>
    if (targetsCalled == 0) 0d
    else targetCalls.toDouble / targetsCalled.toDouble
  }

  val avgPrescriberCallsPerDay = udf { (prescriberCalls: Long, numWorkingDays: Long) =>
    if (numWorkingDays == 0) 0d
    else prescriberCalls.toDouble / numWorkingDays.toDouble
  }

  val targetCallsPerDay = udf { (targetCalls: Long, numWorkDays: Long) =>
    if (numWorkDays == 0) 0d
    else targetCalls.toDouble / numWorkDays.toDouble
  }

  val percentCallsToTargets = udf { (targetCalls: Long, prescriberCalls: Long) =>
    if (prescriberCalls == 0) 0d
    else targetCalls.toDouble / prescriberCalls.toDouble
  }

  val reach = udf { (targetsCalled: Long, totalTargets: Long) =>
    if (totalTargets == 0) 0d
    else targetsCalled.toDouble / totalTargets.toDouble
  }
}
