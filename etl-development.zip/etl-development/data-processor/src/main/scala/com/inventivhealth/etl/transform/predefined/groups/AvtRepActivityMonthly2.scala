package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils
import com.inventivhealth.etl.actdb._
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess

class AvtRepActivityMonthly2 extends GroupOperation {

  override val name: String = "avtRepActivityMonthly2"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val nCols = Array("activity_type", "call_type", "customer_full_name", "segment", "segment_type", "target", "month_id")
    val dCols = Array("call_type", "customer_full_name", "segment", "segment_type", "target", "month_id")

    ActdbHelper.persistDf("primary", df)

    // Computing Numerators
    val n1 = df.groupBy("tenant_id", "st_id", "territory_name", "district_name", "region_name",
      "nation_name", "month_id", "month_name", "target", "customer_full_name", "activity_type",
      "call_type", "segment", "segment_type").
      agg(countDistinct("accnt_call_id").alias("call_count_geo_lvl1"))

    val n2 = df.groupBy("district_name", nCols: _*).
      agg(countDistinct("accnt_call_id").alias("call_count_geo_lvl2"))

    val n3 = df.groupBy("region_name", nCols: _*).
      agg(countDistinct("accnt_call_id").alias("call_count_geo_lvl3"))

    val n4 = df.groupBy("nation_name", nCols: _*).
      agg(countDistinct("accnt_call_id").alias("call_count_geo_lvl4"))

    // Computing Denominators
    val d1 = df.groupBy("territory_name", dCols: _*).
      agg(countDistinct("accnt_call_id").alias("call_count_geo_lvl1_den"))

    val d2 = df.groupBy("district_name", dCols: _*).
      agg(countDistinct("accnt_call_id").alias("call_count_geo_lvl2_den"))

    val d3 = df.groupBy("region_name", dCols: _*).
      agg(countDistinct("accnt_call_id").alias("call_count_geo_lvl3_den"))

    val d4 = df.groupBy("nation_name", dCols: _*).
      agg(countDistinct("accnt_call_id").alias("call_count_geo_lvl4_den"))

    // Join with result data frame

    var resDf = ActdbHelper.leftOuterJoin(n1, n2,
      nCols :+ "district_name", "call_count_geo_lvl2")

    resDf = ActdbHelper.leftOuterJoin(resDf, n3,
      nCols :+ "region_name", "call_count_geo_lvl3")

    resDf = ActdbHelper.leftOuterJoin(resDf, n4,
      nCols :+ "nation_name", "call_count_geo_lvl4")

    resDf = ActdbHelper.leftOuterJoin(resDf, d1,
      dCols :+ "territory_name", "call_count_geo_lvl1_den")

    resDf = ActdbHelper.leftOuterJoin(resDf, d2,
      dCols :+ "district_name", "call_count_geo_lvl2_den")

    resDf = ActdbHelper.leftOuterJoin(resDf, d3,
      dCols :+ "region_name", "call_count_geo_lvl3_den")

    resDf = ActdbHelper.leftOuterJoin(resDf, d4,
      dCols :+ "nation_name", "call_count_geo_lvl4_den")

    ActdbHelper.persistDf("primary", resDf)

    resDf

  }

}