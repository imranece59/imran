package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction4
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

import scala.util.{Failure, Success, Try}

class LookupSegmentType extends EtlFunction4[String, String, String, String, String] {
  override val name: String = "lookupSegmentType"

  override def execute(mktId: String, finBrnd: String, custTrgt: String, brndSeg: String): String = {
    //todo [Victor]: mktId == "pv_mkt_id" && finBrnd == "pv_fin_brnd_id" - impossible to be true cause mkt_id is Int
    //mktId == "pv_mkt_id" && finBrnd == "pv_fin_brnd_id" && (custTrgt == null || brndSeg == null)
    val mktIdInt = Try(mktId.toInt) match {
      case Success(v) => v
      case Failure(_) => 0
    }
    broadcasts.value.get("product_xref_gsk").map { arr =>
      arr.map(row => row.getAs[Int]("mkt_id") -> row.getAs[String]("product"))
        .toMap
        .getOrElse(mktIdInt, null)
    }.orNull
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
