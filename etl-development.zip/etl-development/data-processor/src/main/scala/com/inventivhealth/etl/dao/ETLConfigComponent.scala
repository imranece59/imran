package com.inventivhealth.etl.dao

import com.inventivhealth.etl.config.ConfigComponent
import com.inventivhealth.etl.config.model.{ETLConfig, ETLMapping}
import com.inventivhealth.etl.util.FormattingUtil._
import org.apache.spark.sql.types.{StringType, StructField, StructType}

trait ETLConfigComponent {

  val etlConfig: ETLConfig

  val mappings: List[ETLMapping]

  val mappingIns: List[ETLMapping]

  val mappingLookups: List[ETLMapping]

  val mappingUpd: List[ETLMapping]

  val mappingDel: List[ETLMapping]

  val fileName: String
  val dateLabel: Option[Long]
  val isIncremental: Boolean
  val hasHeader: Boolean
  val delim: String
  val schema: Option[StructType]
  val keyCols: Seq[String]
  val columns: Array[String]

}

trait CassandraETLConfigComponent extends ETLConfigComponent {
  this: ConfigComponent with CassandraDaoComponent =>

  override lazy val mappings: List[ETLMapping] = cassandraDao.getMapping(etlConfig.tenantId, etlConfig.processId, "A")

  override lazy val mappingLookups: List[ETLMapping] = cassandraDao.getMapping(etlConfig.tenantId, etlConfig.processId, "L")

  override lazy val mappingIns: List[ETLMapping] = mappings ++ cassandraDao.getMapping(etlConfig.tenantId, etlConfig.processId, "I")

  override lazy val mappingUpd: List[ETLMapping] = mappings ++ cassandraDao.getMapping(etlConfig.tenantId, etlConfig.processId, "U")

  override lazy val mappingDel: List[ETLMapping] = cassandraDao.getMapping(etlConfig.tenantId, etlConfig.processId, "D")

  override val fileName = etlConfig.sourceEntityName
  override val dateLabel = etlConfig.lastRun.map(_.getTime)
  override val isIncremental = etlConfig.isIncremental
  override val hasHeader = etlConfig.hasHeader
  override lazy val delim = etlConfig.delim.getOrElse(appConfig.defaultDelimiter)
  override lazy val schema = etlConfig.schemaCols.map(sc => StructType(sc.split(escapeCharacters(delim)).map(StructField(_, StringType))))
  override lazy val keyCols: Seq[String] = etlConfig.keyCols.split(escapeCharacters(delim))
  override lazy val columns = etlConfig.schemaCols.map(sc => sc.split(escapeCharacters(delim))).get

}
