package com.inventivhealth.etl.process.steps

import java.sql.Timestamp

import com.inventivhealth.etl.config.ConfigComponent
import com.inventivhealth.etl.dao.ETLConfigComponent
import com.inventivhealth.etl.extract.{DataExtractorFactory, DataPart, DataSources}
import com.inventivhealth.etl.spark.SparkComponent
import com.inventivhealth.etl.util.DataFrameComparator._
import com.inventivhealth.etl.util.FormattingUtil._
import com.typesafe.scalalogging.slf4j.LazyLogging
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{Column, DataFrame}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable

trait Delta extends LazyLogging {
  this: ConfigComponent with ETLConfigComponent with DataExtractorFactory with SparkComponent =>

  /**
    * Computes delta by splitting source data into parts
    *   - data which should be created;
    *   - data which should be updated;
    *   - data which should be marked as deleted (soft delete);
    *
    * @param source - data frame with data from source
    * @return
    */
  def findDelta(source: DataFrame): List[DataPart] = {
    val parts = if (isIncremental || dateLabel.isEmpty)
      DataPart(source, mappingIns, Some("insert")) :: Nil
    else {
      DataSources.withName(etlConfig.sourceName) match {
        case DataSources.`s3` | DataSources.`classPath` | DataSources.`local` => fileDelta(source)
        case DataSources.`ods` => cassandraTableDelta(source)
      }
    }
    val rawRow = getRawRow(schema.getOrElse(source.schema))
    parts.map(dp => dp.copy(data = dp.data.withColumn("row", rawRow)))
  }

  private def fileDelta(source: DataFrame): List[DataPart] = {
    val date = dateLabel.get
    val prevFilePath = replacePlaceholders(etlConfig.prevEntityLoc, date.toString)
    val s3File = s"$prevFilePath/$fileName"

    logger.info(s"Previous run found - $s3File. Looking for difference")

    val extractor = getDataExtractor(etlConfig.sourceName, s3File, hasHeader, schema, Some(delim), appConfig.parserLib)
    val previousSource = extractor.extractData(sqlContext)
    if (appConfig.cachePreviousSource) {
      previousSource.persist(StorageLevel.MEMORY_AND_DISK_SER)
    }

    val diffAddsDf = source.diffAdds(previousSource, keyCols)
    val diffDelsDF = source.diffDels(previousSource, keyCols)
    val diffUpdsDf = source.diffUpds(previousSource, keyCols)
    List(
      DataPart(diffAddsDf, mappingIns, Some("insert")),
      DataPart(diffUpdsDf, mappingUpd, Some("update")),
      DataPart(diffDelsDF, mappingDel, Some("delete")))
  }

  private def cassandraTableDelta(source: DataFrame): List[DataPart] = {
    val time = new Timestamp(dateLabel.get)
    val extractor = getDataExtractor(etlConfig.sourceName, etlConfig.sourceEntityName, hasHeader)
    var data = extractor.extractData(sqlContext)
    if (etlConfig.isIncremental) {
      data = data.where(col("created_dt").gt(lit(time)) or col("updated_dt").gt(lit(time)))
    }
    DataPart(data, mappingIns, Some("insert")) :: Nil
  }

  private def getRawRow(dataSchema: StructType): Column = {
    val iterator = dataSchema.fieldNames.iterator
    val columns = new mutable.ListBuffer[Column]()
    while (iterator.hasNext) {
      val field = iterator.next()
      columns += col(field)
      if (iterator.hasNext) {
        columns += lit(delim)
      }
    }
    concat(columns: _*)
  }
}