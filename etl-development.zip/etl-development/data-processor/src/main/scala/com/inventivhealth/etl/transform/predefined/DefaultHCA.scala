package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

/**
  * used in d_account
  */
class DefaultHCA extends EtlFunction0[String] {
  override val name: String = "defaultHCA"

  override def execute(): String = "HCA"

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
