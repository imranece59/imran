package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

import scala.util.{Failure, Success, Try}

class StringWithDecimalToInt extends EtlFunction1[String, Int] {
  override val name: String = "convertDecimalStringToInt"

  override def execute(s: String): Int = Try(s.toFloat.toInt) match {
    case Success(v) => v
    case Failure(ex) => 0
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
