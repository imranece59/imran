package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame

class BiWebGeographyNationWeek1Columns extends GroupOperation {
  override val name: String = "biWebGeoNatWeek1Cols"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    df
      .withColumnRenamed("nation_four_week_rx", "nation_four_week_nbrx")
      .withColumnRenamed("nation_four_week_rx_change_perc", "nation_four_week_nbrx_change_perc")
      .withColumnRenamed("region_four_week_rx", "region_four_week_nbrx")
      .withColumnRenamed("region_four_week_rx_change_perc", "region_four_week_nbrx_change_perc")
  }
}