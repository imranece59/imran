package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.commons.lang3.StringUtils
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.actdb._

class ActdbAccountCallGeoNames extends GroupOperation {

  override val name: String = "actdbAccountCallGeoNames"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val outputCols = operationParams("geoLevels").trim.split(",").map(_.trim)

    val g = new CassandraDataExtractor("ods", "d_geography").
      extractData(df.sqlContext).select(col("geo_nm"), col("geo_id")).persist

    val h = new CassandraDataExtractor("ods", "d_geography_hierarchy").
      extractData(df.sqlContext).select(col("geo_id").alias("territory_id_temp"), col("prnt2_geo_id").alias("district_id"),
        col("prnt3_geo_id").alias("region_id"), col("prnt4_geo_id").alias("nation_id"))

    var res = df.join(h, df("territory_id") === h("territory_id_temp"), "left_outer").
      select(df("*") +: h.columns.map(c => h(c)): _*).
      drop("territory_id_temp")

    //val g1 = g.drop("geo_nbr") //.repartition(col("geo_id")).sortWithinPartitions().persist
    //g.unpersist

    res = outputCols.foldLeft(res) { (frame, c) =>
      frame.join(g, frame(c + "_id") === g("geo_id"), "left_outer").
        select(frame("*") +: Seq(g("geo_nm").alias(c + "_name")): _*)
    }

    g.unpersist

    val newCols = outputCols.flatMap(c => Array(col(c + "_name"), col(c + "_id")))

    res.select(df("*") +: newCols: _*)

  }
}
