package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class LookupFAccountCallDiscussionStId extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "lkpFAccntCallDscssnStId"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val tenantId = parameters(ETLProcess.tenantIdParam)
    val sqlContext = df.sqlContext

    val fAccountCallDataExtractor = getDataExtractor(sourceName, "f_account_call", false)
    var fAccountCallDf = fAccountCallDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (fAccountCallDf.schema.fieldNames.contains("active_inactive"))  {
      fAccountCallDf = fAccountCallDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }

    val dSfaDataExtractor = getDataExtractor(sourceName, "d_sfa", false)
    var dSfaDf = dSfaDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (dSfaDf.schema.fieldNames.contains("active_inactive"))  {
      dSfaDf = dSfaDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }

    val fAccountCallJoinedDSfaDf = fAccountCallDf.join(dSfaDf, fAccountCallDf("st_id") === dSfaDf("st_id")).select(fAccountCallDf("call2_c"), fAccountCallDf("st_id"))

    df.join(fAccountCallJoinedDSfaDf, df("Call2_vod__c") === fAccountCallJoinedDSfaDf("call2_c"), "left_outer").select(df("*"), fAccountCallJoinedDSfaDf("st_id"))
  }
}