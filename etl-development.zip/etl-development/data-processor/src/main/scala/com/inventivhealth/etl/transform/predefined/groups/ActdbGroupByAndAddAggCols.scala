package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.actdb._
import com.inventivhealth.etl.extract.CassandraDataExtractor
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class ActdbGroupByAndAddAggCols extends GroupOperation {

  override val name: String = "actdbGroupByAndAddAggCols"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    val groupByCols = operationParams("groupBy").split(",").map(df(_))
    val srcJoinByCols = operationParams("groupBy").split(",").map(df(_))

    // Do aggregation and compute the metrics
    val aggColsExprArray = operationParams("aggCols").split(";").map(_.trim)
    val aggComputations = getAggCols(aggColsExprArray)

    val dfAgg = df.groupBy(groupByCols: _*).agg(aggComputations.take(1)(0), aggComputations.drop(1): _*)

    // rename join columns 
    val df2 = operationParams("groupBy").split(",").
      foldLeft(dfAgg) { (frame, c) => frame.withColumnRenamed(c, c + "_temp") }

    val lkpJoinByCols = operationParams("groupBy").split(",").map(v => df2(v + "_temp"))

    val newCols = aggColsExprArray.map(v => df2(v.split(">")(1))).toSeq
    val returnColumns = df("*") +: newCols
    val joinCond = srcJoinByCols.zip(lkpJoinByCols).map { case (s, l) => s === l }.reduceLeft(_ && _)

    var resDf = df
      .join(df2, joinCond, "left_outer")
      .select(returnColumns: _*)

    if (operationParams.contains("outputPersistKey"))
      ActdbHelper.persistDf(operationParams("outputPersistKey"), resDf)

    resDf
  }

  def getAggCols(aggCols: Array[String]) = {

    aggCols.map(c => {

      val parts1 = c.split(">").map(_.trim)
      val colName = parts1(0).replace("\\)", "").split("\\(")(1).split("\\)")(0).trim
      val funcName = parts1(0).split("\\(")(0).trim

      funcName.toLowerCase match {
        case "sum"           => sum(colName).alias(parts1(1))
        case "max"           => max(colName).alias(parts1(1))
        case "min"           => min(colName).alias(parts1(1))
        case "count"         => count(colName).alias(parts1(1))
        case "avg"           => count(colName).alias(parts1(1))
        case "countdistinct" => countDistinct(colName).alias(parts1(1))
        case "sumdistinct"   => sumDistinct(colName).alias(parts1(1))
      }
    })

  }

}

class ActdbGroupByAndAddAggColsAs1 extends ActdbGroupByAndAddAggCols {
  override val name: String = "actdbGroupByAndAddAggColsAs1"
}

class ActdbGroupByAndAddAggColsAs2 extends ActdbGroupByAndAddAggCols {
  override val name: String = "actdbGroupByAndAddAggColsAs2"
}

class ActdbGroupByAndAddAggColsAs3 extends ActdbGroupByAndAddAggCols {
  override val name: String = "actdbGroupByAndAddAggColsAs3"
}

class ActdbGroupByAndAddAggColsAs4 extends ActdbGroupByAndAddAggCols {
  override val name: String = "actdbGroupByAndAddAggColsAs4"
}

class ActdbGroupByAndAddAggColsAs5 extends ActdbGroupByAndAddAggCols {
  override val name: String = "actdbGroupByAndAddAggColsAs5"
}

class ActdbGroupByAndAddAggColsAs6 extends ActdbGroupByAndAddAggCols {
  override val name: String = "actdbGroupByAndAddAggColsAs6"
}

class ActdbGroupByAndAddAggColsAs8 extends ActdbGroupByAndAddAggCols {
  override val name: String = "actdbGroupByAndAddAggColsAs8"
}

class ActdbGroupByAndAddAggColsAs9 extends ActdbGroupByAndAddAggCols {
  override val name: String = "actdbGroupByAndAddAggColsAs9"
}

class ActdbGroupByAndAddAggColsAs10 extends ActdbGroupByAndAddAggCols {
  override val name: String = "actdbGroupByAndAddAggColsAs10"
}

class ActdbGroupByAndAddAggColsAs11 extends ActdbGroupByAndAddAggCols {
  override val name: String = "actdbGroupByAndAddAggColsAs11"
}

class ActdbGroupByAndAddAggColsAs12 extends ActdbGroupByAndAddAggCols {
  override val name: String = "actdbGroupByAndAddAggColsAs12"
}

