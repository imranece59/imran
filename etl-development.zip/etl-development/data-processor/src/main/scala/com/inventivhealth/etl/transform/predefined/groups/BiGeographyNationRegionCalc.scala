package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.bi._
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.storage.StorageLevel
import com.inventivhealth.etl.transform.api.GroupObject

class BiGeographyNationRegionCalc extends GroupOperation {
  override val name: String = "biGeoNatRegCalc"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    // first friday
    val firstFriday = GroupObject.broadcasts.value("first_friday").toInt

    // cache input df
    df.persist(StorageLevel.MEMORY_AND_DISK_SER)

    /**
      * get nation, region level
      * distinct payer rows after joins
      */
    val allDf = df
      .select("wk_id", "fin_brnd_id", "mkt_pid", "sls_chnl_desc", "prsc_cid", "tenant_id", "st_id", "market_name",
        "brand_name", "nation_name", "region_name", "target", "rx", "group_id")
      .distinct()

    // get only nation level
    val allNationDf = df
      .select("wk_id", "fin_brnd_id", "mkt_pid", "sls_chnl_desc", "prsc_cid", "tenant_id", "st_id", "market_name",
        "brand_name", "nation_name", "target", "rx", "group_id")
      .distinct()

    /**
      * sum(rx) group by market, brand, nation, region, target, group_id (group week friday) and get distinct rows
      * and count(prescriber) for the same group
      */
    var aggDf = allDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "nation_name", "region_name", "target", "group_id")
      .agg(sum("rx") as "four_week_rx", expr("count(case when rx > 0 then tenant_id else null end)") as "four_week_prescriber_count")

    // sum and count on region level
    var aggNationDf = allNationDf
      .groupBy("tenant_id", "st_id", "market_name", "brand_name", "nation_name", "target", "group_id")
      .agg(sum("rx") as "nation_four_week_rx", expr("count(case when rx > 0 then tenant_id else null end)") as "nation_four_week_prescriber_count")

    // add previous four_week_rx column and previous four_week_prescriber_count
    aggDf = aggDf
      .withColumn("prev_four_week_rx",
        lag("four_week_rx", 1).over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "nation_name", "region_name", "target").orderBy("group_id")))
      .withColumn("prev_four_week_prescriber_count",
        lag("four_week_prescriber_count", 1).over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "nation_name", "region_name", "target").orderBy("group_id")))

    // nation level
    aggNationDf = aggNationDf
      .withColumn("nation_prev_four_week_rx",
        lag("nation_four_week_rx", 1).over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "nation_name", "target").orderBy("group_id")))
      .withColumn("nation_prev_four_week_prescriber_count",
        lag("nation_four_week_prescriber_count", 1).over(Window.partitionBy("tenant_id", "st_id", "market_name", "brand_name", "nation_name", "target").orderBy("group_id")))

    // replace null values for prev_ columns
    aggDf = aggDf.withColumn("prev_four_week_prescriber_count", when(col("prev_four_week_prescriber_count").isNull, lit(0)).otherwise(col("prev_four_week_prescriber_count")))
    aggDf = aggDf.withColumn("prev_four_week_rx", when(col("prev_four_week_rx").isNull, lit(0)).otherwise(col("prev_four_week_rx")))

    aggNationDf = aggNationDf.withColumn("nation_prev_four_week_prescriber_count", when(col("nation_prev_four_week_prescriber_count").isNull, lit(0)).otherwise(col("nation_prev_four_week_prescriber_count")))
    aggNationDf = aggNationDf.withColumn("nation_prev_four_week_rx", when(col("nation_prev_four_week_rx").isNull, lit(0)).otherwise(col("nation_prev_four_week_rx")))

    // add four_week_rx_change_perc, four_week_prescriber_count_change_perc
    aggDf = aggDf
      .withColumn("four_week_rx_change_perc", brandRxPercentChange(col("four_week_rx"), col("prev_four_week_rx")))
      .withColumn("four_week_prescriber_count_change_perc", brandRxPercentChange(col("four_week_prescriber_count"), col("prev_four_week_prescriber_count")))
      .drop("prev_four_week_rx")
      .drop("prev_four_week_prescriber_count")

    // nation level
    aggNationDf = aggNationDf
      .withColumn("nation_four_week_rx_change_perc", brandRxPercentChange(col("nation_four_week_rx"), col("nation_prev_four_week_rx")))
      .withColumn("nation_four_week_prescriber_count_change_perc", brandRxPercentChange(col("nation_four_week_prescriber_count"), col("nation_prev_four_week_prescriber_count")))
      .drop("nation_prev_four_week_rx")
      .drop("nation_prev_four_week_prescriber_count")

    // join region and nation aggregations
    aggDf = aggDf.join(aggNationDf, Seq("tenant_id", "st_id", "market_name", "brand_name", "nation_name", "target", "group_id"))
      .select(aggDf("*"), aggNationDf("nation_four_week_rx"), aggNationDf("nation_four_week_prescriber_count"), aggNationDf("nation_four_week_rx_change_perc"),
        aggNationDf("nation_four_week_prescriber_count_change_perc"))

    // filter out first week
    aggDf = aggDf.where(col("group_id").notEqual(lit(firstFriday)))

    aggDf = aggDf
      .withColumnRenamed("four_week_rx", "region_four_week_rx")
      .withColumnRenamed("four_week_rx_change_perc", "region_four_week_rx_change_perc")
      .withColumnRenamed("four_week_prescriber_count", "region_four_week_prescriber_count")
      .withColumnRenamed("four_week_prescriber_count_change_perc", "region_four_week_prescriber_count_change_perc")

    aggDf
      .withColumn("week_code", getWeekCode(col("group_id")))
      .withColumnRenamed("group_id", "week_id")
  }
}