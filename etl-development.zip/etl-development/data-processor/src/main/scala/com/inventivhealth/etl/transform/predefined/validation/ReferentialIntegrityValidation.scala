package com.inventivhealth.etl.transform.predefined.validation

import com.inventivhealth.etl.transform.api.CellValidation
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class ReferentialIntegrityValidation extends CellValidation[String] {
  override val name: String = "referentialIntegrity"

  override def execute(keyValue: String, keyName: String, param: String): Option[String] = {
    if (StringUtils.isBlank(keyValue)) {
      Some("RI_VIOLATION")
    }
    else None
  }

  override def createUdf: UserDefinedFunction = udf { super[CellValidation].execute _ }
}
