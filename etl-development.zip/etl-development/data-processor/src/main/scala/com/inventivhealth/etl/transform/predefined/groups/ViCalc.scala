package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.transform.api.{GroupObject, GroupOperation}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class ViCalc extends GroupOperation {
  override val name: String = "viCalc"

  private val pivotColumnParam = "pivotColumn"
  private val pivotValuesNumParam = "pivotValuesNum"
  private val groupByColumnsParam = "groupByColumns"
  private val metric1ColumnParam = "metric1Column"
  private val metric2ColumnParam = "metric2Column"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val pivotColumn = operationParams.getOrElse(pivotColumnParam, "wk_id")
    val pivotValuesNum = operationParams.getOrElse(pivotValuesNumParam, "13").toInt
    val groupByColumns = operationParams.getOrElse(groupByColumnsParam, "prsc_cid, market_name, fin_brnd_id").split(",").map(c => c.trim)
    val metric1Column = operationParams.getOrElse(metric1ColumnParam, null)
    val metric2Column = operationParams.getOrElse(metric2ColumnParam, null)
    val metricColumns = Array(metric1Column, metric2Column).filter(m => m != null)

    // get pivot values
    var pivotValues = GroupObject.pivotValues

    // take only pivotValuesNum of pivot values
    pivotValues = pivotValues.take(pivotValuesNum)

    // aggregate data and pivot
    var pivotDf = df
      .groupBy(groupByColumns.map(c => col(c)): _*)
      .pivot(pivotColumn, pivotValues)
      .sum(metricColumns: _*)

    // rename pivot columns
    pivotValues.zipWithIndex.foreach {
      case (pivotValue, i) =>
        if (metricColumns.size == 1 && metric1Column != null)
          pivotDf = pivotDf.withColumnRenamed(pivotValue.toString, s"B${1 + i}_VOD__C")

        if (metricColumns.size == 1 && metric2Column != null)
          pivotDf = pivotDf.withColumnRenamed(pivotValue.toString, s"B${pivotValuesNum + 1 + i}_VOD__C")

        if (metricColumns.size == 2) {
          pivotDf = pivotDf.withColumnRenamed(pivotValue.toString + "_sum(" + metric1Column + ")", s"B${1 + i}_VOD__C")
          pivotDf = pivotDf.withColumnRenamed(pivotValue.toString + "_sum(" + metric2Column + ")", s"B${pivotValuesNum + 1 + i}_VOD__C")
        }
    }

    // add missing columns if any
    for (i <- 0 until (pivotValuesNum - pivotValues.length) ) {
      if (metric1Column != null)
        pivotDf = pivotDf.withColumn(s"B${1 + pivotValues.length + i}_VOD__C", lit(null))
      if (metric2Column != null)
        pivotDf = pivotDf.withColumn(s"B${pivotValuesNum + 1 + pivotValues.length + i}_VOD__C", lit(null))
    }

    // replace null with zero
    val calcColumns = pivotDf.schema.fieldNames.filter(f => f.contains("_VOD__C"))
    calcColumns.foreach(f => pivotDf = pivotDf.withColumn(f, when(col(f).isNull, lit(0)).otherwise(col(f))))

    // get sorted columns
    var sortedColumns = calcColumns.map(f => f.replaceAll("\\D+","").toInt -> f).sortBy(_._1).map { case(_, name) => name }
    sortedColumns = groupByColumns ++ sortedColumns

    // get df with sorted columns
    pivotDf = pivotDf.select(sortedColumns.map(c => col(c)): _*)

    pivotDf
  }
}