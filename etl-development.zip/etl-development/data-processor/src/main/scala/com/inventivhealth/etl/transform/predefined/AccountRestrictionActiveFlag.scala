package com.inventivhealth.etl.transform.predefined

import java.time.LocalDate
import java.time.format.DateTimeFormatter

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

/**
  * Used in account_restriction table
  */
class AccountRestrictionActiveFlag extends EtlFunction1[String, String] {
  override val name: String = "accountRestrictionActive"

  override def execute(expDateStr: String): String =
    Option(expDateStr).map { str =>
      val formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd")
      val expDate = LocalDate.parse(expDateStr, formatter)
      val result = expDate.compareTo(LocalDate.now())
      if (result > 0) "Y"
      else "N"
    }.getOrElse("Y")

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
