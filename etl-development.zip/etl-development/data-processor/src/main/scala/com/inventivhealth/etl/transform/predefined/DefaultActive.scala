package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class DefaultActive extends EtlFunction0[String] {
  override val name: String = "defaultActive"

  override def execute(): String = "ACTIVE"

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
