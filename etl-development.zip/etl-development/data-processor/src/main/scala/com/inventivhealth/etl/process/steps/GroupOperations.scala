package com.inventivhealth.etl.process.steps

import com.inventivhealth.etl.config.ConfigComponent
import com.inventivhealth.etl.config.model.GroupOp
import com.inventivhealth.etl.dao.{CassandraDaoComponent, ETLConfigComponent}
import com.inventivhealth.etl.transform.ETLFunctionsComponent
import com.typesafe.scalalogging.slf4j.LazyLogging
import org.apache.spark.sql.DataFrame

trait GroupOperations extends LazyLogging {
  this: CassandraDaoComponent with ConfigComponent with ETLConfigComponent with ETLFunctionsComponent =>

  def applySourceGroupOperations(data: DataFrame): DataFrame = {
    val processOperations = cassandraDao.getGroupOperations(etlConfig.tenantId, etlConfig.processId, "source")
    applyGroupOperations(data, processOperations)
  }

  def applyTargetGroupOperations(data: DataFrame): DataFrame = {
    val processOperations = cassandraDao.getGroupOperations(etlConfig.tenantId, etlConfig.processId, "target")
    applyGroupOperations(data, processOperations)
  }

  private def applyGroupOperations(data: DataFrame, ops: List[GroupOp]): DataFrame = {
    logger.info(s"${ops.size} group operations found for process ${etlConfig.processId}")
    ops.foreach(g => logger.debug(s"process ${etlConfig.processId}, Group operation $g found"))

    ops.sortBy(_.order).foldLeft(data) { (df, op) =>
      val func = groupOperations(op.name)
      logger.info(s"Applying group operation ${op.name} -> ${func.getClass.getSimpleName}")
      func.execute(df, op.parameters)
    }
  }

}
