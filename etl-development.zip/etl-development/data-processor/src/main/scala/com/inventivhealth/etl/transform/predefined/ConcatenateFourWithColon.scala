package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction4
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class ConcatenateFourWithColon extends EtlFunction4[String, String, String, String, String] {
  override val name: String = "concatFourWithColon"

  override def execute(s1: String, s2: String, s3: String, s4: String): String = {
    if (s1 == null || s2 == null || s3 == null || s4 == null) {
      null
    } else {
      val first = s1.trim
      val second = s2.trim
      val third = s3.trim
      val fourth = s4.trim
      s"$first:$second:$third:$fourth"
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}