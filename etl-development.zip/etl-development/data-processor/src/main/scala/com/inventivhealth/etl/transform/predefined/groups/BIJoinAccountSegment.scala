package com.inventivhealth.etl.transform.predefined.groups

import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class BIJoinAccountSegment extends GroupOperation {
  override val name: String = "biJoinAccountSegment"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    import df.sqlContext.implicits._
    val segmentFields = udf { (brand: String, segmentValue: String, attr4: String) =>
      val sv1 = if (segmentValue != null) segmentValue else "5_N/A"
      val sv2 = if (attr4 != null) attr4 else "N/A"
      Array("Advair Action Group" -> sv1, "Advair Brand Indicator" -> sv2)
    }
    val tenantId = parameters(ETLProcess.tenantIdParam).asInstanceOf[Int]
    val segments = df.sqlContext.read.format("org.apache.spark.sql.cassandra")
      .options(Map("table" -> "d_account_segment", "keyspace" -> parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]))
      .load()
      .where($"tenant_id" === lit(tenantId) and $"active_inactive" === lit("ACTIVE"))

    import df.sqlContext.implicits._
    df.join(segments, df("accnt_id") === segments("accnt_id"))
      .select(df("*"), segments("sgmnt_typ"), segments("sgmnt_value"), segments("accnt_sgmnt_attrb_4"))
      .where($"sgmnt_typ" === lit("Advair"))
      .withColumn("segment_fields", segmentFields($"brand_name", $"sgmnt_value", $"accnt_sgmnt_attrb_4"))
      .withColumn("segment_field", explode($"segment_fields")).drop("segment_fields")
      .withColumn("segment_type", $"segment_field._1")
      .withColumn("segment", $"segment_field._2")
      .drop("accnt_sgmnt_attrb_4")
      .drop("sgmnt_value")
      .drop("sgmnt_typ")
      .drop("segment_field")
  }
}
