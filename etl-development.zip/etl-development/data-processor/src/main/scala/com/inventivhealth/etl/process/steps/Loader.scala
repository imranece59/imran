package com.inventivhealth.etl.process.steps

import java.sql.Timestamp

import com.inventivhealth.etl.config.ConfigComponent
import com.inventivhealth.etl.dao.{CassandraDaoComponent, ETLConfigComponent}
import com.inventivhealth.etl.persist.DataSaverFactory
import org.apache.spark.sql.DataFrame

trait Loader {
  this: ConfigComponent with CassandraDaoComponent with ETLConfigComponent with DataSaverFactory =>

  def load(data: DataFrame): Unit = {
    val dataSaver = getDataSaver(etlConfig.targetName, etlConfig.targetEntityName)
    dataSaver.saveData(data)
    cassandraDao.updateDateLabel(etlConfig.tenantId, etlConfig.sourceName, etlConfig.sourceEntityName,
      etlConfig.targetName, etlConfig.targetEntityName, etlConfig.processId, new Timestamp(System.currentTimeMillis()))
  }

}
