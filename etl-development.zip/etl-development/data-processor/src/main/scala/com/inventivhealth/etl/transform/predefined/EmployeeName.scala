package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction2
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class EmployeeName extends EtlFunction2[String, String, String] {
  override val name: String = "getEmployeeName"

  override def execute(firstName: String, lastName: String): String = s"$firstName $lastName"

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
