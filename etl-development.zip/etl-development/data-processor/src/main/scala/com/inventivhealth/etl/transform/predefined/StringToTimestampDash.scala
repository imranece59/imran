package com.inventivhealth.etl.transform.predefined

import java.sql.Timestamp
import java.text.SimpleDateFormat

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

import scala.util.{Failure, Success, Try}

class StringToTimestampDash extends EtlFunction1[String, Option[Timestamp]] {
  override val name: String = "convertToDateYYYY-MM-DD"

  override def execute(source: String): Option[Timestamp] = {
    val format = new SimpleDateFormat("yyyy-MM-dd")
    Try(new Timestamp(format.parse(source).getTime)) match {
      case Success(t) => Some(t)
      case Failure(_) => None
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
