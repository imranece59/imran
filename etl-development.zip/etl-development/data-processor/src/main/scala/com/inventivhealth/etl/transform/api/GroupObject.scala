package com.inventivhealth.etl.transform.api

import org.apache.spark.broadcast.Broadcast

object GroupObject {
  var broadcasts: Broadcast[Map[String, String]] = _
  var pivotValues: Seq[Int] = _
}
