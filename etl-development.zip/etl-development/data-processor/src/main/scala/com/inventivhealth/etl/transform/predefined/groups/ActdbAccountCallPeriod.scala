package com.inventivhealth.etl.transform.predefined.groups
import org.apache.spark.sql.functions._

import java.sql.Timestamp
import java.sql.Date
import java.text.SimpleDateFormat

import java.time.{ LocalDate, ZoneOffset }
import java.time.format.{ DateTimeFormatter, TextStyle }
import java.util.Locale

import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.DataFrame

class ActdbAccountCallPeriod extends GroupOperation {
  override val name: String = "actdbAccountCallPeriod"

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {

    def getWeekId(source: String, outputFormat: String): String = {

      val inputFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd")
      val outputFormatter = DateTimeFormatter.ofPattern(outputFormat)

      val d = LocalDate.parse(source, inputFormat).
        atStartOfDay(ZoneOffset.UTC)

      val dayShift = 5 - d.getDayOfWeek.getValue

      d.plusDays(dayShift).format(outputFormatter)

    }

    val getWeekIdUdf = udf(getWeekId(_: String, _: String))

    if (operationParams("output").contains("month"))
      df.withColumn("month_id", date_format(col("call_dt_c"), "yyyyMM")).
        withColumn("month_name", date_format(col("call_dt_c"), "MMM yyyy"))
    else
      df.withColumn("week_id", getWeekIdUdf(date_format(col("call_dt_c"), "yyyy-MM-dd"), lit("yyyyMMdd"))).
        withColumn("week_code", getWeekIdUdf(date_format(col("call_dt_c"), "yyyy-MM-dd"), lit("yyyy-MM-dd")))
    //      df.withColumn("week_id", getWeekId(col("call_dt_c"), "yyyy-MM-dd"), lit("yyyyMMdd"))).
    //        withColumn("week_code", getWeekId(date_format(col("call_dt_c"), "yyyy-MM-dd"), lit("yyyy-MM-dd")))

  }
}

  



