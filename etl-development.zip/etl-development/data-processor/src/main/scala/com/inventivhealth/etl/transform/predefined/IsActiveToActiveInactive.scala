package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

import scala.util.{Failure, Success, Try}

class IsActiveToActiveInactive extends EtlFunction1[String, String] {
  override val name: String = "isActiveToActiveInactive"

  override def execute(s: String): String = {
    val value = Try(s.toBoolean) match {
      case Success(v) => v
      case Failure(ex) => false
    }
    if (value) "ACTIVE"
    else "INACTIVE"
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
