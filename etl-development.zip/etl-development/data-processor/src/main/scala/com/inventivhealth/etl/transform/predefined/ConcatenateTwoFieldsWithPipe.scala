package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction2
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class ConcatenateTwoFieldsWithPipe extends EtlFunction2[String, String, String] {
  override val name: String = "concatTwoWithPipe"

  override def execute(first: String, second: String): String = {
    if (first == null || second == null) {
      null
    } else {
      val f = first.trim
      val s = second.trim
      s"$f|$s"
    }
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
