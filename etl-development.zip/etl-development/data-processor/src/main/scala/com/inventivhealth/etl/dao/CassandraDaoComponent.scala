package com.inventivhealth.etl.dao

import com.datastax.driver.core.Cluster
import com.inventivhealth.etl.config.{AppConfig, ConfigComponent}

trait CassandraDaoComponent {
  this: ConfigComponent =>

  lazy val cassandraDao = CassandraDao(appConfig)

}