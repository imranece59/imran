package com.inventivhealth.etl.transform.predefined.groups


import com.inventivhealth.etl.extract.DefaultDataExtractorFactory
import com.inventivhealth.etl.process.ETLProcess
import com.inventivhealth.etl.transform.api.GroupOperation
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class BiGeographyGetLatitudeLongitude extends GroupOperation with DefaultDataExtractorFactory {
  override val name: String = "biGeoGetLatLong"
  val sourceName: String = parameters.getOrElse(ETLProcess.odsKeyspace, "ods").asInstanceOf[String]

  override def execute(df: DataFrame, operationParams: Map[String, String]): DataFrame = {
    val tenantId = parameters(ETLProcess.tenantIdParam)
    val sqlContext = df.sqlContext

    // d_zip
    val dZipDataExtractor = getDataExtractor(sourceName, "d_zip", false)
    var dZipDf = dZipDataExtractor.extractData(sqlContext).where(col("tenant_id").equalTo(tenantId))
    if (dZipDf.schema.fieldNames.contains("active_inactive"))  {
      dZipDf = dZipDf.where(col("active_inactive").equalTo(lit("ACTIVE")))
    }

    // join with d_zip to get latitude and longitude
    df.join(dZipDf, df("zip") === dZipDf("zip"), "left_outer")
      .select(df("*"), dZipDf("latitude"), dZipDf("longitude"))
  }
}