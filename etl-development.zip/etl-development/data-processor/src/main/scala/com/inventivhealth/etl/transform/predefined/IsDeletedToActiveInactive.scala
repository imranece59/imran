package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.transform.api.EtlFunction1
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.UserDefinedFunction

import scala.util.{Failure, Success, Try}

class IsDeletedToActiveInactive extends EtlFunction1[String, String] {
  override val name: String = "isDeletedToActiveInactive"

  override def execute(s: String): String = {
    val value = Try(s.toBoolean) match {
      case Success(v) => v
      case Failure(ex) => false
    }
    if (value) "INACTIVE"
    else "ACTIVE"
  }

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
