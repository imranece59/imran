package com.inventivhealth.etl.transform.predefined

import com.inventivhealth.etl.process.ETLProcess.processIdParam
import com.inventivhealth.etl.transform.api.EtlFunction0
import org.apache.spark.sql.UserDefinedFunction
import org.apache.spark.sql.functions.udf

class DefaultProcessId extends EtlFunction0[String] {
  override val name: String = "defaultProcessId"

  override def execute(): String = parameters(processIdParam).toString

  override def createUdf: UserDefinedFunction = udf { execute _ }
}
