# ETL Data processor

ETL framework for extracting, validating, enriching, transforming and loading data from any source to any target.

## Summary

Supported sources: 
- CSV files on AWS S3
- CSV files on local filesystem
- Cassandra tables 

Contract of ETL process is described by trait [com.inventivhealth.etl.process.ETLProcess](src/main/scala/com/inventivhealth/etl/process/ELTProcess.scala)
Main steps are: 
1. Extracting data from source
2. Split data into parts - data which needs to be inserted, updated and deleted (A/B, B/A) 
3. For each part perform following steps: 
    - Validate data according to rules (null, data type)
    - Perform referential integrity validation 
    - Transform valid data into target format
    - Collect ETL summary and check error threshold (fail if threshold is exceeded)
    - Save invalid data to err_table in Cassandra
    - Save valid data to destination
    - Trigger previous errors reprocessing 
    
## Building 

```
sbt dataProcessor/assembly
```

## Configuration

Command line arguments: 
`--tenant-id` - Tenant id
`--source-name` - Name of source (e.g. S3)
`--source-entity-name` - Source entity name (e.g. Customer_All.txt, Accounts.txt)
`--target-name` - Name of target (e.g. ods keyspace)
`--target-entity-name` - Name of target entity (e.g. d_account table)

Configuration:

| Property | Description | Default value |
|----------|-------------|---------------|
| app.cassandra-host | Cassandra hosts | localhost |
| app.cassandra-port | Cassandra port | 9042 |
| app.default-delimiter | Default CSV file delimiter (if not provided) | , |
| app.s3.access-key | AWS access key | |
| app.s3.secret-key | AWS secret key | |
| app.step-name | Default name of step in overall ETL process | ETL |
| app.group-id | Default group id | -1 |
| app.spark.cache-data | Whether to cache Spark data frames | true |
| app.spark.num-partitions | Default number of spark partitions | 100 |

## Running 

Using DSE Spark: 

```
dse spark-submit 
    --class com.inventivhealth.etl.ETL 
    --total-executor-cores 1
    --executor-cores 1
    --executor-memory 1G 
    build/dataProcessor-assembly-1.0.jar --config-file external.conf --tenant-id 1 --source-name s3 --source-entity-name Customer_All.txt --target-name ods --target-entity-name d_account
```