package com.inventivhealth.etl.test

import com.datastax.driver.core.{Cluster, QueryOptions}
import com.typesafe.scalalogging.slf4j.LazyLogging
import org.cassandraunit.CQLDataLoader
import org.cassandraunit.dataset.cql.ClassPathCQLDataSet
import org.cassandraunit.utils.EmbeddedCassandraServerHelper
import org.scalatest.{BeforeAndAfterAll, BeforeAndAfterEach, Suite}

import scala.collection.JavaConverters._

trait CassandraSpec extends BeforeAndAfterAll with BeforeAndAfterEach with LazyLogging {
  this: Suite =>

  lazy val cluster = getCluster

  val dataSets: Seq[String] = Seq("default_customer.cql")

  override def beforeAll(): Unit = {
    logger.info(s"Starting Embedded Cassandra")
    EmbeddedCassandraServerHelper.startEmbeddedCassandra(30000)

    val session = cluster.connect()
    val loader = new CQLDataLoader(session)

    val keyspaceExists = session.getCluster.getMetadata.getKeyspaces.asScala.exists(_.getName == "ods")
    if (!keyspaceExists) {
      val schemeLoader = new ClassPathCQLDataSet("scheme.cql")
      loader.load(schemeLoader)
    }
    logger.info(s"Keyspace initialized from scheme.cql")
    super.beforeAll()
  }

  override protected def beforeEach(): Unit = {
    logger.info(s"Loading data sets $dataSets")
    val session = cluster.connect()
    val loader = new CQLDataLoader(session)

    dataSets.foreach { dataset =>
      val dataLoader = new ClassPathCQLDataSet(dataset)
      loader.load(dataLoader)
    }
    logger.info(s"Data sets loading finished ($dataSets)")

    super.beforeEach()
  }

  override def afterEach(): Unit = {
    logger.info("Clearing Cassandra tables")
    val cluster = Cluster.builder()
      .addContactPoint(getHost)
      .withPort(getPort)
      .build()
    val tables = cluster.getMetadata.getKeyspace("ods")
      .getTables.asScala
      .map(_.getName)
    val session = cluster.connect("ods")
    tables.foreach(table => session.execute(s"truncate $table"))
    logger.info("Cassandra tables cleared")
    super.afterEach()
  }

  override def afterAll(): Unit = {
    logger.info("Closing Embedded Cassandra")
    if (cluster != null) cluster.close()
    super.afterAll()
  }

  def getHost: String = EmbeddedCassandraServerHelper.getHost

  def getPort: Int = EmbeddedCassandraServerHelper.getNativeTransportPort

  def getCluster: Cluster = Cluster.builder()
    .withQueryOptions(new QueryOptions().setRefreshSchemaIntervalMillis(0))
    .addContactPoint(getHost)
    .withPort(getPort)
    .build()

}
