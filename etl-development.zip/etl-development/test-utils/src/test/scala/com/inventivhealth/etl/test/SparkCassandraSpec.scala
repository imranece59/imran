package com.inventivhealth.etl.test

import org.scalatest.Suite

trait SparkCassandraSpec extends SparkSpec with CassandraSpec {
  this: Suite =>

  override def sparkSettings: Traversable[(String, String)] = List(
    "spark.sql.shuffle.partitions" -> "20",
    "spark.cassandra.connection.host" -> getHost,
    "spark.cassandra.connection.port" -> getPort.toString
  )

}
