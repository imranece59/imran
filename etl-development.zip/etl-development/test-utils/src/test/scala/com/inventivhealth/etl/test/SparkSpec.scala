package com.inventivhealth.etl.test

import java.util.Date

import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkConf, SparkContext}
import org.scalatest.{BeforeAndAfterAll, Suite}

trait SparkSpec extends BeforeAndAfterAll {
  self: Suite =>

  @transient private var _sc: SparkContext = _
  @transient private var _sqlContext: SQLContext = _

  def sc: SparkContext = _sc

  def sqlContext: SQLContext = _sqlContext

  val appID = new Date().toString + math.floor(math.random * 10E4).toLong.toString

  def sparkSettings: Traversable[(String, String)] = Map()

  def conf: SparkConf = new SparkConf().
      setMaster("local[*]").
      setAppName("test").
      set("spark.ui.enabled", "false").
      set("spark.network.timeout", "10000000").
      set("spark.app.id", appID).
      setAll(sparkSettings)

  override def beforeAll() {
    _sc = new SparkContext(conf)
    _sqlContext = new SQLContext(_sc)
    super.beforeAll()
  }

  override def afterAll() {
    try {
      if (_sc != null) {
        _sc.stop()
      }
      System.clearProperty("spark.driver.port")
      _sc = null
    } finally {
      super.afterAll()
    }
  }
}
