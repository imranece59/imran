package com.inventivhealth.etl.util

import org.joda.time.DateTime

object FormattingUtil {
  private val escapableCars = "[\\^\\.\\|]".r
  private val placeholderExpr = "\\{\\{[a-zA-Z0-9_-]*\\}\\}".r

  def escapeCharacters(s: String): String = {
    escapableCars.replaceAllIn(s, "\\\\$0")
  }

  def splitDateIntoMonthYear(date: DateTime): (Int, Int, Int, Int, Int) = {
    (date.getMinuteOfHour, date.getHourOfDay, date.getDayOfMonth, date.getMonthOfYear, date.getYear)
  }

  def replacePlaceholders(init: String, value: String, values: String*): String = {
    def replacePlaceholders(init: String, values: List[String]): String = {
      values match {
        case Nil => init
        case x :: xs =>
          val replaced = placeholderExpr.replaceFirstIn(init, x)
          replacePlaceholders(replaced, xs)
      }
    }
    val vals = value :: List(values: _*)
    replacePlaceholders(init, vals)
  }
}