package com.inventivhealth.etl.dao

import java.util.UUID

import com.inventivhealth.etl.config.model.{ETLError, ETLLog}

class Logger(cassandraDao: CassandraDao) {
  def writeLog(processId: Int,
               tenantId: Int,
               groupId: Int,
               logDateTime: UUID,
               logMin: Int,
               logHour: Int,
               logDay: Int,
               logMonth: Int,
               logYear: Int,
               nSourceRows: Int,
               nTargetRows: Int,
               source: String,
               sEntity: String,
               target: String,
               tEntity: String,
               status: String,
               step: String,
               subCat: String) {

    val log = ETLLog(tenantId, groupId, processId, logMin, logHour, logDay, logMonth, logYear, subCat, logDateTime, nSourceRows, nTargetRows, source, sEntity, status, step, target, tEntity)
    cassandraDao.saveEtlLog(log)
  }

  def writeError(processId: Int,
                 tenantId: Int,
                 groupId: Int,
                 errDateTime: UUID,
                 errMin: Int,
                 errHour: Int,
                 errDay: Int,
                 errMonth: Int,
                 errYear: Int,
                 message: String,
                 row: String,
                 source: String,
                 sEntity: String,
                 target: String,
                 tEntity: String,
                 step: String,
                 subCat: String,
                 status: String,
                 statusDt: Long) {

    val errorLog = ETLError(tenantId, groupId, processId, errMin, errHour, errDay, errMonth, errYear, subCat, errDateTime, message, row, source, sEntity, status, statusDt, step, target, tEntity)
    cassandraDao.saveEtlError(errorLog)
  }
}