package com.inventivhealth.etl.exceptions

class ConfigurationException(message: String) extends Exception(message) {

}