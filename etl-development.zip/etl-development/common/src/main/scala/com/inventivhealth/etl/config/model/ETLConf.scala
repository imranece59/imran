package com.inventivhealth.etl.config.model

import java.util.Date
import java.util.UUID

case class ETLMapping(
  tenantId: Int,
  processId: Int,
  operationType: String,
  targetField: String,
  isSourceId: Boolean,
  isTargetId: Boolean,
  isTech: Boolean,
  sfNullable: Boolean,
  sourceField: Option[String],
  sourceFieldType: Option[String],
  targetFieldType: Option[String],
  transformation: Option[String],
  validation: Option[String],
  activeFlag: Boolean) {

  def this(tenantId: Int,
           processId: Int,
           targetField: String,
           sourceField: Option[String]) =
    this(tenantId , processId, "A", targetField, false, false, false, false, sourceField, None, None, None, None, true)

}

case class ETLConfig(
  tenantId: Int,
  sourceName: String,
  sourceEntityName: String,
  targetName: String,
  targetEntityName: String,
  currentEntityLoc: String,
  delim: Option[String],
  interval: Option[Long],
  lastRun: Option[Date],
  prevEntityLoc: String,
  processId: Int,
  schemaCols: Option[String],
  keyCols: String,
  threshold: Long,
  activeFlag: Boolean,
  ctrlFileName: String,
  landingLocPath: String,
  errorThreshold: Int,
  landingProcessId: Int,
  isIncremental: Boolean,
  hasHeader: Boolean)

case class ETLLog(
  tenantId: Int,
  groupId: Int,
  processId: Int,
  logMin: Int,
  logHour: Int,
  logDay: Int,
  logMonth: Int,
  logYear: Int,
  subcategory: String,
  logTimestamp: UUID,
  numRowsSource: Long,
  numRowsTarget: Long,
  source: String,
  sourceEntity: String,
  status: String,
  step: String,
  target: String,
  targetEntity: String)

case class ETLError(
  tenantId: Int,
  groupId: Int,
  processId: Int,
  errMin: Int,
  errHour: Int,
  errDay: Int,
  errMonth: Int,
  errYear: Int,
  subcategory: String,
  errTimestamp: UUID,
  errMsg: String,
  row: String,
  source: String,
  sourceEntity: String,
  status: String,
  statusDate: Long,
  step: String,
  target: String,
  targetEntity: String)