package com.inventivhealth.etl.dao

import java.sql.Timestamp
import java.util.Date

import com.datastax.driver.core.querybuilder.QueryBuilder
import com.datastax.driver.core.{Cluster, PlainTextAuthProvider, Session}
import com.inventivhealth.etl.config.AppConfig
import com.inventivhealth.etl.config.model._
import com.inventivhealth.etl.exceptions.ConfigurationException
import com.inventivhealth.etl.util.FormattingUtil._
import org.joda.time.DateTime
import java.util.Random

import scala.collection.JavaConversions._
import scala.collection.JavaConverters._

class CassandraDao(cluster: Cluster, systemKeyspace: String = "ods") {

  def getConfig(tenantId: Int, sourceName: String, sourceEntityName: String,
                targetName: String, targetEntityName: String): List[ETLConfig] = {
    val query = QueryBuilder.select()
      .all()
      .from(systemKeyspace, "etl_config")
      .where(QueryBuilder.eq("tenant_id", tenantId))
      .and(QueryBuilder.eq("source_name", sourceName))
      .and(QueryBuilder.eq("source_entity_name", sourceEntityName))
      .and(QueryBuilder.eq("target_name", targetName))
      .and(QueryBuilder.eq("target_entity_name", targetEntityName))

    val config = withSessionDo { session =>
      val rs = session.execute(query)
      val list = rs.all()
      list.map(x => ETLConfig(
        x.getInt("tenant_id"),
        x.getString("source_name"),
        x.getString("source_entity_name"),
        x.getString("target_name"),
        x.getString("target_entity_name"),
        x.getString("current_entity_loc"),
        Option(x.getString("delim")),
        Option(x.getLong("interval")),
        Option(x.getTimestamp("last_run")),
        x.getString("prev_entity_loc"),
        x.getInt("process_id"),
        Option(x.getString("schema_cols")),
        x.getString("key_cols"),
        x.getLong("threshold"),
        x.getBool("active_flag"),
        x.getString("control_file_name"),
        x.getString("landing_loc"),
        x.getInt("error_threshold"),
        x.getInt("landing_proc_id"),
        x.getBool("is_incremental"),
        x.getBool("has_header")))
    }.filter(_.activeFlag)
    if (config.isEmpty)
      throw new ConfigurationException(s"Empty configuration for query $query")
    config.toList
  }

  def getConfig(processId:Int): ETLConfig = {
    val query = QueryBuilder.select().all()
      .from(systemKeyspace, "etl_config").allowFiltering()
      .where(QueryBuilder.eq("process_id", processId))

    val config = withSessionDo { session =>
      val rs = session.execute(query)
      val list = rs.all()
      list.map(x => ETLConfig(
        x.getInt("tenant_id"),
        x.getString("source_name"),
        x.getString("source_entity_name"),
        x.getString("target_name"),
        x.getString("target_entity_name"),
        x.getString("current_entity_loc"),
        Option(x.getString("delim")),
        Option(x.getLong("interval")),
        Option(x.getTimestamp("last_run")),
        x.getString("prev_entity_loc"),
        x.getInt("process_id"),
        Option(x.getString("schema_cols")),
        x.getString("key_cols"),
        x.getLong("threshold"),
        x.getBool("active_flag"),
        x.getString("control_file_name"),
        x.getString("landing_loc"),
        x.getInt("error_threshold"),
        x.getInt("landing_proc_id"),
        x.getBool("is_incremental"),
        x.getBool("has_header")))
    }
    if (config.isEmpty)
      throw new ConfigurationException(s"Empty configuration for query $query")
    if (config.size > 1)
      throw new ConfigurationException(s"More than one config record exists for query $query")
    if (!config.head.activeFlag)
      throw new ConfigurationException(s"Config is inactive for query $query")
    config.head
  }

  def updateDateLabel(tenantId: Int, sourceName: String, sourceEntityName: String,
                      targetName: String, targetEntityName: String, processId: Int, lastRun: Timestamp) = {
    val query = QueryBuilder.insertInto(systemKeyspace, "etl_config")
      .value("tenant_id", tenantId)
      .value("source_name", sourceName)
      .value("source_entity_name", sourceEntityName)
      .value("target_name", targetName)
      .value("target_entity_name", targetEntityName)
      .value("process_id", processId)
      .value("last_run", lastRun)
    withSessionDo { session =>
      session.execute(query)
    }
  }

  def getMapping(tenantId: Int, processId: Int, operationType: String): List[ETLMapping] = {
    val query = QueryBuilder.select()
      .all()
      .from(systemKeyspace, "mapping_config")
      .where(QueryBuilder.eq("tenant_id", tenantId))
      .and(QueryBuilder.eq("process_id", processId))
      .and(QueryBuilder.eq("operation_type", operationType))
    val mappingRes = withSessionDo { session =>
      val rs = session.execute(query)
      val list = rs.all()
      list.map(x => ETLMapping(
        x.getInt("tenant_id"),
        x.getInt("process_id"),
        x.getString("operation_type"),
        x.getString("target_field"),
        x.getBool("is_source_id"),
        x.getBool("is_target_id"),
        x.getBool("is_tech"),
        x.getBool("sf_nullable"),
        Option(x.getString("source_field")),
        Option(x.getString("source_field_type")),
        Option(x.getString("target_field_type")),
        Option(x.getString("transformation")),
        Option(x.getString("validation")),
        x.getBool("active_flag")))
    }
    val mappings = mappingRes.filter(_.activeFlag)
    if (mappings.isEmpty && operationType == "A")
      throw new ConfigurationException(s"No active mappings found for query $query")
    mappings.toList
  }

  def saveEtlLog(stats: ETLLog): Unit = {
    val query = QueryBuilder.insertInto(systemKeyspace, "log_table")
      .value("tenant_id", stats.tenantId)
      .value("group_id", stats.groupId)
      .value("process_id", stats.processId)
      .value("log_min", stats.logMin)
      .value("log_hour", stats.logHour)
      .value("log_day", stats.logDay)
      .value("log_month", stats.logMonth)
      .value("log_year", stats.logYear)
      .value("subcategory", stats.subcategory)
      .value("log_timestamp", stats.logTimestamp)
      .value("num_rows_source", stats.numRowsSource)
      .value("num_rows_target", stats.numRowsTarget)
      .value("source", stats.source)
      .value("source_entity", stats.sourceEntity)
      .value("status", stats.status)
      .value("step", stats.step)
      .value("target", stats.target)
      .value("target_entity", stats.targetEntity)
    withSessionDo { session =>
      session.execute(query)
    }
  }

  def saveEtlError(e: ETLError): Unit = {
    val randGen = new Random();
    val randNumber = randGen.nextInt(1000);
    val query = QueryBuilder.insertInto(systemKeyspace, "err_table")
      .value("tenant_id", e.tenantId)
      .value("group_id", e.groupId)
      .value("process_id", e.processId)
      .value("err_min", e.errMin)
      .value("err_hour", e.errHour)
      .value("err_day", e.errDay)
      .value("err_month", e.errMonth)
      .value("err_year", e.errYear)
      .value("subcategory", e.subcategory)
      .value("err_timestamp", e.errTimestamp)
      .value("err_message", e.errMsg)
      .value("row", e.row)
      .value("source", e.source)
      .value("source_entity", e.sourceEntity)
      .value("status", e.status)
      .value("status_dt", e.statusDate)
      .value("step", e.step)
      .value("target", e.target)
      .value("target_entity", e.targetEntity)
      .value("r_part",randNumber)
    withSessionDo { session =>
      session.execute(query)
    }
  }

  def getLatestLandingRowsCt(processId: Int, tenantId: Int, lastRun: Date, groupId: Int): Long = {
    val (min, hour, day, month, year) = splitDateIntoMonthYear(new DateTime(lastRun))
    val query = QueryBuilder.select()
          .column("num_rows_target")
          .from(systemKeyspace, "log_table")
          .where(QueryBuilder.eq("tenant_id", tenantId))
          .and(QueryBuilder.eq("group_id", groupId))
          .and(QueryBuilder.eq("process_id", processId))
          .and(QueryBuilder.eq("log_month", month))
          .and(QueryBuilder.eq("log_year", year))
          .and(QueryBuilder.eq("status", "SUCCESS"))
          .orderBy(QueryBuilder.desc("subcategory"), QueryBuilder.desc("log_timestamp"))
          .limit(1)
          .allowFiltering()
        val rowsCt = withSessionDo { session =>
          session.execute(query)
     }
      if (rowsCt.isEmpty) -1
      else rowsCt.head.getLong(0)
  }

  def getJoinRefMapping(processId: Int, source: String): List[RefMapping] = {
    val query = QueryBuilder.select()
      .all()
      .from(systemKeyspace, "ref_mapping")
      .where(QueryBuilder.eq("process_id", processId))
      .and(QueryBuilder.eq("source", source))
    withSessionDo { session =>
      val refMappings = session.execute(query).all().asScala
        .map { r =>
          RefMapping(r.getInt("process_id"), r.getString("source"), r.getString("source_loc"), r.getString("source_field"),
            Option(r.getInt("join_order")).getOrElse(0), r.getString("lookup"), r.getString("lookup_loc"), r.getString("lookup_field"),
            r.getString("return_fields"), r.getBool("isbroadcast"), r.getBool("skip_ri"), r.getBool("active_records_only"), Option(r.getString("condition")))
        }
      refMappings.filter(rm => !rm.broadcast).toList
    }
  }

  def getBroadcastRefMapping(processId: Int, source: String): List[RefMapping] = {
    val query = QueryBuilder.select()
      .all()
      .from(systemKeyspace, "ref_mapping")
      .where(QueryBuilder.eq("process_id", processId))
      .and(QueryBuilder.eq("source", source))
    withSessionDo { session =>
      val refMappings = session.execute(query).all().asScala
        .map { r =>
          RefMapping(r.getInt("process_id"), r.getString("source"), r.getString("source_loc"), r.getString("source_field"),
            Option(r.getInt("join_order")).getOrElse(0), r.getString("lookup"), r.getString("lookup_loc"), r.getString("lookup_field"), r.getString("return_fields"),
            r.getBool("isbroadcast"), r.getBool("skip_ri"), r.getBool("active_records_only"), Option(r.getString("condition")))
        }
      refMappings.filter(_.broadcast).toList
    }
  }

  def getGroupOperations(tenantId: Int, processId: Int, operationTarget: String): List[GroupOp] = {
    val query = QueryBuilder.select()
      .all()
      .from(systemKeyspace, "group_operation")
      .where(QueryBuilder.eq("tenant_id", tenantId))
      .and(QueryBuilder.eq("process_id", processId))
      .and(QueryBuilder.eq("operation_target", operationTarget))
    withSessionDo { session =>
      val groupOps = session.execute(query).all().asScala
        .map { r =>
          val params = r.getMap("parameters", classOf[String], classOf[String]).asScala.toMap
          GroupOp(r.getInt("tenant_id"), r.getInt("process_id"), r.getString("operation_target"),
            r.getString("name"), Option(r.getInt("apply_order")).getOrElse(0), params)
        }
      groupOps.toList
    }
  }

  def openSession(): Session = {
    cluster.connect()
  }

  def withSessionDo[T](code: Session => T): T = {
    closeResourceAfterUse(openSession()) { session =>
      code(session)
    }
  }

  def closeResourceAfterUse[T, C <: { def close() }](closeable: C)(code: C => T): T =
    try code(closeable) finally {
      closeable.close()
    }

  def destroy(): Unit = cluster.close()
}

object CassandraDao {

  def apply(appConfig: AppConfig): CassandraDao = {
    val contactPoints = appConfig.cassandraHost.split(",").map(_.trim).filter(_.nonEmpty)

    val cluster = Cluster.builder()
      .addContactPoints(contactPoints:_*)
      .withPort(appConfig.cassandraPort)
      .withCredentials(appConfig.cassandraUsername, appConfig.cassandraPassword)
      .build
    new CassandraDao(cluster, appConfig.odsKeyspace)

  }

}