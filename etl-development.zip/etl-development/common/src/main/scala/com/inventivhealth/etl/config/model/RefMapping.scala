package com.inventivhealth.etl.config.model

case class RefMapping(processId: Int,
                      source: String,
                      sourceLocation: String,
                      sourceField: String,
                      order: Int,
                      lookup: String,
                      lookupLocation: String,
                      lookupField: String,
                      returnFields: String,
                      broadcast: Boolean,
                      skipRi: Boolean,
                      activeRecordsOnly: Boolean,
                      condition: Option[String])