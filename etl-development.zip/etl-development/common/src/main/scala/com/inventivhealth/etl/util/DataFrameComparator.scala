package com.inventivhealth.etl.util

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

object DataFrameComparator {
  implicit class ComarableDataFrame(df: DataFrame) {

    def diffAdds(otherDf: DataFrame, keyColumns: Seq[String]): DataFrame = {
      val joinCond = keyColumns.map(c => col(s"a.$c") === col(s"b.$c")).reduceLeft(_ && _)
      val filterCond = keyColumns.map(c => isnull(col(s"b.$c"))).reduceLeft(_ && _)
      df.as('a)
        .join(otherDf.as('b), joinCond, "leftouter")
        .where(filterCond)
        .select("a.*")
    }

    def diffDels(otherDf: DataFrame, keyColumns: Seq[String]): DataFrame = {
      otherDf.diffAdds(df, keyColumns)
    }

    def diffUpds(otherDf: DataFrame, keyColumns: Seq[String]): DataFrame = {
      val condition = keyColumns.map(c => col(s"a.$c") === col(s"b.$c")).reduceLeft(_ && _)
      val filterCond = df.schema.map(_.name).map(c => col(s"a.$c") !== col(s"b.$c")).reduceLeft(_ || _)
      df.as('a)
        .join(otherDf.as('b), condition, "inner")
        .where(filterCond)
        .select("a.*")
    }
    
    
    def merge(otherDf: DataFrame, keyColumns: Seq[String]): DataFrame = {
      val aColNames = df.schema.map(f => f.name)
      val bColNames = otherDf.schema.map(f => f.name).diff(aColNames)
      val bCols = bColNames.map(c => col(s"b.$c"))
      val aCols = aColNames.map(c => col(s"a.$c"))
      val cols = bCols ++ aCols
      val condition = keyColumns.map(c => col(s"a.$c") === col(s"b.$c")).reduceLeft(_ && _)
      df
        .as('a)
        .join(otherDf.as('b), condition, "inner")
        .select(cols: _*)
    }
    
    def filterByKeys(otherDf: DataFrame, keyColumns: Seq[String]): DataFrame = {
      val cols = keyColumns.map(col(_))
      val condition = keyColumns.map(c => col(s"a.$c") === col(s"b.$c")).reduceLeft(_ && _)
      df.select(cols: _*)
        .as('a)
        .join(otherDf.as('b), condition, "inner")
        .select("b.*")
    }
  }
}