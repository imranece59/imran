package com.inventivhealth.etl.config.model

case class GroupOp(tenantId: Int,
                   processId: Int,
                   operationTarget: String,
                   name: String,
                   order: Int,
                   parameters: Map[String, String])
