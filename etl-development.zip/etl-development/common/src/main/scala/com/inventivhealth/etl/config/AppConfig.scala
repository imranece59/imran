package com.inventivhealth.etl.config

import com.typesafe.config.Config

class AppConfig(config: Config) {

  private val app = config.getConfig("app")

  val cassandraHost = app.getString("cassandra-host")

  val cassandraUsername = app.getString("cassandra-username")

  val cassandraPassword = app.getString("cassandra-password")

  val cassandraPort = app.getInt("cassandra-port")

  val s3AccessKey = app.getString("s3.access-key")

  val s3SecretKey = app.getString("s3.secret-key")

  val defaultDelimiter = app.getString("default-delimiter")
  
  val dataProcessorStepName = app.getString("data-processor.step-name")

  val odsKeyspace = app.getString("data-processor.system.ods-keyspace")

  val biKeyspace = app.getString("data-processor.system.bi-keyspace")

  val cacheSource = app.getBoolean("data-processor.spark.cache.source")

  val cachePreviousSource = app.getBoolean("data-processor.spark.cache.previous-source")

  val cacheLookups = app.getBoolean("data-processor.spark.cache.lookups")

  val cacheTarget = app.getBoolean("data-processor.spark.cache.target")

  val numPartitions = app.getInt("data-processor.spark.num-partitions")
  
  val groupId = app.getInt("group-id")

  val collectSummary = app.getBoolean("data-processor.collect-summary")

  val collectErrors = app.getBoolean("data-processor.collect-errors")

  val doErrorReprocessing = app.getBoolean("data-processor.do-error-reprocessing")

  val parserLib = app.getString("data-processor.spark.parser-lib")
}
