package com.inventivhealth.etl.exceptions

class ETLProcessException(message: String) extends Exception(message)
