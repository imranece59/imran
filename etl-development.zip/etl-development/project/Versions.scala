object Versions {
  val spark = "1.6.1"
  val cassandra = "3.0.0"
  val paradiseVersion = "2.1.0"
}