# ETL framework core

Project contains: 
- [file-validator](file-validator) project - executed on file validation level
- [data-processor](data-processor/README.md) project - extracts data, performs row validation, transformation and saves data
