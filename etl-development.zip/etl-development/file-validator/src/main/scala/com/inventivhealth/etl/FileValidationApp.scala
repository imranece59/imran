package com.inventivhealth.etl
import java.io.File

import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.services.s3.AmazonS3Client
import com.amazonaws.services.s3.model.GetObjectRequest
import com.datastax.driver.core.Cluster
import com.datastax.driver.core.utils.UUIDs
import com.inventivhealth.etl.config.AppConfig
import com.inventivhealth.etl.config.model.ETLConfig
import com.inventivhealth.etl.dao.{CassandraDao, Logger}
import com.inventivhealth.etl.util.FormattingUtil._
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkConf, SparkContext}
import org.joda.time.DateTime

case class Args(configFile: Option[String] = None,
                tenantId: Int = 1,
                groupId: Option[Int] = None,
                sourceName: String = "s3",
                sourceEntityName: String = "Customer_Header.txt",
                targetName: String = "ods",
                targetEntityName: String = "d_account")

object FileValidationApp {

  def main(args: Array[String]): Unit = {
    val parser = new scopt.OptionParser[Args]("etl") {
      head("etl", "0.1")
      opt[String]("config-file").action((x, a) => a.copy(configFile = Some(x))) text "Path to external configuration file"
      opt[Int]("tenant-id").required().action((x, a) => a.copy(tenantId = x)) text "Tenant Id"
      opt[Int]("group-id").action((x, a) => a.copy(groupId = Some(x))) text "Group Id"
      opt[String]("source-name").required().action((x, a) => a.copy(sourceName = x)) text "Source name"
      opt[String]("source-entity-name").required().action((x, a) => a.copy(sourceEntityName = x)) text "Source entity name"
      opt[String]("target-name").required().action((x, a) => a.copy(targetName = x)) text "Target name"
      opt[String]("target-entity-name").required().action((x, a) => a.copy(targetEntityName = x)) text "Target entity name"
      help("Usage text")
    }
    parser.parse(args, Args()) match {
      case Some(cmdArgs) =>
        val defaults = ConfigFactory.parseResources("reference.conf")
        val config = if (cmdArgs.configFile.isDefined) {
          ConfigFactory
            .parseFile(new File(cmdArgs.configFile.get))
            .withFallback(defaults)
            .resolve()
        } else defaults.resolve()
        
        val appConf = new AppConfig(config)        
        val textMessages = ConfigFactory.parseResources("text.conf").resolve()
        
        // Cassandra Connection
        val cluster = Cluster.builder().addContactPoints(appConf.cassandraHost).build
        val cassandraDao = new CassandraDao(cluster, appConf.odsKeyspace)
        val logWriter = new Logger(cassandraDao)
        val etlConf = cassandraDao
          .getConfig(cmdArgs.tenantId, cmdArgs.sourceName, cmdArgs.sourceEntityName, cmdArgs.targetName, cmdArgs.targetEntityName)
          .head
        
        // Setting up spark sql context
        val scConf = new SparkConf(true)
          .set("spark.cassandra.connection.host", appConf.cassandraHost)
          .setAppName(getClass.getSimpleName)
        val sc = new SparkContext(scConf)
        val sqlContext = new SQLContext(sc)

        // Passing AWS credentials to spark context
        val hadoopConf = sc.hadoopConfiguration
        hadoopConf.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        hadoopConf.set("fs.s3a.access.key", appConf.s3AccessKey)
        hadoopConf.set("fs.s3a.secret.key", appConf.s3SecretKey)

        // Creating RDD from s3 landing       
        val dataFilePath = s"s3a://${etlConf.landingLocPath}/${etlConf.sourceEntityName}"
        val dataFileRdd = sqlContext.sparkContext.textFile(dataFilePath)
        
        /* ----------------------Validations---------------------------*/
        
        /*Check if the file is new*/
        isFileNew(sc, etlConf, appConf, logWriter,textMessages)
        
        /*Check if the source file has no rows*/        
        validateForZeroRows(sc, dataFileRdd, etlConf, appConf, logWriter,textMessages) 
        
         /*Check if source file has minimum number of required rows to perform ETL*/
        validateForThresholdValue(sc, dataFileRdd, etlConf, appConf, logWriter,textMessages)
        
        /*Check control file and log table for row count validation*/
        validateWithControlFile(sc, sqlContext, dataFileRdd, etlConf, appConf, logWriter, cassandraDao,textMessages)
        
        /*Check source file for the schema*/
        validateNumberOfCols(sc, dataFileRdd, etlConf, appConf, logWriter,textMessages)
        
        stopProcessing(sc, 0)
      case None =>
    }
  }

  def isFileNew(sc: SparkContext, etlConf: ETLConfig, appConf: AppConfig, logWriter: Logger, textMsgs: Config) {

   etlConf.lastRun match {

      case Some(previousRunDate) =>
        val awsAccessKey = appConf.s3AccessKey
        val awsSecretKey = appConf.s3SecretKey
        val awsCredentials = new BasicAWSCredentials(awsAccessKey, awsSecretKey)
        val s3 = new AmazonS3Client(awsCredentials)
        val s3BucketName = etlConf.landingLocPath.substring(0,etlConf.landingLocPath.indexOf("/"))
        val sourceEntity = etlConf.sourceEntityName
        val completeLandingPath = etlConf.landingLocPath + "/" + sourceEntity
        val pathFromBucketLoc = completeLandingPath.substring(completeLandingPath.indexOf("/") + 1, completeLandingPath.length())
        val processedFolderLoc = etlConf.prevEntityLoc        
        val processedFolderDtReplace = replacePlaceholders(processedFolderLoc, previousRunDate.getTime.toString());
        val processedFolder = processedFolderDtReplace + "/" + sourceEntity
        val processedFolderPathFromBucket = processedFolder.substring(processedFolder.indexOf("/") + 1, processedFolder.length())
        val s3LandingObject = s3.getObject(new GetObjectRequest(s3BucketName, pathFromBucketLoc))
        val s3LandingLastModified = s3LandingObject.getObjectMetadata.getLastModified
        val s3ProcessedObject = s3.getObject(new GetObjectRequest(s3BucketName, processedFolderPathFromBucket))
        val s3ProcessedLastModified = s3ProcessedObject.getObjectMetadata.getLastModified
        
        // Checking if the file in landing location is older than the file in processed folder
        
        if (s3LandingLastModified.before(s3ProcessedLastModified)) {                
          val msg = textMsgs.getString("app.errors.IS_NOT_NEW_FILE")
          writeLog(etlConf,appConf,textMsgs,logWriter,msg)
          writeErrorLog(etlConf,appConf,textMsgs,logWriter,msg,sc)          
        } else {          
          val msg = textMsgs.getString("app.logs.IS_NEW_FILE")
          writeLog(etlConf,appConf,textMsgs,logWriter,msg)
        }
      case None =>        
        val msg = textMsgs.getString("app.logs.INIT_LOAD")
        writeLog(etlConf,appConf,textMsgs,logWriter,msg)
    }
  }

  def validateForZeroRows(sc: SparkContext, dataFileRdd: RDD[String], etlConf: ETLConfig, appConf: AppConfig, logWriter: Logger, textMsgs: Config) {

    if (dataFileRdd.isEmpty()) {      
      val msg = textMsgs.getString("app.errors.NO_ROWS")
      writeLog(etlConf,appConf,textMsgs,logWriter,msg)
      writeErrorLog(etlConf,appConf,textMsgs,logWriter,msg,sc)
    }
  }

  def validateWithControlFile(sc: SparkContext, sqlContext: SQLContext, dataFileRdd: RDD[String], etlConf: ETLConfig, appConf: AppConfig, logWriter: Logger, cassandraDao: CassandraDao, textMsgs: Config) {

    val groupId = appConf.groupId
    val landingProcessPid = etlConf.landingProcessId
    val landingEtlConf = cassandraDao.getConfig(landingProcessPid)    
    val rowsFromLanding = landingEtlConf.lastRun match {
      case Some(prevRunDate) =>
        cassandraDao.getLatestLandingRowsCt(landingProcessPid, landingEtlConf.tenantId, prevRunDate, groupId)
      case None=> 0
    }    
    if(rowsFromLanding == -1){
          val msg = textMsgs.getString("app.errors.NO_LASTRUN_REC_LOG_TBL")
          writeLog(etlConf,appConf,textMsgs,logWriter,msg)
          writeErrorLog(etlConf,appConf,textMsgs,logWriter,msg,sc) 
    }
    // Row count validation with control file    
    if (etlConf.ctrlFileName != null) {
      val ctrlFilePath = s"s3a://${etlConf.landingLocPath}/${etlConf.ctrlFileName}"
      val ctrlFileRdd = sqlContext.sparkContext.textFile(ctrlFilePath)
      val sourceNameInCtrlFile = etlConf.sourceEntityName.split("\\.")
      val ctrlFileRddFilter = ctrlFileRdd.filter(line => line.contains(sourceNameInCtrlFile(0)))
      val escapedDelim = etlConf.delim match{
        case Some(delimiter)=>
          escapeCharacters(delimiter)
        case None =>
          val msg = textMsgs.getString("app.errors.MISSING_DELIM")
          writeLog(etlConf,appConf,textMsgs,logWriter,msg)
          writeErrorLog(etlConf,appConf,textMsgs,logWriter,msg,sc) 
      }      
      val rowFromCtrlFile = ctrlFileRddFilter.take(1).apply(0).split(escapedDelim.toString())
      val rowCountFromCtrlFile = rowFromCtrlFile(2).toLong
      if (rowFromCtrlFile(2).toLong != rowsFromLanding) {        
        val msg = textMsgs.getString("app.errors.ROW_CT_MISMATCH_CTRL_FILE_LOG")
        writeLog(etlConf,appConf,textMsgs,logWriter,msg)
        writeErrorLog(etlConf,appConf,textMsgs,logWriter,msg,sc)
      }

      if (dataFileRdd.count() != rowFromCtrlFile(2).toLong) {        
        val msg = textMsgs.getString("app.errors.ROW_CT_MISMATCH_CTRL_FILE_S3LANDING")
        writeLog(etlConf,appConf,textMsgs,logWriter,msg)
        writeErrorLog(etlConf,appConf,textMsgs,logWriter,msg,sc)
      }
    } else {

      if (dataFileRdd.count() != rowsFromLanding) {        
        val msg = textMsgs.getString("app.errors.ROW_CT_MISMATCH_S3LANDING_LOG")
        writeLog(etlConf,appConf,textMsgs,logWriter,msg)
        writeErrorLog(etlConf,appConf,textMsgs,logWriter,msg,sc)
      }
    }
  }
  
  def validateForThresholdValue(sc: SparkContext, dataFileRdd: RDD[String], etlConf: ETLConfig, appConf: AppConfig, logWriter: Logger, textMsgs: Config){
    
    if (dataFileRdd.count() < etlConf.threshold) {      
      val msg = textMsgs.getString("app.errors.LT_THRESHOLD")
      writeLog(etlConf,appConf,textMsgs,logWriter,msg)
      writeErrorLog(etlConf,appConf,textMsgs,logWriter,msg,sc)
    } else {      
      val msg = textMsgs.getString("app.logs.GTE_THRESHOLD")
      writeLog(etlConf,appConf,textMsgs,logWriter,msg)
    }

  }

  def validateNumberOfCols(sc: SparkContext, dataFileRdd: RDD[String], etlConf: ETLConfig, appConf: AppConfig, logWriter: Logger, textMsgs: Config) {

     val escapedDelim = etlConf.delim match{
        case Some(delimiter)=>
          escapeCharacters(delimiter)
        case None =>
          val msg = textMsgs.getString("app.errors.MISSING_DELIM_CTRL_FILE")
          writeLog(etlConf,appConf,textMsgs,logWriter,msg)
          writeErrorLog(etlConf,appConf,textMsgs,logWriter,msg,sc) 
      }    
    val numDataCols = dataFileRdd.take(1).apply(0).split(escapedDelim.toString()).length
    val numSchemaCols = etlConf.schemaCols.get.split(escapedDelim.toString()).length
    if (numDataCols != numSchemaCols) {      
      val msg = textMsgs.getString("app.errors.COL_CT_MISMATCH")
      writeLog(etlConf,appConf,textMsgs,logWriter,msg)
      writeErrorLog(etlConf,appConf,textMsgs,logWriter,msg,sc)
    } else {      
      val msg = textMsgs.getString("app.logs.COL_CT_MACTH")
      writeLog(etlConf,appConf,textMsgs,logWriter,msg)
    }
  }
  
  def writeLog(etlConf: ETLConfig, appConf: AppConfig, textMsgs:Config, logWriter: Logger,msg:String){
    val groupId = appConf.groupId
    val step = textMsgs.getString("app.steps.FV_STEP")
    val subcategory = textMsgs.getString("app.sub-categories.FV_SUB_CAT")
    val time = DateTime.now()
    val (min, hour, day, month, year) = splitDateIntoMonthYear(time)
    logWriter.writeLog(
        etlConf.processId, etlConf.tenantId, groupId, UUIDs.timeBased(), min, hour, day, month, year, 0, 0, etlConf.sourceName,
        etlConf.sourceEntityName, etlConf.targetName, etlConf.targetEntityName, msg, step, subcategory)
  }
  
  def writeErrorLog(etlConf: ETLConfig, appConf: AppConfig, textMsgs:Config,logWriter: Logger,msg:String, sc: SparkContext){
    val groupId = appConf.groupId
    val step = textMsgs.getString("app.steps.FV_STEP")
    val errStatus = textMsgs.getString("app.other-texts.NA") 
    val subcategory = textMsgs.getString("app.sub-categories.FV_SUB_CAT")
    val time = DateTime.now()
    val (min, hour, day, month, year) = splitDateIntoMonthYear(time)
    logWriter.writeError(
        etlConf.processId, etlConf.tenantId, groupId, UUIDs.timeBased(), min, hour, day, month, year, msg, "", etlConf.sourceName,
        etlConf.sourceEntityName, etlConf.targetName, etlConf.targetEntityName, step, subcategory, errStatus, System.currentTimeMillis())
      stopProcessing(sc, 1)    
  }

  def stopProcessing(sc: SparkContext, i: Int) {
    sc.stop()
    System.exit(i)
  }
}
