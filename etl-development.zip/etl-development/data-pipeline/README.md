#### Scheduled data pipelines to load sources with different frequency to s3 and start processing pipeline:

- [Landing daily data pipeline](landing/landing-daily-data-pipeline.json)
- [Landing weekly data pipeline](landing/landing-weekly-data-pipeline.json)
- [Landing monthly data pipeline](landing/landing-monthly-data-pipeline.json)

#### On demand data pipelines to process sources with different frequency:
- [Daily data pipeline](daily/daily-data-pipeline.json)
- [Weekly data pipeline](weekly/weekly-data-pipeline.json)
- [Monthly data pipeline](monthly/monthly-data-pipeline.json)

#### Additional pipelines to be scheduled 
- [Start daily data pipeline](start/start-daily-data-pipeline.json)
- [Start weekly data pipeline](start/start-weekly-data-pipeline.json)
- [Start monthly data pipeline](start/start-monthly-data-pipeline.json)