#!/bin/bash

JAR_BUCKET=$1
CONFIG_BUCKET=$2

echo "JAR_BUCKET = $JAR_BUCKET"
echo "CONFIG_BUCKET = $CONFIG_BUCKET"

cd /home/ec2-user

echo "aws s3 cp $JAR_BUCKET/dataProcessor-assembly-0.0.1-RC1.jar dataProcessor-assembly-0.0.1-RC1.jar"
aws s3 cp $JAR_BUCKET/dataProcessor-assembly-0.0.1-RC1.jar dataProcessor-assembly-0.0.1-RC1.jar

echo "aws s3 cp $CONFIG_BUCKET configs --recursive"
aws s3 cp $CONFIG_BUCKET configs --recursive