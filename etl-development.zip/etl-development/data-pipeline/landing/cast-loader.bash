#!/bin/bash

if [[ $2 -eq "default" ]]
then
    TIMESTAMP=$(($(date --date="$1" "+%s%N")/1000000))
else
    TIMESTAMP=$2
fi

CAST_PATH=$3
HOST=23.253.27.199
USER=
PASSWORD=
CAST_FILE_PATH=SFTP/INVENTIV_CDWBI/CAST/Inbound
DATE=$(date +%Y%m%d)

echo "USER = $USER"
echo "HOST= $HOST"
echo "TIMESTAMP = $TIMESTAMP"
echo "CAST_PATH = $CAST_PATH"
echo "CAST_FILE_PATH = $CAST_FILE_PATH"
echo "DATE = $DATE"

cd /home/ec2-user

# NEED SSHPASS TO BE INSTALLED
export SSHPASS=$PASSWORD

sshpass -e sftp -o StrictHostKeyChecking=no $USER@$HOST > tmp_cast << EOF

cd $CAST_FILE_PATH
ls -ltr
quit
EOF

if [ $? -ne 0 ]
then
    echo "Error connecting to the Host server, exiting..."
    exit 1
fi

FNAME_JOB=`grep "Job_$DATE" tmp_cast | awk {'print $9'} | head -1`
echo "FNAME_JOB = $FNAME_JOB"

FNAME_JOB_HISTORY=`grep "Job_History_$DATE" tmp_cast | awk {'print $9'} | head -1`
echo "FNAME_JOB_HISTORY = $FNAME_JOB_HISTORY"

sshpass -e sftp -o StrictHostKeyChecking=no $USER@$HOST > tmp_cast << EOF

cd $CAST_FILE_PATH
get ${FNAME_JOB}
get ${FNAME_JOB_HISTORY}
quit
EOF

if [ $? -ne 0 ]
then
    echo "Error connecting to the Host server, exiting..."
    exit 1
fi

FNAMECUT_JOB=Job.txt
FNAMECUT_JOB_HISTORY=Job_History.txt

echo "aws s3 rm --dryrun $CAST_PATH/$TIMESTAMP/CAST/$FNAMECUT_JOB"
aws s3 rm --dryrun $CAST_PATH/$TIMESTAMP/CAST/$FNAMECUT_JOB

if [[ $? -eq 0 ]]
then
    echo "File $FNAMECUT_JOB already exists in $CAST_PATH/$TIMESTAMP/CAST/, skipping..."
else
    echo "aws s3 cp $FNAME_JOB $CAST_PATH/$TIMESTAMP/CAST/$FNAMECUT_JOB"
    aws s3 cp $FNAME_JOB $CAST_PATH/$TIMESTAMP/CAST/$FNAMECUT_JOB
fi

echo "aws s3 rm --dryrun $CAST_PATH/$TIMESTAMP/CAST/$FNAMECUT_JOB_HISTORY"
aws s3 rm --dryrun $CAST_PATH/$TIMESTAMP/CAST/$FNAMECUT_JOB_HISTORY

if [[ $? -eq 0 ]]
then
    echo "File $FNAMECUT_JOB_HISTORY already exists in $CAST_PATH/$TIMESTAMP/CAST/, skipping..."
else
    echo "aws s3 cp $FNAME_JOB_HISTORY $CAST_PATH/$TIMESTAMP/CAST/$FNAMECUT_JOB_HISTORY"
    aws s3 cp $FNAME_JOB_HISTORY $CAST_PATH/$TIMESTAMP/CAST/$FNAMECUT_JOB_HISTORY
fi

