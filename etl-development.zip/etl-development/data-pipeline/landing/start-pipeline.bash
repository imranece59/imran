#!/bin/bash

DATE=$(date +%Y%m%d)
PIPELINE_NAME=$1
PIPELINE_PATH_JSON=$2
SOURCE_TIMESTAMPS_BUCKET=$3
TIMESTAMPS_FILE=$4

echo "DATE = $DATE"
echo "PIPELINE_NAME = $PIPELINE_NAME"
echo "PIPELINE_PATH_JSON = $PIPELINE_PATH_JSON"
echo "SOURCE_TIMESTAMPS_BUCKET = $SOURCE_TIMESTAMPS_BUCKET"
echo "TIMESTAMPS_FILE = $TIMESTAMPS_FILE"

SOURCE_TIMESTAMPS_FILE=$SOURCE_TIMESTAMPS_BUCKET/$TIMESTAMPS_FILE
echo "SOURCE_TIMESTAMPS_FILE = $SOURCE_TIMESTAMPS_FILE"

cd /home/ec2-user

echo "aws s3 cp $SOURCE_TIMESTAMPS_FILE $TIMESTAMPS_FILE"
aws s3 cp $SOURCE_TIMESTAMPS_FILE $TIMESTAMPS_FILE

TIMESTAMPS_TO_PROCESS=`cat $TIMESTAMPS_FILE`
echo "TIMESTAMPS_TO_PROCESS = $TIMESTAMPS_TO_PROCESS"

if [[ -z $TIMESTAMPS_TO_PROCESS ]]
then
    echo "Timestamp file is empty, exiting..."
    exit 0
fi

TIMESTAMP_TO_PROCESS=`cat $TIMESTAMPS_FILE | cut -d , -f 1`
echo "TIMESTAMP_TO_PROCESS = $TIMESTAMP_TO_PROCESS"

echo "aws datapipeline create-pipeline --name $PIPELINE_NAME-$DATE-$TIMESTAMP_TO_PROCESS --region us-east-1 --unique-id $TIMESTAMP_TO_PROCESS"
PIPELINE_ID=`aws datapipeline create-pipeline --name $PIPELINE_NAME-$DATE-$TIMESTAMP_TO_PROCESS --region us-east-1 --unique-id $TIMESTAMP_TO_PROCESS`
PIPELINE_ID=`echo $PIPELINE_ID | sed 's/.*: "//' | sed 's/".*//' | sed 's/{.*//' | sed 's/.*}//' | sed '/^$/d'`
echo "PIPELINE_ID = $PIPELINE_ID"

echo "aws s3 cp $PIPELINE_PATH_JSON pipeline.json"
aws s3 cp $PIPELINE_PATH_JSON pipeline.json

echo "aws datapipeline put-pipeline-definition --pipeline-id $PIPELINE_ID --region us-east-1  --pipeline-definition file://pipeline.json --parameter-values myTimestampFolder=$TIMESTAMP_TO_PROCESS"
aws datapipeline put-pipeline-definition --pipeline-id $PIPELINE_ID --region us-east-1  --pipeline-definition file://pipeline.json --parameter-values myTimestampFolder=$TIMESTAMP_TO_PROCESS

echo "aws datapipeline activate-pipeline --pipeline-id $PIPELINE_ID --region us-east-1"
aws datapipeline activate-pipeline --pipeline-id $PIPELINE_ID --region us-east-1


