#!/bin/bash

if [[ $2 -eq "default" ]]
then
    TIMESTAMP=$(($(date --date="$1" "+%s%N")/1000000))
else
    TIMESTAMP=$2
fi

CONCUR_PATH=$3
HOST=23.253.27.174
USER=
PASSWORD=
INVENTIV_FILE_PATH=INVENTIV_CDWBI/Concur/Test/Inbound

echo "USER = $USER"
echo "HOST= $HOST"
echo "TIMESTAMP = $TIMESTAMP"
echo "CONCUR_PATH = $CONCUR_PATH"
echo "INVENTIV_FILE_PATH = $INVENTIV_FILE_PATH"

cd /home/ec2-user

# NEED SSHPASS TO BE INSTALLED
export SSHPASS=$PASSWORD

echo "sshpass -e sftp -o StrictHostKeyChecking=no $USER@$HOST > tmp_concur << EOF"
sshpass -e sftp -o StrictHostKeyChecking=no $USER@$HOST > tmp_concur << EOF

cd $INVENTIV_FILE_PATH
ls -ltr
quit
EOF

if [ $? -ne 0 ]
then
    echo "Error connecting to the Host server, exiting..."
    exit 1
fi

FNAME=`grep "inventiv_concur_detail" tmp_concur | awk {'print $9'} | tail -1`
echo "FNAME = $FNAME"

sshpass -e sftp -o StrictHostKeyChecking=no $USER@$HOST > tmp_concur << EOF

cd $INVENTIV_FILE_PATH
get ${FNAME}
quit
EOF

if [ $? -ne 0 ]
then
    echo "Error connecting to the Host server, exiting..."
    exit 1
fi

FNAMECUT=inventiv_concur_detail.txt

echo "aws s3 rm --dryrun $CONCUR_PATH/$TIMESTAMP/Concur/$FNAMECUT"
aws s3 rm --dryrun $CONCUR_PATH/$TIMESTAMP/Concur/$FNAMECUT

if [[ $? -eq 0 ]]
then
    echo "File $FNAMECUT already exists in $CONCUR_PATH/$TIMESTAMP/Concur/, skipping..."
else
    echo "aws s3 cp $FNAME $CONCUR_PATH/$TIMESTAMP/Concur/$FNAMECUT"
    aws s3 cp $FNAME $CONCUR_PATH/$TIMESTAMP/Concur/$FNAMECUT
fi

