#!/bin/bash

if [[ $2 -eq "default" ]]
then
    TIMESTAMP=$(($(date --date="$1" "+%s%N")/1000000))
else
    TIMESTAMP=$2
fi

JOB_MODE=$3
JOB_PATH=$4
DAILY_LANDING=$5
DAILY_SOURCES=$6
DATE=$(date +%Y%m%d)

echo "JOB_MODE = $JOB_MODE"
echo "JOB_PATH = $JOB_PATH"
echo "DATE = $DATE"
echo "TIMESTAMP = $TIMESTAMP"
echo "DAILY_LANDING = $DAILY_LANDING"
echo "DAILY_SOURCES = $DAILY_SOURCES"

sudo su - imran
cd /home/imran/Source_Jars

# THIS SHOULD BE RUN ON VEEVA DEV OR PROD MACHINE
# nohup java -jar TaskRunner-1.0.jar --accessId=XXX--secretKey=XXX  --workerGroup=wg-veeva-job/wg-prod-veeva-job --logUri=s3://gsk-taskrunner/logs &> logs &

echo "dse spark-submit  --class com.inventiv.veeva.CreateVeevaParam    --conf spark.cores.max=2 --conf spark.executor.memory=2g  --conf spark.driver.memory=2g \
--num-executors 20 --conf spark.driver.extraClassPath=/opt/cdata/lib/cdata.jdbc.salesforce.jar --conf spark.executor.extraClassPath=/opt/cdata/lib/cdata.jdbc.salesforce.jar  \
--jars sf-loader-assembly-1.0.jar    sf-loader_2.10-1.0.jar --JobMode=$JOB_MODE"

dse spark-submit  --class com.inventiv.veeva.CreateVeevaParam    --conf spark.cores.max=2 --conf spark.executor.memory=2g  --conf spark.driver.memory=2g \
--num-executors 20 --conf spark.driver.extraClassPath=/opt/cdata/lib/cdata.jdbc.salesforce.jar --conf spark.executor.extraClassPath=/opt/cdata/lib/cdata.jdbc.salesforce.jar  \
--jars sf-loader-assembly-1.0.jar    sf-loader_2.10-1.0.jar --JobMode=$JOB_MODE

echo "dse spark-submit  --driver-java-options "-Xms512M -Xmx10g" --class inventiv.s3.SourceToS3 --conf spark.cores.max=5 --conf spark.executor.memory=6g \
--conf spark.driver.memory=5g --conf spark.driver.extraClassPath=/opt/cdata/lib/cdata.jdbc.salesforce.jar \
--conf spark.executor.extraClassPath=/opt/cdata/lib/cdata.jdbc.salesforce.jar --num-executors 20 --jars sf-loader-assembly-1.0.jar \
sf-loader_2.10-1.0.jar --JobMode=$JOB_MODE"

dse spark-submit  --driver-java-options "-Xms512M -Xmx10g" --class inventiv.s3.SourceToS3 --conf spark.cores.max=5 --conf spark.executor.memory=6g \
--conf spark.driver.memory=5g --conf spark.driver.extraClassPath=/opt/cdata/lib/cdata.jdbc.salesforce.jar \
--conf spark.executor.extraClassPath=/opt/cdata/lib/cdata.jdbc.salesforce.jar --num-executors 20 --jars sf-loader-assembly-1.0.jar \
sf-loader_2.10-1.0.jar --JobMode=$JOB_MODE

if [[ -n $DAILY_SOURCES ]]
then
    IFS=',' read -r -a SOURCES <<< "$DAILY_SOURCES"

    for SOURCE in "${SOURCES[@]}"
    do
        if [[ -n $(aws s3 ls $DAILY_LANDING/$TIMESTAMP/Veeva/$SOURCE/) ]]
        then
            echo "$DAILY_LANDING/$TIMESTAMP/Veeva/$SOURCE/ already exists, skipping..."
         else
            echo "aws s3 cp $JOB_PATH/$DATE/Veeva/$SOURCE $DAILY_LANDING/$TIMESTAMP/Veeva/$SOURCE --recursive"
            aws s3 cp $JOB_PATH/$DATE/Veeva/$SOURCE $DAILY_LANDING/$TIMESTAMP/Veeva/$SOURCE --recursive

            if [[ -z $(aws s3 ls $DAILY_LANDING/$TIMESTAMP/Veeva/$SOURCE/) ]]
            then
                echo "Failed to copy $SOURCE to $DAILY_LANDING/$TIMESTAMP/Veeva/, exiting..."
                exit 1
            fi
        fi
    done
fi

export IFS=







