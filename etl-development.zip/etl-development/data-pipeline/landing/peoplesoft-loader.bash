#!/bin/bash

if [[ $2 -eq "default" ]]
then
    TIMESTAMP=$(($(date --date="$1" "+%s%N")/1000000))
else
    TIMESTAMP=$2
fi

PEOPLESOFT_PATH=$3
HOST=23.253.27.199
USER=
PASSWORD=
PEOPLESOFT_FILE_PATH=SFTP/INVENTIV_CDWBI/PS/Inbound
DATE=$(date +%m%d%Y)

echo "USER = $USER"
echo "HOST= $HOST"
echo "TIMESTAMP = $TIMESTAMP"
echo "PEOPLESOFT_PATH = $PEOPLESOFT_PATH"
echo "PEOPLESOFT_FILE_PATH = $PEOPLESOFT_FILE_PATH"
echo "DATE = $DATE"

cd /home/ec2-user

# NEED SSHPASS TO BE INSTALLED
export SSHPASS=$PASSWORD

sshpass -e sftp -o StrictHostKeyChecking=no $USER@$HOST > tmp_peoplesoft << EOF

cd $PEOPLESOFT_FILE_PATH
ls -ltr
quit
EOF

if [ $? -ne 0 ]
then
    echo "Error connecting to the Host server, exiting..."
    exit 1
fi

FNAME=`grep "EMPLOYEE_$DATE" tmp_peoplesoft | awk {'print $9'} | head -1`
echo "FNAME = $FNAME"

sshpass -e sftp -o StrictHostKeyChecking=no $USER@$HOST > tmp_peoplesoft << EOF

cd $PEOPLESOFT_FILE_PATH
get ${FNAME}
quit
EOF

if [ $? -ne 0 ]
then
    echo "Error connecting to the Host server, exiting..."
    exit 1
fi

FNAMECUT=EMPLOYEE.txt

echo "aws s3 rm --dryrun $PEOPLESOFT_PATH/$TIMESTAMP/Peoplesoft/$FNAMECUT"
aws s3 rm --dryrun $PEOPLESOFT_PATH/$TIMESTAMP/Peoplesoft/$FNAMECUT

if [[ $? -eq 0 ]]
then
    echo "File $FNAMECUT already exists in $PEOPLESOFT_PATH/$TIMESTAMP/Peoplesoft/, skipping..."
else
    echo "aws s3 cp $FNAME $PEOPLESOFT_PATH/$TIMESTAMP/Peoplesoft/$FNAMECUT"
    aws s3 cp $FNAME $PEOPLESOFT_PATH/$TIMESTAMP/Peoplesoft/$FNAMECUT
fi


