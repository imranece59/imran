#!/bin/bash

if [[ $2 -eq "default" ]]
then
    TIMESTAMP=$(($(date --date="$1" "+%s%N")/1000000))
else
    TIMESTAMP=$2
fi

LANDING=$3
TIMESTAMPS_FILE=$4

echo "TIMESTAMP = $TIMESTAMP"
echo "LANDING = $LANDING"
echo "TIMESTAMPS_FILE = $TIMESTAMPS_FILE"

cd /home/ec2-user

echo "aws s3 rm --dryrun $LANDING/$TIMESTAMPS_FILE"
aws s3 rm --dryrun $LANDING/$TIMESTAMPS_FILE

if [ $? -ne 0 ]
then
    echo -n $TIMESTAMP > $TIMESTAMPS_FILE
else
    echo "aws s3 cp $LANDING/$TIMESTAMPS_FILE $TIMESTAMPS_FILE"
    aws s3 cp $LANDING/$TIMESTAMPS_FILE $TIMESTAMPS_FILE

    if [[ -z $(cat $TIMESTAMPS_FILE) ]]
    then
        echo -n $TIMESTAMP > $TIMESTAMPS_FILE
    else
        echo -n ,$TIMESTAMP >> $TIMESTAMPS_FILE
    fi
fi

TIMESTAMPS_TO_PROCESS=`cat $TIMESTAMPS_FILE`
echo "TIMESTAMPS_TO_PROCESS = $TIMESTAMPS_TO_PROCESS"

echo "aws s3 cp $TIMESTAMPS_FILE $LANDING/$TIMESTAMPS_FILE"
aws s3 cp $TIMESTAMPS_FILE $LANDING/$TIMESTAMPS_FILE



