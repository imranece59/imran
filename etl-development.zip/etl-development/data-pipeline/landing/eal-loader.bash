#!/bin/bash

if [[ $2 -eq "default" ]]
then
    TIMESTAMP=$(($(date --date="$1" "+%s%N")/1000000))
else
    TIMESTAMP=$2
fi

LANDING=$3
SOURCES=$4
HOST=esft-us1.gsk.com
USER=
PASSWORD=
FREQUENCY=$5
EAL_FILE_PATH=dropbox/DES_inVentiv

echo "TIMESTAMP = $TIMESTAMP"
echo "LANDING = $LANDING"
echo "SOURCES = $SOURCES"
echo "USER = $USER"
echo "HOST= $HOST"
echo "EAL_FILE_PATH = $EAL_FILE_PATH"
echo "FREQUENCY = $FREQUENCY"

cd /var/media

# NEED SSHPASS TO BE INSTALLED
export SSHPASS=$PASSWORD

echo "sshpass -e sftp -o StrictHostKeyChecking=no -oKexAlgorithms=diffie-hellman-group14-sha1 $USER@$HOST > tmp_eal << EOF"
sshpass -e sftp -o StrictHostKeyChecking=no -oKexAlgorithms=diffie-hellman-group14-sha1 $USER@$HOST > tmp_eal << EOF

cd $EAL_FILE_PATH/$FREQUENCY
ls -ltr
quit
EOF

if [ $? -ne 0 ]
then
    echo "Error connecting to the Host server, exiting..."
    exit 1
fi

ZIP_LIST=`grep "inVentiv_$FREQUENCY" tmp_eal | awk {'print $9'}`
echo "ZIP_LIST = $ZIP_LIST"

ZIP=`grep "inVentiv_$FREQUENCY" tmp_eal | awk {'print $9'} | tail -1`
echo "ZIP = $ZIP"

TIME_LOAD_FILE=`grep "$ZIP" tmp_eal | awk  'BEGIN {OFS = "_"; } {print $6, $7, $9}'`
echo "TIME_LOAD_FILE = $TIME_LOAD_FILE"

for f in $ZIP_LIST
do
    echo "sshpass -e sftp -o StrictHostKeyChecking=no -oKexAlgorithms=diffie-hellman-group14-sha1 $USER@$HOST > tmp_$FREQUENCY << EOF"
    sshpass -e sftp -o StrictHostKeyChecking=no -oKexAlgorithms=diffie-hellman-group14-sha1 $USER@$HOST > tmp_$FREQUENCY << EOF

    cd $EAL_FILE_PATH/$FREQUENCY
    get ${f}
    quit
EOF

    if [ $? -ne 0 ]
    then
        echo "Error connecting to the Host server, exiting..."
        exit 1
    fi
done

echo "cat inVentiv_$FREQUENCY* > tmp.zip"
cat inVentiv_$FREQUENCY* > tmp.zip

echo "unzip tmp.zip -d tmp"
unzip tmp.zip -d tmp

if [[ -n $SOURCES ]]
then
    IFS=',' read -r -a SRC <<< "$SOURCES"

    for SOURCE in "${SRC[@]}"
    do
        echo "aws s3 rm --dryrun $LANDING/$TIMESTAMP/EAL/$SOURCE"
        aws s3 rm --dryrun $LANDING/$TIMESTAMP/EAL/$SOURCE

        if [[ $? -eq 0 ]]
        then
            echo "$SOURCE in $LANDING/$TIMESTAMP/EAL/ already exists, skipping..."
        else
            echo "aws s3 cp tmp/$SOURCE $LANDING/$TIMESTAMP/EAL/$SOURCE"
            aws s3 cp tmp/$SOURCE $LANDING/$TIMESTAMP/EAL/$SOURCE

            echo "aws s3 rm --dryrun $LANDING/$TIMESTAMP/EAL/$SOURCE"
            aws s3 rm --dryrun $LANDING/$TIMESTAMP/EAL/$SOURCE

            if [ $? -ne 0 ]
            then
                echo "Failed to copy $SOURCE to $LANDING/$TIMESTAMP/EAL/, exiting..."
                exit 1
            fi
        fi
    done
fi

