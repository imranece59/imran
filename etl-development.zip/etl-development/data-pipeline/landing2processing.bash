#!/bin/bash

TENANT_ID=$1
SOURCE_NAME_Q=\'$2\'
SOURCE_ENTITY_NAME_Q=\'$3\'
SOURCE_ENTITY_NAME=$3
TARGET_NAME_Q=\'$4\'
TARGET_NAME=$4
TARGET_ENTITY_NAME_Q=\'$5\'
TARGET_ENTITY_NAME=$5
TIMESTAMP_FOLDER=$6

echo "TENANT_ID = $TENANT_ID"
echo "SOURCE_NAME_Q = $SOURCE_NAME_Q"
echo "SOURCE_ENTITY_NAME = $SOURCE_ENTITY_NAME"
echo "SOURCE_ENTITY_NAME_Q = $SOURCE_ENTITY_NAME_Q"
echo "TARGET_NAME = $TARGET_NAME"
echo "TARGET_NAME_Q = $TARGET_NAME_Q"
echo "TARGET_ENTITY_NAME = $TARGET_ENTITY_NAME"
echo "TARGET_ENTITY_NAME_Q = $TARGET_ENTITY_NAME_Q"
echo "TIMESTAMP_FOLDER = $TIMESTAMP_FOLDER"

# CURRENT FIX
export CQLSH_HOST=192.168.6.45

current_entity_loc=`cqlsh -u XXX -p XXX -e "select current_entity_loc AS l from $TARGET_NAME.etl_config where target_name=$TARGET_NAME_Q and tenant_id=$TENANT_ID and source_name=$SOURCE_NAME_Q and source_entity_name=$SOURCE_ENTITY_NAME_Q and target_entity_name=$TARGET_ENTITY_NAME_Q limit 1"`
echo "current_entity_loc = $current_entity_loc"

landing_loc=`cqlsh -u XXX -p XXX -e "select landing_loc AS l from $TARGET_NAME.etl_config where target_name=$TARGET_NAME_Q and tenant_id=$TENANT_ID and source_name=$SOURCE_NAME_Q and source_entity_name=$SOURCE_ENTITY_NAME_Q and target_entity_name=$TARGET_ENTITY_NAME_Q limit 1"`
echo "landing_loc = $landing_loc"

PROCESSING_DIR=`echo $current_entity_loc | sed 's/ (.*//' | sed 's/.*- //'`
echo "PROCESSING_DIR = $PROCESSING_DIR"

PROCESSING_FINALDIR="$PROCESSING_DIR/$SOURCE_ENTITY_NAME"
echo "PROCESSING_FINALDIR = $PROCESSING_FINALDIR"

LANDING_DIR_FIRST=`echo $landing_loc | sed 's/.*- //' | sed 's/\/{.*//'`
echo "LANDING_DIR_FIRST = $LANDING_DIR_FIRST"

LANDING_DIR_SECOND=`echo $landing_loc | sed 's/.*}}\///' | sed 's/ (.*//'`
echo "LANDING_DIR_SECOND = $LANDING_DIR_SECOND"

LANDING_DIR="$LANDING_DIR_FIRST/$TIMESTAMP_FOLDER/$LANDING_DIR_SECOND"
echo "LANDING_DIR = $LANDING_DIR"

LANDING_FINALDIR="$LANDING_DIR/$SOURCE_ENTITY_NAME"
echo "LANDING_FINALDIR = $LANDING_FINALDIR"

if [[ $SOURCE_ENTITY_NAME == *[.]* ]]
then
    echo "aws s3 rm s3://$PROCESSING_FINALDIR"
    aws s3 rm s3://$PROCESSING_FINALDIR

    echo "aws s3 cp s3://$LANDING_FINALDIR s3://$PROCESSING_FINALDIR"
    aws s3 cp s3://$LANDING_FINALDIR s3://$PROCESSING_FINALDIR
else
    echo "aws s3 rm s3://$PROCESSING_FINALDIR --recursive"
    aws s3 rm s3://$PROCESSING_FINALDIR --recursive

    echo "aws s3 cp s3://$LANDING_FINALDIR s3://$PROCESSING_FINALDIR --recursive"
    aws s3 cp s3://$LANDING_FINALDIR s3://$PROCESSING_FINALDIR --recursive
fi






