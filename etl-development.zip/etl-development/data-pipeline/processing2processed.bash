#!/bin/bash

TENANT_ID=$1
SOURCE_NAME_Q=\'$2\'
SOURCE_ENTITY_NAME_Q=\'$3\'
SOURCE_ENTITY_NAME=$3
TARGET_NAME_Q=\'$4\'
TARGET_NAME=$4
TARGET_ENTITY_NAME_Q=\'$5\'
TARGET_ENTITY_NAME=$5
IS_OPTIONAL=$6

echo "TENANT_ID = $TENANT_ID"
echo "SOURCE_NAME_Q = $SOURCE_NAME_Q"
echo "SOURCE_ENTITY_NAME = $SOURCE_ENTITY_NAME"
echo "SOURCE_ENTITY_NAME_Q = $SOURCE_ENTITY_NAME_Q"
echo "TARGET_NAME = $TARGET_NAME"
echo "TARGET_NAME_Q = $TARGET_NAME_Q"
echo "TARGET_ENTITY_NAME = $TARGET_ENTITY_NAME"
echo "TARGET_ENTITY_NAME_Q = $TARGET_ENTITY_NAME_Q"
echo "IS_OPTIONAL = $IS_OPTIONAL"

# CURRENT FIX
export CQLSH_HOST=192.168.6.45

last_run=`cqlsh -u XXX -p XXX -e "select toUnixTimestamp(last_run) AS l from $TARGET_NAME.etl_config where target_name=$TARGET_NAME_Q and tenant_id=$TENANT_ID and source_name=$SOURCE_NAME_Q and source_entity_name=$SOURCE_ENTITY_NAME_Q and target_entity_name=$TARGET_ENTITY_NAME_Q limit 1"`
echo "last_run = $last_run"

prev_entity_loc=`cqlsh -u XXX -p XXX -e "select prev_entity_loc AS l from $TARGET_NAME.etl_config where target_name=$TARGET_NAME_Q and tenant_id=$TENANT_ID and source_name=$SOURCE_NAME_Q and source_entity_name=$SOURCE_ENTITY_NAME_Q and target_entity_name=$TARGET_ENTITY_NAME_Q limit 1"`
echo "prev_entity_loc = $prev_entity_loc"

current_entity_loc=`cqlsh -u XXX -p XXX -e "select current_entity_loc AS l from $TARGET_NAME.etl_config where target_name=$TARGET_NAME_Q and tenant_id=$TENANT_ID and source_name=$SOURCE_NAME_Q and source_entity_name=$SOURCE_ENTITY_NAME_Q and target_entity_name=$TARGET_ENTITY_NAME_Q limit 1"`
echo "current_entity_loc = $current_entity_loc"

FINALNUMBER=`echo $last_run | sed 's/.*- //' | sed 's/ (.*//'`
echo "FINALNUMBER = $FINALNUMBER"

PROCESSING_DIR=`echo $current_entity_loc | sed 's/ (.*//' | sed 's/.*- //'`
echo "PROCESSING_DIR = $PROCESSING_DIR"

PROCESSING_FINALDIR="$PROCESSING_DIR/$SOURCE_ENTITY_NAME"
echo "PROCESSING_FINALDIR = $PROCESSING_FINALDIR"

PROCESSED_DIR=`echo $prev_entity_loc | sed 's/ (.*//' | sed 's/.*- //' | sed 's/\/{.*//'`
echo "PROCESSED_DIR = $PROCESSED_DIR"

PROCESSED_FINALDIR="$PROCESSED_DIR/$FINALNUMBER/$SOURCE_ENTITY_NAME"
echo "PROCESSED_FINALDIR = $PROCESSED_FINALDIR"

if [[ (-z $FINALNUMBER || $FINALNUMBER -eq null) && ! -z $IS_OPTIONAL ]]
then
    echo "Job is optional, exiting..."
    exit 0
fi

if [[ (-z $FINALNUMBER || $FINALNUMBER -eq null) ]]
then
    echo "No last_run provided, exiting..."
    exit 1
fi

if [[ $SOURCE_ENTITY_NAME == *[.]* ]]
then
    echo "aws s3 cp s3://$PROCESSING_FINALDIR s3://$PROCESSED_FINALDIR"
    aws s3 cp s3://$PROCESSING_FINALDIR s3://$PROCESSED_FINALDIR
else
    echo "aws s3 cp s3://$PROCESSING_FINALDIR s3://$PROCESSED_FINALDIR --recursive"
    aws s3 cp s3://$PROCESSING_FINALDIR s3://$PROCESSED_FINALDIR --recursive
fi