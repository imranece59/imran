#!/bin/bash

MY_TOTAL_EXECUTOR_CORES=$1
MY_EXECUTOR_CORES=$2
MY_EXECUTOR_MEMORY=$3
MY_DRIVER_MEMORY=$4
JAVA_EXTRA_OPTIONS=$5
MY_OUTPUT_CONSISTENCY_LEVEL=$6
MY_INPUT_CONSISTENCY_LEVEL=$7
MY_BATCH_SIZE_BYTES=$8
MY_BATCH_GROUPING_SIZE_BYTES=$9
MY_OUTPUT_IGNORE_NULLS=${10}
MY_CONCURRENT_WRITES=${11}
MY_BATCH_GROUPING_KEY=${12}
CONFIG_FILE=${13}
TENANT_ID=${14}
SOURCE_NAME=${15}
SOURCE_NAME_Q=\'${15}\'
SOURCE_ENTITY_NAME=${16}
SOURCE_ENTITY_NAME_Q=\'${16}\'
TARGET_NAME=${17}
TARGET_NAME_Q=\'${17}\'
TARGET_ENTITY_NAME=${18}
TARGET_ENTITY_NAME_Q=\'${18}\'
TIMESTAMP_FOLDER=${19}
IS_OPTIONAL=${20}

echo "MY_TOTAL_EXECUTOR_CORES = $MY_TOTAL_EXECUTOR_CORES"
echo "MY_EXECUTOR_CORES = $MY_EXECUTOR_CORES"
echo "MY_EXECUTOR_MEMORY = $MY_EXECUTOR_MEMORY"
echo "MY_DRIVER_MEMORY = $MY_DRIVER_MEMORY"
echo "JAVA_EXTRA_OPTIONS = $JAVA_EXTRA_OPTIONS"
echo "MY_OUTPUT_CONSISTENCY_LEVEL = $MY_OUTPUT_CONSISTENCY_LEVEL"
echo "MY_INPUT_CONSISTENCY_LEVEL = $MY_INPUT_CONSISTENCY_LEVEL"
echo "MY_BATCH_SIZE_BYTES = $MY_BATCH_SIZE_BYTES"
echo "MY_BATCH_GROUPING_SIZE_BYTES = $MY_BATCH_GROUPING_SIZE_BYTES"
echo "MY_OUTPUT_IGNORE_NULLS = $MY_OUTPUT_IGNORE_NULLS"
echo "MY_CONCURRENT_WRITES = $MY_CONCURRENT_WRITES"
echo "MY_BATCH_GROUPING_KEY = $MY_BATCH_GROUPING_KEY"
echo "CONFIG_FILE = $CONFIG_FILE"
echo "TENANT_ID = $TENANT_ID"
echo "SOURCE_NAME = $SOURCE_NAME"
echo "SOURCE_NAME_Q = $SOURCE_NAME_Q"
echo "SOURCE_ENTITY_NAME = $SOURCE_ENTITY_NAME"
echo "SOURCE_ENTITY_NAME_Q = $SOURCE_ENTITY_NAME_Q"
echo "TARGET_NAME = $TARGET_NAME"
echo "TARGET_NAME_Q = $TARGET_NAME_Q"
echo "TARGET_ENTITY_NAME = $TARGET_ENTITY_NAME"
echo "TARGET_ENTITY_NAME_Q = $TARGET_ENTITY_NAME_Q"
echo "TIMESTAMP_FOLDER = $TIMESTAMP_FOLDER"
echo "IS_OPTIONAL = $IS_OPTIONAL"

# CURRENT FIX
export CQLSH_HOST=192.168.6.45

landing_loc=`cqlsh -u XXX -p XXX -e "select landing_loc AS l from $TARGET_NAME.etl_config where target_name=$TARGET_NAME_Q and tenant_id=$TENANT_ID and source_name=$SOURCE_NAME_Q and source_entity_name=$SOURCE_ENTITY_NAME_Q and target_entity_name=$TARGET_ENTITY_NAME_Q limit 1"`
echo "landing_loc = $landing_loc"

LANDING_DIR_FIRST=`echo $landing_loc | sed 's/.*- //' | sed 's/\/{.*//'`
echo "LANDING_DIR_FIRST = $LANDING_DIR_FIRST"

LANDING_DIR_SECOND=`echo $landing_loc | sed 's/.*}}\///' | sed 's/ (.*//'`
echo "LANDING_DIR_SECOND = $LANDING_DIR_SECOND"

MARKER_FILE_NAME=.${TENANT_ID}_${SOURCE_NAME}_${SOURCE_ENTITY_NAME}_${TARGET_NAME}_${TARGET_ENTITY_NAME}
echo "MARKER_FILE_NAME = $MARKER_FILE_NAME"

LANDING_MARKER_FILE="$LANDING_DIR_FIRST/${TIMESTAMP_FOLDER}/$LANDING_DIR_SECOND/$MARKER_FILE_NAME"
echo "LANDING_MARKER_FILE = $LANDING_MARKER_FILE"

echo "aws s3 rm --dryrun s3://$LANDING_MARKER_FILE"
aws s3 rm --dryrun s3://$LANDING_MARKER_FILE

if [[ $? -eq 0 ]]
then
    echo "Marker file $LANDING_MARKER_FILE exists, skipping spark job..."
    exit 0
fi

cd /home/ec2-user

if [ ! -f configs/$CONFIG_FILE ]
then
    CONFIG_FILE=default-job.conf
fi

echo "Running spark job"

echo "dse -u XXX -p XXX spark-submit --verbose --class com.inventivhealth.etl.ETL \
--total-executor-cores $MY_TOTAL_EXECUTOR_CORES --executor-cores $MY_EXECUTOR_CORES --executor-memory $MY_EXECUTOR_MEMORY \
--driver-memory $MY_DRIVER_MEMORY --conf $JAVA_EXTRA_OPTIONS --conf spark.cassandra.output.consistency.level=$MY_OUTPUT_CONSISTENCY_LEVEL \
--conf spark.cassandra.input.consistency.level=$MY_INPUT_CONSISTENCY_LEVEL --conf spark.cassandra.output.ignoreNulls=$MY_OUTPUT_IGNORE_NULLS \
--conf spark.cassandra.output.batch.size.bytes=$MY_BATCH_SIZE_BYTES --conf spark.cassandra.output.batch.grouping.buffer.size=$MY_BATCH_GROUPING_SIZE_BYTES \
--conf spark.cassandra.output.concurrent.writes=$MY_CONCURRENT_WRITES --conf spark.cassandra.output.batch.grouping.key=$MY_BATCH_GROUPING_KEY dataProcessor-assembly-0.0.1-RC1.jar \
--config-file configs/$CONFIG_FILE --tenant-id $TENANT_ID --source-name $SOURCE_NAME --source-entity-name $SOURCE_ENTITY_NAME \
--target-name $TARGET_NAME --target-entity-name $TARGET_ENTITY_NAME"

dse -u XXX -p XXX spark-submit --verbose --class com.inventivhealth.etl.ETL \
--total-executor-cores $MY_TOTAL_EXECUTOR_CORES --executor-cores $MY_EXECUTOR_CORES --executor-memory $MY_EXECUTOR_MEMORY \
--driver-memory $MY_DRIVER_MEMORY --conf $JAVA_EXTRA_OPTIONS --conf spark.cassandra.output.consistency.level=$MY_OUTPUT_CONSISTENCY_LEVEL \
--conf spark.cassandra.input.consistency.level=$MY_INPUT_CONSISTENCY_LEVEL --conf spark.cassandra.output.ignoreNulls=$MY_OUTPUT_IGNORE_NULLS \
--conf spark.cassandra.output.batch.size.bytes=$MY_BATCH_SIZE_BYTES --conf spark.cassandra.output.batch.grouping.buffer.size=$MY_BATCH_GROUPING_SIZE_BYTES \
--conf spark.cassandra.output.concurrent.writes=$MY_CONCURRENT_WRITES --conf spark.cassandra.output.batch.grouping.key=$MY_BATCH_GROUPING_KEY dataProcessor-assembly-0.0.1-RC1.jar \
--config-file configs/$CONFIG_FILE --tenant-id $TENANT_ID --source-name $SOURCE_NAME --source-entity-name $SOURCE_ENTITY_NAME \
--target-name $TARGET_NAME --target-entity-name $TARGET_ENTITY_NAME

if [[ $? -eq 0 ]]
then
    echo "Creating marker file..."
    touch $MARKER_FILE_NAME
    echo "aws s3 cp $MARKER_FILE_NAME s3://$LANDING_MARKER_FILE"
    aws s3 cp $MARKER_FILE_NAME s3://$LANDING_MARKER_FILE
    exit 0
fi

if [[ -z $IS_OPTIONAL ]]
then
    echo "Spark job failed, exiting..."
    exit 1
else
    echo "Step is optional, skipping failure..."
fi
